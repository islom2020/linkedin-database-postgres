import com.google.gson.Gson;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) throws IOException, SQLException {

        Gson gson = new Gson();
        ArrayList<Post> posts = new ArrayList<>();
        File file = new File("C:\\Users\\User\\Desktop\\aa.jpg");
        FileInputStream fileInputStream = new FileInputStream(file);
        byte[] bytes = fileInputStream.readAllBytes();

        Post post = new Post();

        post.setSize(0L);
        post.setName("Begzod");
        post.setContent_type(".png");
        post.setContent("AAAA".getBytes());

        Post post1 = new Post();

        post1.setSize(0L);
        post1.setName("BegzodBEK");
        post1.setContent_type(".png");
        post1.setContent("AAAABBBB".getBytes());
        posts.add(post1);
        posts.add(post);

        Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/linkedin","postgres","1");
        PreparedStatement preparedStatement = connection.prepareStatement("select add_post_b2(?,?,?)");

        System.out.println(gson.toJson(posts));
        preparedStatement.setString(1,"MuhammadSodiq barakallo");
        preparedStatement.setString(3,"a59066ac-c7f9-4167-8aff-265aab6007ef");
        preparedStatement.setString(2,gson.toJson(posts));

        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next())
            System.out.println(resultSet.getString("add_post_b2"));

        connection.close();
        fileInputStream.close();

    }
}


