create function get_wallets(i_id integer DEFAULT NULL::integer, i_fullname character varying DEFAULT NULL::character varying, i_wallet_type integer DEFAULT NULL::integer, i_mail_address character varying DEFAULT NULL::character varying, i_currency_id integer DEFAULT NULL::integer, i_phone_number character varying DEFAULT NULL::character varying, i_deposit_state integer DEFAULT NULL::integer, i_withdraw_state integer DEFAULT NULL::integer) returns SETOF ib_wallets
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
    v_condition varchar := '';
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;

    if i_wallet_type is not null then
        v_condition := v_condition || ' and t.wallet_type = ' || i_wallet_type;
    end if;
    if i_fullname is not null then
        v_condition := v_condition || 'and lower(t.fullname ) like ''%' || lower(i_fullname) || '%' || '''';
    end if;

    if i_currency_id is not null then
        v_condition := v_condition || ' and  t.currency_id= ' || i_currency_id ;
    end if;
    if i_deposit_state is not null then
        v_condition := v_condition || ' and  t.deposit_state= ' || i_deposit_state ;
    end if;
    if i_withdraw_state is not null then
        v_condition := v_condition || ' and  t.withdraw_state = ' || i_withdraw_state ;
    end if;
    if i_mail_address is not null then
        v_condition := v_condition || ' and  t.mail_address = ''' || i_mail_address || '''';
    end if;
    if i_phone_number is not null then
        v_condition := v_condition || ' and  t.phone_number = ''' || i_phone_number || '''';
    end if; 
    RETURN QUERY
        execute 'SELECT * FROM ib_wallets t  WHERE  1 = 1 ' || v_condition;
  /*  IF NOT FOUND THEN
        perform log_action_atx(v_condition, 5, 'wallet   not found  : get_wallets ' || v_condition, 'ERROR');
    END IF;*/
END ;
$$;

alter function get_wallets(integer, varchar, integer, varchar, integer, varchar, integer, integer) owner to interhub_user;

