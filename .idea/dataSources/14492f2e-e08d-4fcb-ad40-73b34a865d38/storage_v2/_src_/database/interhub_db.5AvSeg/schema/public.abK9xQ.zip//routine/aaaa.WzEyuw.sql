create function aaaa(aa bigint, bb bigint) returns bigint
    language plpgsql
as
$$
declare
  v_reference_id       integer;
begin

return aa + bb;
end;
$$;

alter function aaaa(bigint, bigint) owner to postgres;

