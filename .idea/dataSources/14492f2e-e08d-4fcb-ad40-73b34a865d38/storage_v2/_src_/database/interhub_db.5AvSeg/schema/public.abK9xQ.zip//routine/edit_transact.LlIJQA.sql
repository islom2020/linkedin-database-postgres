create function edit_transact(i_id bigint, i_agent_id integer, i_transact_amount numeric, i_state_id integer, i_client_account character varying, i_gateway_merchant_id integer, i_merchant_id integer, i_transact_date timestamp without time zone, i_agent_transact_id character varying, i_gateway_transact_id character varying, i_payment_type_id integer, i_params text, i_commission_amount numeric, i_info character varying, i_amount_in_currency numeric, i_amount_out_currency numeric, i_tran_type integer DEFAULT 1, i_gateway_transact_date character varying DEFAULT NULL::character varying, i_currency_id integer DEFAULT NULL::integer, i_source_currency_id integer DEFAULT NULL::integer, i_destination_currency_id integer DEFAULT NULL::integer, i_commission_agent numeric DEFAULT 0) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_created_by         integer := 1;
    v_date               date    := now();
    v_id_max             bigint;
    v_gateway_id         integer;
    v_object_id constant integer := 7;
    v_res                integer;
    v_agents             ib_agents%rowtype;
    v_gateways           ib_gateways%rowtype;
    v_transact           ib_transacts%rowtype;
    v_gateway_currency_id  integer;
  v_agent_merchants	ib_agent_merchant%rowtype;
  v_client_id  integer;
BEGIN
 
        select c.client_id , t.currency_id,t.gateway_id  into v_client_id, v_gateway_currency_id,v_gateway_id from ib_gateway_merchants t ,  ib_gateways c 
       		where t.id = i_gateway_merchant_id and c.id = t.gateway_id;
		if not found then 
			perform log_action_atx(i_id || '', v_object_id, 'can not find gateway ', 'ERROR');
            return false;
		end if;
     
        select t.* into v_transact from ib_transacts t where t.id = i_id for update;
    if not found then 
            perform log_action_atx(i_id || '', v_object_id, sqlerrm, 'ERROR');
            return false;
    end if;
	 begin
	          select t.* into v_agents from ib_agents t where id = i_agent_id
	         and currency_id = i_source_currency_id;
	       /* select t.*
	        into v_agents
	        from ib_agent_merchant t
	        where agent_id = i_agent_id
	          and merchant_id = i_merchant_id
	         and t.currency_id =  i_source_currency_id;*/
	    exception
	        when others then
	            perform log_action_atx(i_id || '', v_object_id, sqlerrm, 'ERROR');
	            return false;
	    end;
	   	if v_agents.currency_id is null then
--	   		  perform log_action_atx(i_id || '', v_object_id, ' agent merchant currency can not be null ', 'ERROR');
	            return false;
	   	end if;
   
 --   select t.* into v_gateways from ib_gateways t where id = v_gateway_id;
    if i_state_id in (4) and v_transact.state_id = 2 then

        select take_deposit(i_client_id => v_agents.client_id,
                            i_dr_amount => i_transact_amount,
                            i_client_type_id => 2,
                            i_currency_id => v_agents.currency_id,
                            i_group_id => i_id,
                            i_jur_id => v_agents.id,
                            i_commission_agent =>i_commission_agent)
        into v_res;
        if v_res = -1 then
            return false;
        end if;
    end if;
    if v_transact.state_id in (4, 5) and i_state_id = 7 then
        select take_deposit_back(i_client_id => v_agents.client_id, i_cr_amount => i_transact_amount,
                                 i_client_type_id => 2, i_currency_id => v_agents.currency_id, i_group_id=> i_id,
                            i_jur_id => v_agents.id)
        into v_res;
        if v_res = -1 then
            return false;
        end if;
    end if;
    if v_transact.state_id in (4, 5) and i_state_id = 6 then
        select return_deposit(i_client_id => v_client_id,
                              i_cr_amount => i_transact_amount,
                              i_client_type_id => 3,
                              i_currency_id => v_gateway_currency_id,
                              i_group_id => i_id
                              ,i_jur_id => v_gateway_id,
                               i_from_currency_id =>  v_agents.currency_id,
                              i_commission_amount => v_transact.commission_amount  )
        into v_res;
        if v_res = -1 then
            return
                false;
        end if;
    end if;
-- LOCK TABLE ib_transacts IN ACCESS EXCLUSIVE MODE;
    UPDATE public.ib_transacts
    SET agent_id            = i_agent_id
      , state_id            = i_state_id 
      , client_account      = i_client_account
      , source_currency_id         = i_source_currency_id
      , destination_currency_id         = i_destination_currency_id
      , gateway_merchant_id = i_gateway_merchant_id
      , merchant_id         = i_merchant_id
      , transact_date       = i_transact_date
      , agent_transact_id   = i_agent_transact_id
      , gateway_transact_id = i_gateway_transact_id
      , payment_type_id     = i_payment_type_id
      , params              = i_params
      , commission_amount   = i_commission_amount
      , created_date        = now()
      , transact_amount     = i_transact_amount
      , amount_in_currency  = i_amount_in_currency
      , info                = i_info
      , amount_out_currency  = i_amount_out_currency
      , gateway_transact_date = i_gateway_transact_date
    WHERE id = i_id;

    if v_transact.state_id in (6) and i_state_id = 8 then
        select reverse_deposit(i_from_client_id => v_client_id, 
        						i_to_client_id =>  v_Agents.client_id,
        					   i_dr_amount => i_transact_amount,
                               i_from_client_type_id => 3,
                               i_to_client_type_id => 2,
                               i_currency_id =>v_agents.currency_id,
                               i_group_id => i_id,
                               i_from_currency_id =>  v_gateway_currency_id,
                               i_commission_amount => v_transact.commission_amount,
                               i_from_jur_id => v_gateway_id,
                               i_to_jur_id =>v_Agents.id)
        into v_res;
        if v_res = -1 then
            return
                false;
        end if; 
    end if;
    return true;
exception
    when others THEN
        perform log_action_atx(i_id || '', v_object_id, sqlerrm || ' edit_transact', 'ERROR');
        return false;
END;
$$;

alter function edit_transact(bigint, integer, numeric, integer, varchar, integer, integer, timestamp, varchar, varchar, integer, text, numeric, varchar, numeric, numeric, integer, varchar, integer, integer, integer, numeric) owner to interhub_user;

