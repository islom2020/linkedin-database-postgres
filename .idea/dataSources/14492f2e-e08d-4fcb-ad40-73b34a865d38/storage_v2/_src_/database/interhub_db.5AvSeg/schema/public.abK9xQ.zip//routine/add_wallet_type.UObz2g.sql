create function add_wallet_type(i_type_name character varying, i_max_amount bigint, i_condition character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 5;
    v_id                 integer;
BEGIN
    insert into ib_wallet_types (type_name, max_amount, condition )
    values (i_type_name, i_max_amount, i_condition )
    returning id into v_id;

exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(nextval('ib_wallet_types_id_seq') || '', v_object_id, v_err_text || 'add_wallet_type',
                               'ERROR');
        return false;
END;
$$;

alter function add_wallet_type(varchar, bigint, varchar) owner to interhub_user;

