create function edit_jur_wallet_child(i_id integer, i_name character varying DEFAULT NULL::character varying, i_token character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 5; 
begin
	if i_parent_wallet_id is null then 
		raise 'wallet id can not null ';
	end if; 
	update ib_jur_wallet_childs  set 
		token  = i_token where id  = i_id ;
	return true;
	exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id  || '' , v_object_id,
                               v_err_text || 'add_wallets',
                               'ERROR');
        return false;
END;
$$;

alter function edit_jur_wallet_child(integer, varchar, varchar) owner to interhub_user;

