create function get_client_jur_info(i_birth_date character varying DEFAULT NULL::character varying, i_nationality character varying DEFAULT NULL::character varying, i_address character varying DEFAULT NULL::character varying, i_mail_address character varying DEFAULT NULL::character varying, i_client_id integer DEFAULT NULL::integer, i_region integer DEFAULT NULL::integer, i_phone_number character varying DEFAULT NULL::character varying, i_city character varying DEFAULT NULL::character varying, i_counter_agent_type integer DEFAULT NULL::integer, i_trade_mark character varying DEFAULT NULL::character varying, i_jur_inn character varying DEFAULT NULL::character varying) returns SETOF ib_client_jur_info
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 5;
     v_condition varchar := '';
    begin 
	    
	     
	     if i_phone_number  is not null then
       		 v_condition := v_condition || ' and t.phone_number  =  ''' || i_phone_number ||'''';
   		 end if;
   		  if i_region  is not null then
       		 v_condition := v_condition || ' and t.region  = ''' || i_region ||'''';
   		 end if;
   		
   		  if i_birth_date  is not null then
       		 v_condition := v_condition || ' and t.birth_date  = ''' || i_birth_date||'''' ;
   		 end if;
   		  
   		  if i_trade_mark  is not null then
       		 v_condition := v_condition || ' and t.trade_mark  = ''' || i_trade_mark||'''' ;
   		 end if;
   		 
   		  if i_jur_inn  is not null then
       		 v_condition := v_condition || ' and t.jur_inn  = ''' || i_jur_inn||'''' ;
   		 end if;
   		  
   		if i_mail_address is not null then
       		 v_condition := v_condition || ' and t.mail_address  = ''' || i_mail_address||'''' ;
   		 end if;
   		  
   		 	if i_nationality is not null then
       		 v_condition := v_condition || ' and t.nationality  = ''' || i_nationality||'''' ;
   		 end if;
   		 	if i_city is not null then
       		 v_condition := v_condition || ' and t.city  = ''' || i_city||'''' ;
   		 end if;
	   if i_address is not null then
       		 v_condition := v_condition || ' and t.address  = ''' || i_address||'''' ;
   		 end if;
	    
	     if i_counter_agent_type is not null then
       		 v_condition := v_condition || ' and t.counter_agent_type  = ' || i_counter_agent_type ;
   		 end if;
	     if i_client_id is not null then
       		 v_condition := v_condition || ' and t.client_id  = ' || i_client_id ;
   		 end if;
   		return query execute ' select
							t.*
						from
							public.ib_client_jur_info  
  t
      WHERE   1= 1 ' || v_condition;
  exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(v_condition, v_object_id, v_err_text || 'get_client_jur_info', 'ERROR');
        
END;
$$;

alter function get_client_jur_info(varchar, varchar, varchar, varchar, integer, integer, varchar, varchar, integer, varchar, varchar) owner to interhub_user;

