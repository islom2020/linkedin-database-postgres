create function get_all_currencies() returns SETOF ib_currencies
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    v_date      date    := now();
BEGIN
    return query
        select  id        ,
               currency_code,
               price         
               currency_date,
                created_date,  
                difference,
                nominal
        from ib_currencies;
END;
$$;

alter function get_all_currencies() owner to interhub_user;

