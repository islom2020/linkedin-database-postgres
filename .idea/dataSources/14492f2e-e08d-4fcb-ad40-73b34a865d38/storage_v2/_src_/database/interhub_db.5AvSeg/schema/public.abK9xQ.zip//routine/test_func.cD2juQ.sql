create function test_func() returns void
    language plpgsql
as
$$
DECLARE
    v_var           varchar ;
    v_count         integer := 0 ;
    v_dep           bigint  := 0;
    v_res           boolean := false;
    v_currency_code varchar := '';
    r               record;
BEGIN
    for r in (
        select *
        from ib_transacts
        where    state_id = 6 and   commission_amount != 0
        order by id)
        loop
            select currency_code
            into v_currency_code
            from ib_currencies
            where id = 860;
            select count(*), max(deposit)
            into v_count, v_dep
            from ib_client_deposit
            where client_id = r.agent_id
              and id = (select max(t.id)
                        from ib_client_deposit t
                        where t.client_id = r.agent_id
                          and t.client_type_id = 2
                          and t.currency_id = 860
                          and t.cr_acc_code = '1000' || r.agent_id || v_currency_code || 2
            );
            v_dep := v_dep - r.transact_amount;
            insert into ib_client_deposit (client_id, deposit, dr_acc_code, cr_acc_code, cr_amount, client_type_id,
                                           dr_amount, currency_id, group_id)
            values (r.agent_id, v_dep, '2000' || r.agent_id || v_currency_code || 2,
                    '1000' || r.agent_id || v_currency_code || 2, 0, 2,r.transact_amount, 860, r.id);
            v_dep := 0;
            select count(*), max(deposit)
            into v_count, v_dep
            from ib_client_deposit
            where id = (select max(t.id)
                        from ib_client_deposit t
                        where t.client_id = 1
                          and t.client_type_id = 3
                          and t.currency_id = 860
                          and t.cr_acc_code = '1000' || 1 || v_currency_code || 3
            );
            v_dep := v_dep +(r.transact_amount - r.commission_amount);
            insert into ib_client_deposit (client_id, deposit, dr_acc_code, cr_acc_code, cr_amount, client_type_id,
                                           dr_amount, currency_id, group_id)
            values (1, v_dep, '2000' || 1 || v_currency_code || 3, '1000' || 1 || v_currency_code || 3,  (r.transact_amount - r.commission_amount), 3,
                   0, 860, r.id);
            v_dep := 0;
            select count(*), max(deposit)
            into
                v_count, v_dep
            from ib_client_deposit
            where cr_acc_code = '0000' || v_currency_code
              and id = (select max(id)
                        from ib_client_deposit
                        where cr_acc_code = '0000' || v_currency_code);
            if v_dep is null then
                v_dep := 0;
            end if;
            v_dep := v_dep + r.commission_amount;
            insert into ib_client_deposit (client_id, deposit, dr_acc_code, cr_acc_code, cr_amount, client_type_id,
                                           dr_amount, currency_id, group_id)
            values (1, v_dep, '0000' || v_currency_code, '0000' || v_currency_code, r.commission_amount, 3,
                   0, 860, r.id);

        end loop;

end;

$$;

alter function test_func() owner to interhub_user;

