create function add_bank(i_filial_code character varying, i_bank_name character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_created_by         integer := 1;
    v_date               date    := now()::date;
    v_object_id constant integer := 2;
BEGIN
    insert into ib_s_banks (filial_code ,
    bank_name 
    )
    values ( i_filial_code ,
   i_bank_name);
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(nextval('ib_s_banks') || '', v_object_id, v_err_text, 'ERROR');
        return false;
END;
$$;

alter function add_bank(varchar, varchar) owner to interhub_user;

