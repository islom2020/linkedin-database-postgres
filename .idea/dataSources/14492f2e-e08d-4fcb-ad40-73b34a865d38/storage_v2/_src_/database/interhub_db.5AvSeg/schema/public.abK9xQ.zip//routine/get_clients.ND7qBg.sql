create function get_clients(i_id integer DEFAULT NULL::integer, i_client_name character varying DEFAULT NULL::character varying, i_client_type character varying DEFAULT NULL::character varying, i_client_inn character varying DEFAULT NULL::character varying, i_phone_number character varying DEFAULT NULL::character varying, i_address character varying DEFAULT NULL::character varying, i_condition character varying DEFAULT NULL::character varying, i_is_juridical_wallet character varying DEFAULT NULL::character varying, i_id_list character varying DEFAULT NULL::character varying) returns SETOF ib_clients
    language plpgsql
as
$$
DECLARE
    v_reference_id integer;
    v_err_text     varchar;
    v_condition    varchar = '';
BEGIN

    if i_id is not null then
        v_condition := v_condition || ' and t.id  =' || i_id;
    end if;
     if i_id_list is not null then
        v_condition := v_condition || ' and t.id in ( ' || i_id_list ||' )';
    end if;
    if i_client_type is not null then
        v_condition := v_condition || ' and t.client_type =''' || i_client_type || '''';
    end if;
    if i_client_inn is not null then
        v_condition := v_condition || ' and t.client_inn =''' || i_client_inn || '''';
    end if;
    if i_phone_number is not null then
        v_condition := v_condition || ' and  t.phone_number =''' || i_phone_number || '''';
    end if;
    if i_client_name is not null then
        v_condition := v_condition || 'and lower(t.client_name ) like ''%' || lower(i_client_name) || '%' || '''';
    end if; 
     
    if i_address is not null then
        v_condition := v_condition || 'and lower(t.address ) like ''%' || lower(i_address) || '%' || '''';
    end if;
   
    if i_condition is not null then
        v_condition := v_condition || ' and  t.conidition =''' || i_condition || '''';
    end if; 
   if i_is_juridical_wallet   is null then 
    RETURN QUERY
        execute 'SELECT * FROM ib_clients t  WHERE  1= 1 ' || v_condition;
     elsif  i_is_juridical_wallet ='Y' then 
    RETURN QUERY
        execute 'SELECT t.* FROM ib_clients t , ib_wallets s   WHERE   s.client_id =  t.id  and t.client_type != ''P''  ' || v_condition; 
     end if;
       
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', 0, v_err_text, 'ERROR');
END ;
$$;

alter function get_clients(integer, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar) owner to interhub_user;

