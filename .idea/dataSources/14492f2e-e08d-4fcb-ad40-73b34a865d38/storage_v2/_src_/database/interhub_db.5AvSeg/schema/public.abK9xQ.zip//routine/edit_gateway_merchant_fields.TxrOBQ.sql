create function edit_gateway_merchant_fields(i_id integer, i_code character varying DEFAULT NULL::character varying, i_description character varying DEFAULT NULL::character varying, i_ordered integer DEFAULT NULL::integer, i_min_length integer DEFAULT NULL::integer, i_field_type character varying DEFAULT NULL::character varying, i_is_required character varying DEFAULT NULL::character varying, i_gateway_merch_id integer DEFAULT NULL::integer, i_max_length integer DEFAULT NULL::integer, i_regexp character varying DEFAULT NULL::character varying, i_title character varying DEFAULT NULL::character varying, i_example character varying DEFAULT NULL::character varying, i_service_field_id integer DEFAULT NULL::integer, i_custom_type character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 1;
    v_code               character varying ;
    v_descreption        character varying ;
    v_ordered            integer ;
    v_length             integer ;
    v_field_type         character varying ; 
    v_is_required        character varying ;
    v_gateway_merch_id   integer ;
    v_max_length  varchar ;
    v_regexp varchar ;
    v_title varchar ;
    v_example varchar ;
   v_service_merchant_field integer;
  v_parent_id integer;
 v_custom_type varchar ;
BEGIN
    select code
         ,  description
         , ordered
         , min_length
         , field_type 
         , is_required
         , gateway_merch_id
         ,max_length
                                          , regexp
                                          , title
                                          , example 
                                          , service_field_id
                                          , custom_type
    into
        v_code
        , v_descreption
        , v_ordered
        , v_length
        , v_field_type 
        , v_is_required
        , v_gateway_merch_id
       , v_max_length
                                          , v_regexp
                                          , v_title
                                          , v_example 
                                          ,v_service_merchant_field
                                          ,v_custom_type
    from ib_gateway_merchant_fields
    where id = i_id;
    if not found then
        v_err_text := 'takaya merchant ne nayden ';
        perform log_action_atx(i_id, v_object_id, v_err_text, 'ERROR');
        return false;
    end if;
    if i_service_field_id is null then
        i_service_field_id := v_service_merchant_field;
    end if;
     
    if i_example is null then
        i_example := v_example;
    end if;
    if i_custom_type is null then
        i_custom_type := v_custom_type;
    end if;
    if i_code is null then
        i_code := v_code;
    end if;
    if i_description is null then
        i_description := v_descreption;
    end if;
    if i_ordered is null then
        i_ordered := v_ordered;
    end if;
    if i_min_length is null then
        i_min_length := v_length;
    end if;
    if i_field_type is null then
        i_field_type := v_field_type;
    end if; 
    if i_is_required is null then
        i_is_required := v_is_required;
    end if;
    if i_gateway_merch_id is null then
        i_gateway_merch_id := v_gateway_merch_id;
    end if;
   
    if i_max_length is null then
        i_max_length := v_max_length;
    end if;
    if i_regexp is null then
        i_regexp := v_regexp;
    end if;
 
    if i_title is null then
        i_title := v_title;
    end if;
   
    update ib_gateway_merchant_fields
    set code             = i_code, 
        gateway_merch_id = i_gateway_merch_id,
        is_required      = i_is_required,
        field_type       = i_field_type,
        min_length           = i_min_length,
        ordered          =i_ordered,
       	description      = i_description,
			  max_length   = I_max_length,
			  regexp = i_regexp ,
			  title= i_title , 
			  example = i_example ,
			  service_field_id= i_service_field_id ,
			  custom_type = i_custom_type
			 where id = i_id;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id ||'', v_object_id, v_err_text, 'ERROR');
        return false;
END;
$$;

alter function edit_gateway_merchant_fields(integer, varchar, varchar, integer, integer, varchar, varchar, integer, integer, varchar, varchar, varchar, integer, varchar) owner to interhub_user;

