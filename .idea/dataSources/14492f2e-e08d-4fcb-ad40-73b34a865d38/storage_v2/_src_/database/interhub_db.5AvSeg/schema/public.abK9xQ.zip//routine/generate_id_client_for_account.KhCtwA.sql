create function generate_id_client_for_account(i_client_id integer) returns character varying
    language plpgsql
as
$$
DECLARE
    v_err_text varchar:='';
    v_client_id varchar:=''||i_client_id;
begin
    LOOP
        EXIT WHEN length(v_client_id) = 8 ;

        v_client_id := '0'||v_client_id;
    END LOOP ;
    return  v_client_id;
exception
    when others THEN
        v_err_text := sqlerrm;
END ;
$$;

alter function generate_id_client_for_account(integer) owner to interhub_user;

