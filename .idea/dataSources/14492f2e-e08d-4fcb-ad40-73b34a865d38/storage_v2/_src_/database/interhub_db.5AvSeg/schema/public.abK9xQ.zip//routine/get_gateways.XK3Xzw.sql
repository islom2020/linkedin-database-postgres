create function get_gateways(i_id integer DEFAULT NULL::integer, i_name character varying DEFAULT NULL::character varying, i_login character varying DEFAULT NULL::character varying, i_request_token character varying DEFAULT NULL::character varying, i_has_billing integer DEFAULT NULL::integer, i_client_id integer DEFAULT NULL::integer) returns SETOF ib_gateways
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
    v_condition varchar := '';
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
   
    if i_client_id is not null then
        v_condition := v_condition || ' and t.client_id = ' || i_client_id;
    end if;
   
    if i_has_billing  is not null then
        v_condition := v_condition || ' and t.has_billing = ' || i_has_billing;
    end if;
   
    if i_name is not null then
        v_condition := v_condition || 'and lower(t.name) like ''%' || lower(i_name) || '%' || '''';
    end if;
   if i_request_token is not null then
        v_condition := v_condition || 'and  t.request_token = ''' || i_request_token ||  '''';
    end if;
    if i_login is not null then
        v_condition := v_condition || 'and t.login like ''' =|| i_login  '''';
    end if;
    return query execute ' SELECT  t.* FROM ib_gateways t
      WHERE   1= 1 ' || v_condition;


    if not found then
        perform log_action_atx(v_condition, 3, 'Данный не нфйден ид :get_gateways' || v_condition, 'ERROR');
    end if;
END;
$$;

alter function get_gateways(integer, varchar, varchar, varchar, integer, integer) owner to interhub_user;

