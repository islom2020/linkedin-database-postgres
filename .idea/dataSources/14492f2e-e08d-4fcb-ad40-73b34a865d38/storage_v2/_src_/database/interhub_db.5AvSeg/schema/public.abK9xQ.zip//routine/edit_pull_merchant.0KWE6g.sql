create function edit_pull_merchant(i_id integer, i_gateway_merchant_id integer DEFAULT NULL::integer, i_gateway_id integer DEFAULT NULL::integer, i_merchant_id integer DEFAULT NULL::integer) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text            varchar;
    v_object_id constant  integer := 1; 
    v_gateway_merchant_id integer ;
    v_merchant_id         integer ;
    v_gateway_id         integer ; 
   v_id 			integer;
BEGIN
    select id,
           gateway_merchant_id,
           merchant_id,
           gateway_id 
    into
        v_id ,
        v_gateway_merchant_id ,
        v_merchant_id ,
        v_gateway_id  
    from ib_pull_merchants
    where id = i_id;
    if not found then
        v_err_text := 'takaya merchant ne nayden ';
        perform log_action_atx(i_id, v_object_id, v_err_text, 'ERROR');
        return false;
    end if;
   
    if i_merchant_id is null then
        i_merchant_id := v_merchant_id;
    end if;
    if i_gateway_merchant_id is null then
        i_gateway_merchant_id := v_gateway_merchant_id;
    end if;
   
    if i_gateway_id is null then
       i_gateway_id := v_gateway_id;
    end if;
   
    update ib_pull_merchants
    set  
        gateway_merchant_id = i_gateway_merchant_id,
        merchant_id          = i_merchant_id,
        i_gateway_id         = i_gateway_id 
    where id = i_id;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id||'', v_object_id, v_err_text || ' edit_merchant', 'ERROR');
        return false;
END;
$$;

alter function edit_pull_merchant(integer, integer, integer, integer) owner to interhub_user;

