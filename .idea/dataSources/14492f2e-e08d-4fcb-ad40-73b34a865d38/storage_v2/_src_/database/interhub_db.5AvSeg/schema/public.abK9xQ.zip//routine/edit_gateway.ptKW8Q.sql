create function edit_gateway(i_id integer, i_name character varying DEFAULT NULL::character varying, i_login character varying DEFAULT NULL::character varying, i_password character varying DEFAULT NULL::character varying, i_currency_id integer DEFAULT NULL::integer, i_state_id integer DEFAULT NULL::integer, i_pay_url character varying DEFAULT NULL::character varying, i_small_logo character varying DEFAULT NULL::character varying, i_amount_unit bigint DEFAULT NULL::bigint, i_ip_address character varying DEFAULT NULL::character varying, i_check_url character varying DEFAULT NULL::character varying, i_has_billing integer DEFAULT NULL::integer) returns boolean
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
    v_err_text varchar := '';
   			v_name  varchar ;
            v_login varchar ;
            v_password varchar ;
            v_currency_id integer ;
            v_state_id integer ;
            v_pay_url varchar ;
            v_small_logo varchar ;
            v_amount_unit numeric  ;
            v_ip_address varchar ;
            v_check_url varchar ;
            v_has_billing integer;
		   
		   
BEGIN
 
	select t.name ,
            t.login,
            t.password,
            t.currency_id,
            t.state_id,
            t.pay_url,
            t.small_logo,
            t.amount_unit,
            t.ip_address,
            t.check_url,
            t.has_billing 
		    into 
		    	v_name                   
			   , v_login                   
			   , v_password            
			   , v_currency_id         
			   , v_state_id              
			   , v_pay_url               
			   , v_small_logo          
			   , v_amount_unit        
			   , v_ip_address          
			   , v_check_url            
			   , v_has_billing 
			   

		   from ib_gateways t where t.id = i_id ;
    if i_name is null then
        i_name := v_name;
    end if;
    if i_currency_id is null then
        i_currency_id := v_currency_id;
    end if;
	 if i_login is null then
        i_login := v_login;
    end if;
   if i_password is null then
        i_password := v_password;
    end if;
    if i_currency_id is null then
        i_currency_id := v_currency_id;
    end if;
   if i_state_id is null then
        i_state_id := v_state_id;
    end if;
	 if i_pay_url is null then
        i_pay_url := v_pay_url;
    end if;  
    if i_small_logo is null then
        i_small_logo := v_small_logo;
    end if;  
   if i_amount_unit is null then
        i_amount_unit := v_amount_unit;
    end if;
     if i_ip_address is null then
        i_ip_address := v_ip_address;
    end if;
     if i_check_url is null then
        i_check_url := v_check_url;
    end if;
     if i_has_billing is null then
        i_has_billing := v_has_billing;
    end if;
    update ib_gateways set
                           name =i_name,
                           login= i_login  ,
                           password = i_password,
                           currency_id = i_currency_id  ,
                           state_id  = i_state_id,
                           pay_url = i_pay_url,
                           small_logo =i_small_logo,
                           amount_unit =i_amount_unit,
                           ip_address =i_ip_address,
                           check_url = i_check_url,
                           has_billing= i_has_billing
                           where id  = i_id ;
    return  true ;
   exception when  others then 
     v_err_text := sqlerrm;
        perform log_action_atx(i_id||'', 3, v_err_text || ' edit_gateway', 'ERROR');
        return false;
END;
$$;

alter function edit_gateway(integer, varchar, varchar, varchar, integer, integer, varchar, varchar, bigint, varchar, varchar, integer) owner to interhub_user;

