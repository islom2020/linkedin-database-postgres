create function add_client_deposit(i_account_id integer, i_balance numeric, i_debit_amount numeric, i_credit_amount numeric, i_group_id bigint, i_is_commission character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_object_id constant integer   := 4;
    v_date               timestamp := now();
BEGIN

    insert into ib_client_deposit (account_id, debit_amount, credit_amount, balance, group_id)
    values (i_account_id,
            i_debit_amount,
            i_credit_amount,
            i_balance,
            i_group_id);
    return true;
exception
    when others THEN
        perform log_action_atx(i_account_id || '', v_object_id, sqlerrm || ' add_client_deposit', 'ERROR');
        return false;
END;
$$;

alter function add_client_deposit(integer, numeric, numeric, numeric, bigint, varchar) owner to interhub_user;

