create function add_transact(i_agent_id integer, i_transact_amount numeric, i_state_id integer, i_client_account character varying, i_gateway_merchant_id integer, i_merchant_id integer, i_transact_date timestamp without time zone, i_agent_transact_id character varying, i_gateway_transact_id character varying, i_payment_type_id integer, i_params text, i_commission_amount numeric, i_amount_in_currency numeric, i_info character varying, i_amount_out_currency numeric DEFAULT NULL::numeric, i_tran_type integer DEFAULT 1, i_gateway_transact_date character varying DEFAULT NULL::character varying, i_source_currency_id integer DEFAULT NULL::integer) returns bigint
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_currency_price     numeric ;
    v_created_by         integer := 1;
    v_date               date    := now();
    v_id                 bigint  := 1;
    v_id_max             bigint  := -1;
    v_object_id constant integer := 7;
    v_gateway_merchants         ib_gateway_merchants%rowtype ;
    v_client_dep_count   integer := 0;
    v_merch_count        integer := 0;
   	v_without_commission_amount numeric := 0;
   v_commission_agent numeric := 0;
   v_agent   		ib_agents%rowtype;
--v_transact_id bigint;
    v_agent_merchants    ib_agent_merchant%rowtype;
BEGIN
    select t.* into v_gateway_merchants from ib_gateway_merchants t where  
  			t.id = i_gateway_merchant_id ;
	if not found then 
		  perform log_action_atx(i_client_account , v_object_id, 'this gateway merchant is not found  ', 'ERROR');
        return -1;
	end if;
	if i_commission_amount is null or v_gateway_merchants.currency_id is null then
        perform log_action_atx(i_agent_id || '', v_object_id, 'commission amount shouldnt be null ', 'ERROR');
        return -1;
    end if;
   
    begin
        /*perform write_log_transaction_atx(i_agent_id, i_client_account,
                                          i_gateway_merchant_id, i_transact_date, i_gateway_transact_id, i_params,
                                          i_transact_amount, i_merchant_id, i_agent_transact_id);*/
        select t.price
        into v_currency_price
        from ib_currencies t
        where id = v_gateway_merchants.currency_id;
        select t.*
        into v_agent_merchants
        from ib_agent_merchant t
        where agent_id = i_agent_id
          and merchant_id = i_merchant_id
         and t.currency_id = i_source_currency_id  ;
    exception
        when others then
            perform log_action_atx(i_agent_id || '', v_object_id, sqlerrm, 'ERROR');
            return -1;
    end;
   		
   		select t.* into v_agent  from ib_agents t where t.id  =  i_agent_id ;
   if not found then 
   		return -1; 
   end if;
  	if i_tran_type  =2  then 
  		select   calculate_exchange_amount(i_amount_in_currency , 
  	v_gateway_merchants.currency_id,  v_agent.currency_id   ) into v_without_commission_amount ;
  		if v_without_commission_amount is null then 
			raise 'exchange qilishni iloji yuq ';
  		end if;
  	 i_transact_amount :=  trunc( v_without_commission_amount*100/(100-v_agent_merchants.commission_down  - v_gateway_merchants.commission_down),  2 );
		  	if i_transact_amount is null or i_transact_amount= 0  then 
		  		raise '  transact_amount null bulmasligi kerak ';
		  	end if;
		  i_commission_amount := i_transact_amount  - v_without_commission_amount;
  	else 
    if  v_agent_merchants.commission_down > 0  or  v_gateway_merchants.commission_down >0 then
        i_commission_amount := i_transact_amount * ( v_agent_merchants.commission_down  + v_gateway_merchants.commission_down    ) / 100;
    end if;
   end if;
	if i_commission_amount is null or i_transact_amount = 0   then 
			raise 'commission cant be null';
	end if;
 
	if  v_agent_merchants.commission_from_agent > 0 then 
		v_commission_agent :=  i_transact_amount * (v_agent_merchants.commission_from_agent)/100;
	elsif 	v_agent_merchants.commission_to_agent >  0  then 
		v_commission_agent := - i_transact_amount * (v_agent_merchants.commission_to_agent)/100;
	end if;
    select generate_id_transact(i_agent_id) into v_id_max;
    select count(*)
    into v_merch_count
    from ib_merchants
    where id = i_merchant_id;
   
    if v_merch_count > 0  and i_tran_type = 1 then
	   if  i_gateway_merchant_id in (2,  18 ) and v_gateway_merchants.currency_id = 643 then 
			    	   select t.price
			        into v_currency_price
			        from ib_currencies t
			        where id = 840;
			      i_amount_in_currency :=   trunc((i_transact_amount - i_commission_amount) / v_currency_price :: numeric, 2);
	   			select * from calculate_exchange_amount (i_amount_in_currency ,  840 , v_gateway_merchants.currency_id) 
	   					into 	i_amount_in_currency;
	   				if i_amount_in_currency is null then 
			   				 select t.price
					        into v_currency_price
					        from ib_currencies t
					        where id = v_gateway_merchants.currency_id;
	   					i_amount_in_currency :=  trunc((i_transact_amount - i_commission_amount) / v_currency_price :: numeric, 2);
	   				end if;
	    	elsif v_agent.currency_id = 860  then  
		      	  i_amount_in_currency := trunc((i_transact_amount - i_commission_amount) / v_currency_price :: numeric, 2);
			elsif   v_agent.currency_id in ( 643,  978)  then 
				if v_agent.currency_id in (978) then 
					 	select * from calculate_exchange_amount((i_transact_amount - i_commission_amount),  v_agent.currency_id , 								643  ) into i_amount_in_currency;
					select * from calculate_exchange_amount(i_amount_in_currency,  643,  	840  ) into i_amount_in_currency; 
				else 
					select * from calculate_exchange_amount((i_transact_amount - i_commission_amount),  v_agent.currency_id , 								840  ) into i_amount_in_currency;
				end if;
			select * from calculate_exchange_amount(i_amount_in_currency,  840, 	v_gateway_merchants.currency_id  ) into i_amount_in_currency;
			else
				select * from calculate_exchange_amount((i_transact_amount - i_commission_amount),  v_agent.currency_id , v_gateway_merchants.currency_id  ) into i_amount_in_currency;
-- 		      	  i_amount_in_currency := trunc((i_transact_amount - i_commission_amount) * v_currency_price :: numeric, 2);
			end if;
      elsif v_merch_count =0 then 
          return -1;
    end if;
   if i_amount_in_currency is null then 
   		raise 'amount in currency can not be null ';
   	else 
	   	i_amount_in_currency := trunc(i_amount_in_currency,  2 );
   end if;
begin 
--    LOCK TABLE ib_transacts IN ACCESS EXCLUSIVE MODE;
   INSERT INTO ib_transacts ( id
                             , agent_id
                             , state_id
                             , client_account
                             , destination_currency_id
                             , gateway_merchant_id
                             , merchant_id
                             , transact_date
                             , agent_transact_id
                             , gateway_transact_id
                             , payment_type_id
                             , params
                             , commission_amount
                             , created_date
                             , transact_amount
                             , amount_in_currency
                             , info
                             ,amount_out_currency
                             ,tran_type
                             ,gateway_transact_date
                             ,source_currency_id
                             ,commission_agent)
    VALUES ( v_id_max
           , i_agent_id
           , i_state_id
           , i_client_account
           , v_gateway_merchants.currency_id
           , i_gateway_merchant_id
           , i_merchant_id
           , i_transact_date
           , i_agent_transact_id
           , i_gateway_transact_id
           , i_payment_type_id
           , i_params
           , i_commission_amount
           , now()
           , i_transact_amount
           , i_amount_in_currency
           , i_info
           ,i_amount_out_currency
           ,i_tran_type
           ,i_gateway_transact_date
           ,i_source_currency_id
           ,v_commission_agent);

    return v_id_max;
   exception    WHEN unique_violation THEN 
      perform log_action_atx(v_id_max || '', v_object_id, sqlerrm ||i_agent_id|| ' add_transacts', 'ERROR');
        return -2;
       end;
exception
    when others THEN
        perform log_action_atx(v_id_max || '', v_object_id, sqlerrm || 'add_transacts', 'ERROR');
        return -1;
END;
$$;

alter function add_transact(integer, numeric, integer, varchar, integer, integer, timestamp, varchar, varchar, integer, text, numeric, numeric, varchar, numeric, integer, varchar, integer) owner to interhub_user;

