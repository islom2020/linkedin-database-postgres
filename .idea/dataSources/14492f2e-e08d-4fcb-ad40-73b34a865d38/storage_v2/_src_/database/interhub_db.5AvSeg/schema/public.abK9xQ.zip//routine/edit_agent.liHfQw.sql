create function edit_agent(i_id integer, i_token character varying DEFAULT NULL::character varying, i_name character varying DEFAULT NULL::character varying, i_payment_type integer DEFAULT NULL::integer, i_commission numeric DEFAULT NULL::numeric, i_currency_id integer DEFAULT NULL::integer, i_state_id integer DEFAULT NULL::integer) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_created_by         integer := 1;
    v_object_id constant integer := 2;
    v_payment_type       integer;
    v_token              varchar(200) ;
    v_name               varchar(300);
    v_commission         numeric(5, 2);
    v_currency_code      varchar;
   v_state_id integer ;
BEGIN
    select name, payment_type, token, commission, i_currency_id, state_id 
    into
        v_name , v_payment_type, v_token , v_commission,v_currency_code,  v_state_id 
    from ib_agents
    where id = i_id;
    if not found then
        v_err_text := 'takaya id ne nayden ';
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
    end if;
    if i_payment_type is null then
        i_payment_type := v_payment_type;
    end if;
     if i_state_id is null then
        i_state_id := v_state_id;
    end if;
    if i_token is null then
        i_token := v_token;
    end if;
    if i_name is null then
        i_name := v_name;
    end if;
    if i_commission is null then
        i_commission := v_commission;
    end if;
    if i_currency_id is null then
        i_currency_id := v_currency_code;
    end if;
    update ib_agents
    set name         = i_name,
        payment_type = i_payment_type,
        token        = i_token,
        commission   = i_commission,
        currency_id  = i_currency_id,
        state_id = i_state_id 
    where id = i_id;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', v_object_id, v_err_text ||' edit_agent ', 'ERROR');
        return false;
END;
$$;

alter function edit_agent(integer, varchar, varchar, integer, numeric, integer, integer) owner to interhub_user;

