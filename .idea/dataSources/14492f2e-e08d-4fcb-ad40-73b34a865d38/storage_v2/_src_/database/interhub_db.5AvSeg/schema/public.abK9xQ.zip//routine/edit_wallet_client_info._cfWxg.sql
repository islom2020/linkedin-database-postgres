create function edit_wallet_client_info(i_id integer, i_first_name character varying DEFAULT NULL::character varying, i_surname character varying DEFAULT NULL::character varying, i_last_name character varying DEFAULT NULL::character varying, i_birth_date character varying DEFAULT NULL::character varying, i_doc_number character varying DEFAULT NULL::character varying, i_nationality character varying DEFAULT NULL::character varying, i_gender character varying DEFAULT NULL::character varying, i_birth_address character varying DEFAULT NULL::character varying, i_expiry_doc character varying DEFAULT NULL::character varying, i_authority character varying DEFAULT NULL::character varying, i_registration_address character varying DEFAULT NULL::character varying, i_doc_photo_url character varying DEFAULT NULL::character varying, i_mail_address character varying DEFAULT NULL::character varying, i_self_photo character varying DEFAULT NULL::character varying, i_state_id integer DEFAULT NULL::integer, i_client_id integer DEFAULT NULL::integer, i_info character varying DEFAULT NULL::character varying, i_region_id integer DEFAULT NULL::integer, i_created_date character varying DEFAULT NULL::character varying, i_created_doc_date character varying DEFAULT NULL::character varying, i_user_id integer DEFAULT NULL::integer, i_doc_address_photo character varying DEFAULT NULL::character varying, i_oson_file character varying DEFAULT NULL::character varying, i_yandex_file character varying DEFAULT NULL::character varying, i_qiwi_file character varying DEFAULT NULL::character varying, i_filial_id integer DEFAULT NULL::integer) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 5;
    v_first_name varchar ;		
v_surname 				varchar ;
v_last_name				 varchar;
v_birth_date 					varchar;
v_doc_number  			varchar;
v_nationality 			varchar;
v_gender				varchar;
v_birth_address 		varchar;
v_expiry_doc 			varchar;
v_authority 			varchar ;
v_registration_address		varchar;
v_doc_photo_url			varchar;
v_mail_address		varchar;
v_self_photo 			varchar; 
v_state_id			integer;
v_client_id 			integer ;
v_info 			varchar ;
v_created_doc_date varchar ;
v_region_id integer ;
v_res  boolean;
v_descreption  varchar :=' ';
v_doc_address_photo varchar;
v_oson_file varchar ;
v_yandex_file varchar ;
v_qiwi_file varchar ;
 v_filial_id integer ;
begin
	 select   				
			 t.first_name 			
			,t.surname 		
			,t.last_name	
			,t.birth_date 		
			,t.doc_number  	
			,t.nationality 		
			,t.gender				
			,t.birth_address 	
			,t.expiry_doc 	
			,t.authority 		
			,t.registration_address		
			,t.doc_photo_url		
			,t.mail_address	
			,t.self_photo 		
			,t.state_id			
			,t.client_id 
			, t.info 
			, t.region_id
			,t.created_doc_date
			,t.doc_address_photo
			,t.oson_file
			,t.yandex_file
			,t.qiwi_file
			,t.filial_id 
			into  					
			 v_first_name 				
				,v_surname 			
				,v_last_name		
				,v_birth_date 		
				,v_doc_number  	
				,v_nationality 		
				,v_gender				
				,v_birth_address 		
				,v_expiry_doc 		
				,v_authority 			
				,v_registration_address		
				,v_doc_photo_url			
				,v_mail_address	
				,v_self_photo 		
				,v_state_id			
				,v_client_id 
				, v_info  
				,v_region_id
				,v_created_doc_date
				,v_doc_address_photo
				,v_oson_file
				,v_yandex_file
				,v_qiwi_file
				, v_filial_id 
from ib_wallet_client_info  t where id =  i_id ;
    if i_state_id is null then
         if i_state_id != v_state_id then  v_descreption  := v_descreption||'  state_id "'||v_state_id ||'" -->  "'||i_state_id ||'" ';
         end if;  i_state_id := v_state_id;
    end if;
 if i_first_name is null then
        if i_first_name != v_first_name then  v_descreption  := v_descreption||'  first_name "'||v_first_name ||'" -->  "'||i_first_name ||'" ';
         end if; i_first_name := v_first_name;
    end if;
    if i_region_id is null then
      if i_region_id != v_region_id then  v_descreption  := v_descreption||'   region_id "'||v_region_id ||'" -->  "'||i_region_id ||'" ';  end if;
       i_region_id := v_region_id;
    end if;
    if i_surname is null then
       if i_surname != v_surname then v_descreption  := v_descreption||'    surname "'||v_surname ||'" -->  "'||i_surname ||'" '; end if;
        i_surname := v_surname; 
    end if;
    if i_last_name is null then
         if i_last_name != v_last_name then  v_descreption  := v_descreption||'   last_name "'||v_last_name ||'" -->  "'||i_last_name ||'" '; end if;
        i_last_name := v_last_name;
    end if;
      if i_nationality is null then
       if i_nationality != v_nationality then v_descreption  := v_descreption||'   nationality "'||v_nationality ||'" -->  "'||i_nationality ||'" '; end if;
        i_nationality := v_nationality;
    end if;
     if i_created_doc_date is null then
        if i_created_doc_date != v_created_doc_date then v_descreption  := v_descreption||'    created_doc_date "'||v_created_doc_date ||'" -->  "'||i_created_doc_date ||'" ';end 		if;
        i_created_doc_date := v_created_doc_date;
    end if;
    if i_mail_address is null then
        if i_mail_address != v_mail_address then v_descreption  := v_descreption||'    mail_address "'||v_mail_address ||'" -->  "'||i_mail_address ||'" ';end if;
        i_mail_address := v_mail_address;
    end if;

    if i_client_id is null then
     	  if i_client_id != v_client_id then v_descreption  := v_descreption||'   client_id "'||v_client_id ||'" -->  "'||i_client_id ||'" ';end if;
        i_client_id := v_client_id;
    end if;
   
    if i_gender is null then
  		  if i_gender != v_gender then  v_descreption  := v_descreption||'   gender "'||v_gender ||'" -->  "'||i_gender ||'" ';end if;
        i_gender := v_gender;
    end if;
    if i_birth_address is null then
		if i_birth_address != v_birth_address then 	v_descreption  := v_descreption||'    birth_address "'||v_birth_address ||'" -->  "'||i_birth_address ||'" ';	end if;
    	i_birth_address := v_birth_address;
    end if;
   
     if i_filial_id is null then
      i_filial_id := v_filial_id;
     end if;
     if i_registration_address is null then
      if i_registration_address != v_registration_address then  v_descreption  := v_descreption||'  registration_address "'||v_registration_address ||'" -->  "'||i_registration_address ||'" ';	end if;
        i_registration_address := v_registration_address;
    end if;
    if i_authority is null then
       if i_authority != v_authority then v_descreption  := v_descreption||'   authority "'||v_authority ||'" -->  "'||i_authority ||'" ';end if;
        i_authority := v_authority;
    end if; 
    if i_doc_number is null then 
    
       if i_doc_number != v_doc_number then v_descreption  := v_descreption||'    doc_number "'||v_doc_number ||'" -->  "'||i_doc_number ||'" ';
       		end if;	i_doc_number := v_doc_number;
     end if;
    if i_doc_photo_url is null then 
       			i_doc_photo_url := v_doc_photo_url;
    end if;
    if i_self_photo  is null then 
       			i_self_photo  := v_self_photo;
    end if;
    if i_expiry_doc is null then 
      if i_expiry_doc != v_expiry_doc then   v_descreption  := v_descreption||'   expiry_doc "'||v_expiry_doc ||'" -->  "'||i_expiry_doc ||'" ';
       		end if;	 i_expiry_doc := v_expiry_doc;
    end if;
       	
   if i_birth_date is null then 
         i_birth_date := v_birth_date;
    end if;  	
      if i_doc_address_photo is null then 
         i_doc_address_photo := v_doc_address_photo;
    end if; 
   
     if i_oson_file is null then 
         i_oson_file := v_oson_file;
    end if;   
    if i_yandex_file is null then 
         i_yandex_file := v_yandex_file;
    end if; 
    if i_qiwi_file is null then 
         i_qiwi_file := v_qiwi_file;
    end if; 
   
   
   if i_info is null then 
         i_info := v_info;
    end if;  	
  	select    add_wallet_client_info_his(i_wallet_client_info_id=>i_id,i_info=>i_info ,i_descreption =>v_descreption,  i_user_id => i_user_id) into v_res;
  if v_res = false then 
  	   perform log_action_atx(i_id ||'', v_object_id,    'make history error edit_wallet_client_info', 'ERROR');
  end if;
	update ib_wallet_client_info 
			set  					
			first_name 				= i_first_name 				
			,surname 			= i_surname 			
			,last_name		= i_last_name		
			,birth_date 		= i_birth_date 		
			,doc_number  	= i_doc_number  	
			,nationality 		= i_nationality 		
			,gender				= i_gender				
			,birth_address 	= i_birth_address 		
			,expiry_doc 		= i_expiry_doc 		
			,authority 			= i_authority 			
			,registration_address		= i_registration_address		
			,doc_photo_url			= i_doc_photo_url			
			,mail_address	= i_mail_address	
			,self_photo 		= i_self_photo 		
			,state_id			= i_state_id			
			,client_id 			= i_client_id 	
			,info 				=i_info
			,region_id			 = i_region_id ,
			 created_doc_date = i_created_doc_date,
			modified_date =   now() ,
			 doc_address_photo= i_doc_address_photo,
					oson_file = i_oson_file,
				 yandex_file	=i_yandex_file,
				 qiwi_file= i_qiwi_file,
				 filial_id = i_filial_id
		where id = i_id ;
	
	return true;
	exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id ||'', v_object_id, v_err_text || 'edit_wallet_client_info', 'ERROR');
        return false;
END;
$$;

alter function edit_wallet_client_info(integer, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, integer, integer, varchar, integer, varchar, varchar, integer, varchar, varchar, varchar, varchar, integer) owner to interhub_user;

