create function get_wallet_monitoring(i_id bigint DEFAULT NULL::bigint, i_transact_date_from character varying DEFAULT NULL::character varying, i_transact_date_to character varying DEFAULT NULL::character varying, i_currency_id integer DEFAULT NULL::integer, i_commission_amount numeric DEFAULT NULL::bigint, i_state_id integer DEFAULT NULL::integer, i_transact_amount numeric DEFAULT NULL::bigint, i_owner_id integer DEFAULT NULL::integer, i_phone_number character varying DEFAULT NULL::character varying, i_agent_transaction_id character varying DEFAULT NULL::character varying) returns SETOF ib_wallet_transacts
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    rec         RECORD;
    v_ref_id    varchar;
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if; 
  if  i_agent_transaction_id is not null then 
		v_condition :=  v_condition ||  ' and t.agent_transaction_id  = '''|| i_agent_transaction_id || '''';
   end if;
  
  if i_phone_number is not null then 
  		v_condition :=  v_condition ||  ' and (t.source = '''|| i_phone_number || '''  or t.destination  =  '''|| i_phone_number ||''' )';
  end if;
    if i_transact_amount is not null then
        v_condition := v_condition || ' and t.transact_amount = ' || i_transact_amount;
    end if;
    if i_state_id is not null then
        v_condition := v_condition || ' and t.state_id = ' || i_state_id;
    end if;
    if i_owner_id is not null then
        v_condition := v_condition || ' and t.owner_id = ' || i_owner_id;
    end if;
    if i_transact_date_from is not null then
        v_condition := v_condition ||
                       ' and  t.created_date  >= to_date( ''' ||
                       i_transact_date_from || ''', ''dd.mm.yyyy'')';
    end if;
    if i_transact_date_to is not null then
        v_condition := v_condition ||
                       ' and  t.created_date  <= to_date( ''' ||
                       i_transact_date_to || ''', ''dd.mm.yyyy'')';
    end if;

    return query execute 'SELECT   	t.id,
									(select j.name  from ib_jur_wallet_childs j where j.id =  t."source"::integer  ) as source ,
									t.destination,
									t.payment_type,
									t.currency_id,
									t.commission_amount,
									t.state_id,
									t.transact_amount,
									t.created_date,
									t.owner_jur_id,
									t.modified_date,
									t.destination_amount,
									t.destination_currency_id,
									t.agent_transaction_id,
									t.info,
									t.params
                    FROM public.ib_wallet_transacts t where  payment_type =1 and t.state_id = 6 and  t.source != ''2'' ' || v_condition ||  ' order  by id desc ';

END;
$$;

alter function get_wallet_monitoring(bigint, varchar, varchar, integer, numeric, integer, numeric, integer, varchar, varchar) owner to interhub_user;

