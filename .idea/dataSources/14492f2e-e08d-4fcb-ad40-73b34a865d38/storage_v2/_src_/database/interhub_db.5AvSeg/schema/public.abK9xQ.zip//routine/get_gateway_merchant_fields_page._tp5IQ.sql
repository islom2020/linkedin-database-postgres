create function get_gateway_merchant_fields_page(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_ordered_by character varying DEFAULT NULL::character varying, i_is_desc character varying DEFAULT NULL::character varying, i_id integer DEFAULT NULL::integer, i_code character varying DEFAULT NULL::character varying, i_gateway_merch_id integer DEFAULT NULL::integer, i_merchant_field_id integer DEFAULT NULL::integer, i_parent_id integer DEFAULT NULL::integer, i_field_type character varying DEFAULT NULL::character varying, i_custom_type character varying DEFAULT NULL::character varying)
    returns TABLE(id integer, code character varying, description character varying, ordered integer, min_length integer, field_type character varying, is_required character varying, gateway_merch_id integer, max_length integer, regexp character varying, service_id integer, merchant_field_id integer, title character varying, example character varying, parent_id integer, custom_type character varying, count integer)
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    rec         RECORD;
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
     if i_service_merchant_field is not null then
        v_condition := v_condition || ' and t.merchant_field_id = ' || i_merchant_field_id;
    end if;
    if i_parent_id is not null then
        v_condition := v_condition || ' and t.parent_id = ' || i_parent_id;
    end if;
    if i_field_type  is not null then
        v_condition := v_condition || ' and  t.field_type = ''' || i_field_type || '''';
    end if;
      if i_custom_type  is not null then
        v_condition := v_condition || ' and  t.custom_type = ''' || i_custom_type || '''';
    end if;
    if i_code is not null then
        v_condition := v_condition || ' and  t.code = ' || i_code;
    end if; 
    return query execute 'select t.* , count(*) over() as count  
                            FROM ib_gateway_merchant_fields t  
                        where   1=1 ' || v_condition ||' order by  '||i_ordered_by||'     limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;

    IF NOT FOUND THEN
        perform log_action_atx(v_condition, 3, 'Данный не нaйден ид :' || 1, 'OK');
    END IF;
END;
$$;

alter function get_gateway_merchant_fields_page(integer, integer, varchar, varchar, integer, varchar, integer, integer, integer, varchar, varchar) owner to interhub_user;

