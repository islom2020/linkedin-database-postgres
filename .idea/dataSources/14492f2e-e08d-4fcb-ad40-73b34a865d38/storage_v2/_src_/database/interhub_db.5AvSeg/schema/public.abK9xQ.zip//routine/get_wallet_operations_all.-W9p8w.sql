create function get_wallet_operations_all(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_client_id integer DEFAULT NULL::integer, i_deposit_date_from character varying DEFAULT NULL::character varying, i_deposit_date_to character varying DEFAULT NULL::character varying, i_amount_from numeric DEFAULT NULL::numeric, i_amount_to numeric DEFAULT NULL::numeric, i_transact_type character varying DEFAULT NULL::character varying, i_source_currency_id integer DEFAULT NULL::integer, i_destination_currency_id integer DEFAULT NULL::integer, i_ordered_by character varying DEFAULT NULL::character varying, i_is_desc character varying DEFAULT NULL::character varying, i_group_id bigint DEFAULT NULL::bigint, i_client_account character varying DEFAULT NULL::character varying) returns SETOF ib_v_wallet_operations
    language plpgsql
as
$$
DECLARE
    v_transact_count integer := 0;
   v_total_amount numeric := 0;
    v_condition      varchar := '';
   v_client_type	integer;
begin  
	if i_transact_type is  not null and i_transact_type in ('W' ,  'P'   ) then
		v_condition  := v_condition  || ' and  t.transact_type  = '''||i_transact_type ||'''';
	end if;
	if i_client_account is  not null   then
			v_condition  := v_condition  || ' and  t.credit_account   = '''||i_client_account  ||''' or t.debit_account   = '''||i_client_account  ||'''';
	end if;
    
	/*if i_client_id    is not null then
	        v_condition := v_condition || ' and t.source_client_id  = ' || i_client_id || ' or t.destination_client_id  = '||i_client_id ;
    end if;
    */
   if i_ordered_by is   null then
          i_ordered_by := '1';
     end if;
	  if i_is_desc  ='Y' then
          i_ordered_by := i_ordered_by || ' desc ';
      end if;
     
   /* if i_client_id    is not null then
        v_condition := v_condition || ' and t.destination_client_id  = ' || i_client_id ;
    end if; */
        
    if i_group_id   is not null then
        v_condition := v_condition || ' and t.group_id  = ' || i_group_id;
    end if;
   
    if i_source_currency_id   is not null then
        v_condition := v_condition || ' and t.source_currency_id  = ' || i_source_currency_id;
    end if;
   
    if i_Destination_currency_id   is not null then
        v_condition := v_condition || ' and t.Destination_currency_id  = ' || i_Destination_currency_id;
    end if;
    if i_amount_from is not null then
        v_condition := v_condition || ' and t.debit_amount  >= ' || i_amount_from ;
    end if;
 
    if i_amount_to is not null then
        v_condition := v_condition || ' and t.debit_amount  <= ' || i_amount_to ;
    end if; 
    if i_deposit_date_from  is not null then
        v_condition := v_condition ||
                       ' and  t.deposit_date  >= to_date( ''' ||
                       i_deposit_date_from || ''', ''dd.mm.yyyy'')';
    end if;


   if i_deposit_date_to is not null then
        v_condition := v_condition ||
                       ' and  t.deposit_date  <= to_date( ''' ||
                       i_deposit_date_to || ''', ''dd.mm.yyyy'')';
    end if;


    EXECUTE 'select  count(*),  sum(t.debit_amount)  from ib_v_wallet_operations t where 1=1 ' || v_condition into v_transact_count,  v_total_amount;
    return query execute '
select t.group_id , 
	t.debit_amount,
	t.source_currency_id,	
	t.credit_amount,
	t.destination_currency_id,
	t.comission_amount,
	t.source_client_name,
	t.source_client_id,
	t.destination_client_name,
	t.destination_client_id ,
	t.credit_account,
	t.debit_account,
 	t.deposit_date,
	t.transact_type, ' || v_transact_count::integer || '  as count , '||v_total_amount
	||' as total_amount    from   ib_v_wallet_operations t where 1=1 ' || v_condition ||
                         'order by '||i_ordered_by||'    desc limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;

end ;
$$;

alter function get_wallet_operations_all(integer, integer, integer, varchar, varchar, numeric, numeric, varchar, integer, integer, varchar, varchar, bigint, varchar) owner to interhub_user;

