create function add_wallet_client_info_his(i_wallet_client_info_id integer, i_info character varying DEFAULT NULL::character varying, i_descreption character varying DEFAULT NULL::character varying, i_user_id integer DEFAULT NULL::integer) returns boolean
    language plpgsql
as
$$
declare 
v_err_text varchar ;
begin
 INSERT INTO public.ib_wallet_client_info_his
			(wallet_client_info_id, user_id,   description, info)
		VALUES(i_wallet_client_info_id, i_user_id,   i_descreption, i_user_id);
 return true;
 exception when others then 
 v_err_text :=  sqlerrm;	
 perform log_action_atx(i_wallet_client_info_id ||'', 5, v_err_text || 'add_wallet_client_info_his', 'ERROR');
   return false ;
   end;
$$;

alter function add_wallet_client_info_his(integer, varchar, varchar, integer) owner to interhub_user;

