create function write_log_transaction_atx(i_agent_id integer, i_client_account character varying, i_gateway_merchant_id integer, i_transact_date timestamp without time zone, i_gateway_transact_id character varying, i_params character varying, i_transact_amount bigint, i_merchant_id integer, i_agent_transact_id character varying) returns void
    language plpgsql
as
$$
DECLARE
    v_date   date    := now();
    v_user   integer := 2;
    v_ref_id integer;
BEGIN
    insert into ib_transact_logs (agent_id,
                                  client_account,
                                  gateway_merchant_id,
                                  transact_date,
                                  gateway_transact_id,
                                  params,
                                  transact_amount,
                                  merchant_id,
                                  agent_transact_id)
    values ( i_agent_id
           , i_client_account
           , i_gateway_merchant_id
           , i_transact_date
           , i_gateway_transact_id
           , i_params
           ,i_transact_amount
           , i_merchant_id
           , i_agent_transact_id);
exception
    when others then
        select max(id) into v_ref_id from ib_transact_logs;
        perform log_action_atx(v_ref_id || '', 7, sqlerrm ||'write_log_transaction', 'ERROR');
END;
$$;

alter function write_log_transaction_atx(integer, varchar, integer, timestamp, varchar, varchar, bigint, integer, varchar) owner to interhub_user;

