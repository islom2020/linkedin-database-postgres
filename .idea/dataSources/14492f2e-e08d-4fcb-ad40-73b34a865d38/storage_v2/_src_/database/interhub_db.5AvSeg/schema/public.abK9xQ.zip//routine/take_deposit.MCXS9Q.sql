create function take_deposit(i_client_id integer, i_dr_amount numeric, i_client_type_id integer, i_currency_id integer, i_group_id bigint, i_jur_id integer DEFAULT NULL::integer, i_commission_agent numeric DEFAULT 0) returns integer
    language plpgsql
as
$$
DECLARE
    v_over_balance   numeric  := 0;
    v_over_count     integer := 0;
    v_count          integer := 0 ;
    v_dep            bigint  := 0;
    v_res            boolean := false;
    v_currency_code  varchar := '';
    v_id_over        integer;
    v_differ_over    numeric;
    v_client_account ib_client_accounts%rowtype;
   v_client_account_comm_agent ib_client_accounts%rowtype;
BEGIN
	 if i_commission_agent >0  then 
	 	i_dr_amount := i_dr_amount + i_commission_agent  ; 
		   select t.*
	    into v_client_account_comm_agent
	    from ib_client_accounts t
	    where t.client_id = -1
	      and t.client_type_id = -2
	      and t.currency_id  = i_currency_id
	      and t.account_type_id = 1 
	      and t.condition = 'A' ;
	     
	  elsif i_commission_agent <0  then 
		  select t.*
		    into v_client_account_comm_agent
		    from ib_client_accounts t
		    where t.client_id = -1
		      and t.client_type_id = -3
		      and t.currency_id  = i_currency_id
		      and t.account_type_id = 1 
		      and t.condition = 'A' ;
	 end if;
	if i_commission_agent  !=  0  then 
	 v_client_account_comm_agent.balance := v_client_account_comm_agent.balance + i_commission_agent;
			    select  add_client_deposit(v_client_account_comm_agent.id, v_client_account_comm_agent.balance, i_commission_agent, 0, i_group_id) into v_res;
       if v_res = false then 
			raise 'agentdan pul ololmadi ';
        end if;
       
        update ib_client_accounts
        set balance = v_client_account_comm_agent.balance
        where  id =  v_client_account_comm_agent.id ;
	end if;
	
    select t.*
    into v_client_account
    from ib_client_accounts t
    where t.client_id = i_client_id
      and t.client_type_id = i_client_type_id
      and t.currency_id  = i_currency_id
      and t.account_type_id = i_client_type_id
      and coalesce (t.juridical_id,  i_jur_id) =  i_jur_id
      and t.condition = 'A' ;
     if not found then 
     	raise 'schot topilmadi' ;
     end if;
    -- check
    if v_client_account.is_overdraft = 'N' and v_client_account.balance < i_dr_amount then
        perform log_action_atx(i_client_id || '', 4, 'take_deposit  deposit puli yetarli emas', 'ERROR');
        return -1;
    end if;
   --------
    select count(*), sum(balance), max(id)
    into v_over_count , v_over_balance, v_id_over
    from ib_client_accounts t
    where t.account_type_id = 4
      and t.client_id = i_client_id
      and t.currency_id = i_currency_id
      and t.client_type_id = i_client_type_id  
      and coalesce (t.juridical_id,  i_jur_id) =  i_jur_id;
    --- 
    
     if v_client_account.is_overdraft = 'Y' and v_over_count = 0 then
        perform log_action_atx(i_client_id || '', 4, 'take_deposit  overdraft hisob raqami mavjud  emas', 'ERROR');
        return -1;
    elsif v_client_account.is_overdraft = 'Y' and v_over_count > 0 and
          (v_client_account.overdraft_amount + v_over_balance
              + v_client_account.balance) < i_dr_amount then
        perform log_action_atx(i_client_id || '', 4, 'take_deposit  overdrafti va depositidagi puli  yetarli emas',
                               'ERROR');
        return -1;
    end if;
-----

    if (v_client_account.is_overdraft = 'Y' and (v_client_account.balance - i_dr_amount) >= 0) or
       (v_client_account.is_overdraft = 'N' and
        v_client_account.balance >= i_dr_amount)
    then

        v_client_account.balance := v_client_account.balance - i_dr_amount;
       
         select  add_client_deposit(v_client_account.id, v_client_account.balance, i_dr_amount, 0, i_group_id) into v_res;

       if v_res = false then 
			raise 'agentdan pul ololmadi ';
        end if;
       
        update ib_client_accounts
        set balance = v_client_account.balance
        where client_id = i_client_id
        and currency_id  = i_currency_id
          and client_type_id = i_client_type_id
          and account_type_id = i_client_type_id
      and coalesce (juridical_id,  i_jur_id) =  i_jur_id;

    elsif v_client_account.is_overdraft = 'Y' and (v_client_account.balance - i_dr_amount) < 0 and v_over_count > 0 and
          v_over_balance is not null and
          (v_client_account.overdraft_amount + v_over_balance
              + v_client_account.balance) >= i_dr_amount then
              -------
        v_differ_over := i_dr_amount - v_client_account.balance;

        v_over_balance := v_over_balance - v_differ_over;
       
       select  add_client_deposit(v_id_over, v_over_balance, v_differ_over, 0, i_group_id)
       		into v_res;
        if v_res = false then 
			raise 'overdraft agentdan ololmadi ';
        end if;
       
        update ib_client_accounts t
        set balance = v_over_balance
        where t.account_type_id = 4
        and t.currency_id  = i_currency_id
          and t.client_id = i_client_id
          and t.client_type_id = i_client_type_id
      and coalesce (juridical_id,  i_jur_id) =  i_jur_id
        returning id into v_id_over;

     /*  v_client_account.balance := v_client_account.balance + v_differ_over;
       ---------
        update ib_client_accounts
        set balance = v_client_account.balance
        where client_id = i_client_id
        	and currency_id = i_currency_id
          and client_type_id = i_client_type_id
          and account_type_id = i_client_type_id;
        ------ 
         select add_client_deposit(v_client_account.id, v_client_account.balance, 0, v_differ_over, i_group_id)
        	into v_res ;
         if v_res = false then 
			raise 'overdraftni tuldira olmadi ';
         end if;
        v_client_account.balance := v_client_account.balance - i_dr_amount;
       -------- 
      
        select  * from add_client_deposit(v_client_account.id, v_client_account.balance, i_dr_amount, 0, i_group_id)
       		into v_res;
        if v_res = false then 
			raise 'overdraftdan ololmadi';
        end if;
       ---------------
 		update ib_client_accounts
        set balance = v_client_account.balance
        where client_id = i_client_id
        and currency_id  = i_currency_id
          and client_type_id = i_client_type_id
          and account_type_id = i_client_type_id
          and condition = 'A';*/
		------
	else	
		raise ' overdraftida puli qolmagan yoki kutilmagan xatolik ';
    end if;

    return 1;
exception
    when others then
        perform log_action_atx(i_group_id || '', 4, sqlerrm || 'take_deposit', 'ERROR');
        return -1;

END;
$$;

alter function take_deposit(integer, numeric, integer, integer, bigint, integer, numeric) owner to interhub_user;

