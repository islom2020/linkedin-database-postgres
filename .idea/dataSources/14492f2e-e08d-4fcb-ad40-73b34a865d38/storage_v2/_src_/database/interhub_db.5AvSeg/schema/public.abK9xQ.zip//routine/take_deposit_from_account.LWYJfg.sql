create function take_deposit_from_account(i_from_client_account character varying, i_transact_amount numeric, i_group_id bigint) returns integer
    language plpgsql
as
$$
DECLARE
    v_res boolean;
    v_client_account ib_client_accounts%rowtype;
BEGIN

    select t.*
    into v_client_account
    from ib_client_accounts t
    where t.client_account  = i_from_client_account 
      and t.condition = 'A' for update;
     if not found then 
     	raise  ;
     end if;
       if 
        v_client_account.balance < i_transact_amount then 
        	raise 'pul mablagi yetarli emas ';
        end if;
        v_client_account.balance := v_client_account.balance - i_transact_amount;
       
         select  add_client_deposit(v_client_account.id, v_client_account.balance, i_transact_amount, 0, i_group_id) into v_res;

       if v_res = false then 
			raise;
        end if;
       
        update ib_client_accounts
        set balance = v_client_account.balance
        where id  = v_Client_account.id;
 

    return 1;
exception
    when others then
        perform log_action_atx(i_from_Client_account || '', 4, sqlerrm || 'take_deposit', 'ERROR');
        return -1;

END;
$$;

alter function take_deposit_from_account(varchar, numeric, bigint) owner to interhub_user;

