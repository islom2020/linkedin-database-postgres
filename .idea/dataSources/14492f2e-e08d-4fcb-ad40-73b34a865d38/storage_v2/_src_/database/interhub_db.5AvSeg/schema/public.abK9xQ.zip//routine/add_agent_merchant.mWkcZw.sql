create function add_agent_merchant(i_agent_id integer, i_merchant_id integer, i_commission_down numeric, i_commission_to_agent numeric, i_commission_from_agent numeric, i_currency_id integer, i_min_amount numeric DEFAULT 0, i_max_amount numeric DEFAULT 0, i_state_id integer DEFAULT 1, i_is_main character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_created_by         integer := 1;
    v_object_id constant integer := 1;
BEGIN
    insert into ib_agent_merchant ( agent_id
                                  , merchant_id
                                  , commission_down
                                  , commission_to_agent
                                  , commission_from_agent
                                  , currency_id
                                  ,min_amount 
                                  ,max_amount,state_id,  is_main )
    values (i_agent_id, i_merchant_id, i_commission_down, i_commission_to_agent, i_commission_from_agent, i_currency_id,i_min_amount,i_max_amount,i_state_id,i_is_main);
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        select max(id) into v_reference_id from ib_agent_merchant;
        perform log_action_atx(v_reference_id + 1 || '', v_object_id, v_err_text ||' add_agent_merchant ', 'ERROR');
        return false;
END;
$$;

alter function add_agent_merchant(integer, integer, numeric, numeric, numeric, integer, numeric, numeric, integer, varchar) owner to interhub_user;

