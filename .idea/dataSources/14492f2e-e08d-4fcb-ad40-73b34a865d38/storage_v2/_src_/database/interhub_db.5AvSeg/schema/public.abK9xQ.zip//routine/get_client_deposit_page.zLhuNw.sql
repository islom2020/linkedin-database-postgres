create function get_client_deposit_page(i_account_id integer, i_page integer DEFAULT 1, i_page_count integer DEFAULT 20)
    returns TABLE(id integer, account_id integer, debit_amount numeric, credit_amount numeric, balance numeric, group_id bigint, deposit_date timestamp without time zone, count integer)
    language plpgsql
as
$$
DECLARE
    v_condition     varchar := '';
    v_currency_code varchar := '';
    v_Count integer :=0 ;
begin
    select count(*) into v_Count from ib_client_deposit  t  where t.account_id = i_account_id ;
    return query SELECT t.id   ,
                        t.account_id   ,
                        t.debit_amount   ,
                        t.credit_amount   ,
                        t.balance   ,
                        t.group_id  ,
                        t.deposit_date  ,  v_Count as count   from ib_client_deposit t where t.account_id = i_account_id  order by 1 desc  limit i_page_count
                     offset     (i_page - 1) * i_page_count;
end;
$$;

alter function get_client_deposit_page(integer, integer, integer) owner to interhub_user;

