create function get_wallet_transact_pagenation(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_id bigint DEFAULT NULL::bigint, i_payment_type integer DEFAULT NULL::integer, i_transact_date_from character varying DEFAULT NULL::character varying, i_transact_date_to character varying DEFAULT NULL::character varying, i_currency_id integer DEFAULT NULL::integer, i_commission_amount numeric DEFAULT NULL::bigint, i_state_id integer DEFAULT NULL::integer, i_transact_amount numeric DEFAULT NULL::bigint, i_agent_id integer DEFAULT NULL::integer, i_phone_number character varying DEFAULT NULL::character varying, i_merchant_id integer DEFAULT NULL::integer, i_ordered_by character varying DEFAULT NULL::character varying, i_is_desc character varying DEFAULT NULL::character varying, i_agent_transaction_id character varying DEFAULT NULL::character varying) returns SETOF ib_v_wallet_transacts
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    rec         RECORD;
    v_ref_id    varchar;
   v_transact_count integer;
v_transact_amount   numeric;
  BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_payment_type is not null then
        v_condition := v_condition || ' and t.payment_type = ' || i_payment_type;
    end if;
 	if i_ordered_by is   null then
          i_ordered_by := '1';
         
     end if;
	  if i_is_desc  ='Y' then
          i_ordered_by := i_ordered_by || ' desc ';
      end if;
    if i_transact_amount is not null then
        v_condition := v_condition || ' and t.transact_amount = ' || i_transact_amount;
    end if;
    if i_state_id is not null then
        v_condition := v_condition || ' and t.state_id = ' || i_state_id;
    end if; 
   if  i_Agent_id is not null then 
		v_condition :=  v_condition ||  ' and t.source = '''|| i_agent_id || '''';
   end if;
  
   if  i_agent_transaction_id is not null then 
		v_condition :=  v_condition ||  ' and t.agent_transaction_id = '''|| i_agent_transaction_id || '''';
   end if;
  

    if  i_merchant_id is not null then 
		v_condition :=  v_condition ||  ' and t.destination  = '''|| i_merchant_id || '''';
   end if;

  if i_phone_number is not null then 
  		v_condition :=  v_condition ||  ' and (t.source = '''|| i_phone_number || '''  or t.destination  =  '''|| i_phone_number ||''' )';
  end if;
 /*   if i_transact_date_from is not null then
        v_condition := v_condition ||
                       ' and  t.created_date  >= to_date( ''' ||
                       i_transact_date_from || ''', ''dd.mm.yyyy'')';
    end if;
    if i_transact_date_to is not null then
        v_condition := v_condition ||
                       ' and  t.created_date  <= to_date( ''' ||
                       i_transact_date_to || ''', ''dd.mm.yyyy'')';
    end if;
   */
   if i_transact_date_from is not null then
   
        v_condition := v_condition ||
                       ' and  t.created_date  >= to_date( ''' ||
                       i_transact_date_from || ''', ''dd.mm.yyyy'')';
    end if;
    if i_transact_date_to is not null then
     	SELECT to_char(to_date(i_transact_date_to, 'dd.mm.yyyy'::text) + INTERVAL ' 1 day' ,'dd.mm.yyyy') into 		i_transact_date_to ;  
        v_condition := v_condition ||
                       ' and  t.created_date  < to_date( ''' ||
                       i_transact_date_to || ''', ''dd.mm.yyyy'')';
    end if;
	
   
	 EXECUTE 'select  count(*) ,  sum(t.transact_amount) from ib_v_wallet_transacts t where 1=1 ' || v_condition into v_transact_count,  v_transact_amount;
    return query execute 'SELECT    t.id                       
									,t.currency_id       
									,t.currency_name     
									,t.source                   
									,t.source_client_name       
									,t.transact_amount          
									,t.destination_currency_id  
									,t.destination_currency_name
									,t.destination              
									,t.destination_client_name  
									,t.destination_amount       
									,t.created_date             
									,t.commission_amount        
									,t.state_name               
									,t.type_name                
									,t.payment_type             
									,t.state_id,
									t.agent_transaction_id ,' || v_transact_count || ' as count,
						' ||  v_transact_amount || ' as total_amount     from 
                    ib_v_wallet_transacts t where 1 = 1 ' || v_condition || 
                   	' order by  '||i_ordered_by||'   limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;

END;
$$;

alter function get_wallet_transact_pagenation(integer, integer, bigint, integer, varchar, varchar, integer, numeric, integer, numeric, integer, varchar, integer, varchar, varchar, varchar) owner to interhub_user;

