create function get_transacts(i_id bigint DEFAULT NULL::bigint, i_client_account character varying DEFAULT NULL::character varying, i_merchant_id integer DEFAULT NULL::integer, i_agent_id integer DEFAULT NULL::integer, i_state_id integer DEFAULT NULL::integer, i_gateway_merchant_id integer DEFAULT NULL::integer, i_agent_transact_id character varying DEFAULT NULL::character varying, i_transact_amount bigint DEFAULT NULL::bigint) returns SETOF ib_transacts
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    rec         RECORD;
    v_ref_id    varchar;
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_agent_id is not null then
        v_condition := v_condition || ' and  t.agent_id = ' || i_agent_id;
    end if;
    if i_client_account is not null then
        v_condition := v_condition || ' and  t.client_account = ' || i_client_account;
    end if;
    if i_merchant_id is not null then
        v_condition := v_condition || ' and t.merchant_id = ' || i_merchant_id;
    end if;
    if i_gateway_merchant_id is not null then
        v_condition := v_condition || ' and t.gateway_merchant_id  = ' || i_gateway_merchant_id;
    end if;
    if i_agent_transact_id is not null then
        v_condition := v_condition || ' and t.agent_transact_id = ''' || i_agent_transact_id||'''';
    end if;
    if i_transact_amount is not null then
        v_condition := v_condition || ' and t.transact_amount = ' || i_transact_amount;
    end if;
    if i_state_id is not null then
        v_condition := v_condition || ' and t.state_id = ' || i_state_id;
    end if;

    return query execute 'SELECT    t.*
                    FROM public.ib_transacts t where 1 = 1 ' || v_condition;

    IF NOT FOUND THEN
        if i_id is not null then
            v_ref_id := i_id;
        elsif i_client_account is not null then
            v_ref_id := i_client_account;
        end if;
    END IF;
END;
$$;

alter function get_transacts(bigint, varchar, integer, integer, integer, integer, varchar, bigint) owner to interhub_user;

