create function calculate_custom_exchange(i_gateway_merchant_id integer, i_agent_merchant_id integer, i_amount numeric) returns numeric
    language plpgsql
as
$$
declare
	v_amount numeric;
v_agent_merchant ib_agent_merchant%rowtype ;
v_gateway_merchant  ib_gateway_merchants%rowtype;
v_currency_id  integer ;
begin
	select
		*   
	into
		v_gateway_merchant 
	from
		ib_gateway_merchants  t
	where
		t.id = i_gateway_merchant_id;
	if not found then 
		 perform log_action_atx(i_gateway_merchant_id||'', 1, 'not found  :calculate_custom_exchange ' || 1, 'OK');
		return -1 ;
	end if;
	
		select
		t.* 
	into
		v_agent_merchant 
	from
		ib_agent_merchant  t,  ib_agents a 
	where
		t.id = i_agent_merchant_id and a.id = t.agent_id ;
	if not found then 
		 perform log_action_atx(i_agent_id||'', 1, 'not found  :calculate_custom_exchange ' || 1, 'OK');
		return -1 ;
	end if;
	select
		currency_id into v_currency_id
	from
		ib_agents t
	where
		t.id = v_agent_merchant.agent_id;
	if not found then 
		 perform log_action_atx(i_agent_id||'', 1, 'not found  :calculate_custom_exchange ' || 1, 'OK');
		return -1 ;
	end if;
	
   if  v_agent_merchant.commission_down > 0  or  v_gateway_merchant.commission_down >0 then
        v_amount :=  trunc( i_amount*100/(100-v_agent_merchant.commission_down  - v_gateway_merchant.commission_down),  2 );
    else 
    	v_amount := i_amount;
    end if;

 	select
	 t.amount* v_amount  
	 into
		v_amount
	from
		ib_S_currency_exchanges t
	where
		t.from_Currency_id = v_gateway_merchant.currency_id
		and t.to_currency_id = v_currency_id
	limit 1;

return v_amount ;
exception when others then 
        perform log_action_atx(i_gateway_merchant_id||'', 1, 'oshibka :calculate_custom_exchange ' || 1, 'OK');
return -1;
end;

$$;

alter function calculate_custom_exchange(integer, integer, numeric) owner to interhub_user;

