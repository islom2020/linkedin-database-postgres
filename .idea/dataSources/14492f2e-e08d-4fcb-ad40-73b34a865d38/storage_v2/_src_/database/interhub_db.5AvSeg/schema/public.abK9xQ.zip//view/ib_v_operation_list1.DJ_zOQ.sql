create view ib_v_operation_list1
            (group_id, debit_amount, source_currency_id, credit_amount, destination_currency_id, comission_amount,
             source_client_name, source_client_id, destination_client_name, destination_client_id, credit_account,
             debit_account, deposit_date, transact_type, count, total_amount)
as
SELECT a.id                 AS group_id,
       a.transact_amount    AS debit_amount,
       ag.currency_id       AS source_currency_id,
       a.amount_in_currency AS credit_amount,
       g.currency_id        AS destination_currency_id,
       a.commission_amount  AS comission_amount,
       ag.name              AS source_client_name,
       ag.client_id         AS source_client_id,
       g.name               AS destination_client_name,
       g.client_id          AS destination_client_id,
       (SELECT f.client_account
        FROM ib_client_accounts f
        WHERE f.client_id = ag.client_id
          AND f.client_type_id = 2
          AND f.account_type_id = 2
        LIMIT 1)            AS credit_account,
       (SELECT f.client_account
        FROM ib_client_accounts f
        WHERE f.client_id = g.client_id
          AND f.client_type_id = 3
          AND f.account_type_id = 3
        LIMIT 1)            AS debit_account,
       a.transact_date      AS deposit_date,
       'P'::text            AS transact_type,
       1                    AS count,
       1::numeric           AS total_amount
FROM ib_transacts a,
     ib_agents ag,
     ib_gateway_merchants m,
     ib_gateways g
WHERE a.gateway_merchant_id = m.id
  AND a.agent_id = ag.id
  AND g.id = m.gateway_id
  AND a.destination_currency_id = m.currency_id
  AND a.state_id = 6;

alter table ib_v_operation_list1
    owner to interhub_user;

