create function write_log_protocol(i_reference_id integer, i_log_text character varying, i_object_id integer, i_modified_by integer, i_info character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_date date    := now();
   v_err_text	varchar;
    v_user integer := 2;
BEGIN
    insert into ib_log_protocols (reference_id, object_id, log_text,  modified_by, info)
    values (i_reference_id, i_object_id, i_log_text,  i_modified_by, i_info);
   return true;
exception when others then 
	 v_err_text := sqlerrm;
        perform log_action_atx(i_reference_id || '', i_object_id, v_err_text, 'ERROR');
        return false;
END;
$$;

alter function write_log_protocol(integer, varchar, integer, integer, varchar) owner to interhub_user;

