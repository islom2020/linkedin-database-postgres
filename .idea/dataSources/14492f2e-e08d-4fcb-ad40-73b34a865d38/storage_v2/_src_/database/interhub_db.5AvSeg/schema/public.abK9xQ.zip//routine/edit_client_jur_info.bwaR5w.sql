create function edit_client_jur_info(i_client_id integer, i_trade_mark character varying DEFAULT NULL::character varying, i_juridical_name character varying DEFAULT NULL::character varying, i_type_juridical character varying DEFAULT NULL::character varying, i_jur_inn character varying DEFAULT NULL::character varying, i_postal_code character varying DEFAULT NULL::character varying, i_oked character varying DEFAULT NULL::character varying, i_country_id integer DEFAULT NULL::integer, i_city character varying DEFAULT NULL::character varying, i_region character varying DEFAULT NULL::character varying, i_address character varying DEFAULT NULL::character varying, i_account_number character varying DEFAULT NULL::character varying, i_filial_code character varying DEFAULT NULL::character varying, i_phone_number character varying DEFAULT NULL::character varying, i_email_for_info character varying DEFAULT NULL::character varying, i_email_for_lead character varying DEFAULT NULL::character varying, i_email_for_doc character varying DEFAULT NULL::character varying, i_name_manager character varying DEFAULT NULL::character varying, i_birth_date character varying DEFAULT NULL::character varying, i_nationality character varying DEFAULT NULL::character varying, i_info_person character varying DEFAULT NULL::character varying, i_person_phone_number character varying DEFAULT NULL::character varying, i_created_by integer DEFAULT NULL::integer, i_tax_code character varying DEFAULT NULL::character varying, i_counter_agent_type integer DEFAULT NULL::integer, i_description character varying DEFAULT NULL::character varying, i_logo_url character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 5;
    v_first_name varchar ;		
v_trade_mark varchar                   ;
	v_juridical_name varchar               ;
	v_type_juridical varchar                ;
	v_jur_inn varchar                          ;
	v_postal_code varchar                  ;
	v_oked varchar                            ;
	v_country_id int4                          ;
	v_city varchar                              ;
	v_region varchar                           ;
	v_address varchar                        ;
	v_account_number varchar           ;
	v_filial_code varchar                     ;
	v_phone_number varchar              ;
	v_email_for_info varchar               ;
	v_email_for_lead varchar              ;
	v_email_for_doc varchar               ;
	v_name_manager varchar             ;
	v_birth_date varchar                          ;
	v_nationality varchar                     ;
	v_info_person varchar                   ;
	v_person_phone_number varchar   ;
	v_created_by int4                         ;
	v_tax_code varchar                      ;
v_logo_url varchar ;
 v_counter_agent_type integer;
v_description varchar ;
begin
	 select   				
			trade_mark                       
			,juridical_name                   
			,type_juridical                    
			,jur_inn                              
			,postal_code                      
			,oked                                
			,country_id							
			,city                                  
			,region                               
			,address                            
			,account_number               
			,filial_code                         
			,phone_number                  
			,email_for_info                   
			,email_for_lead                  
			,email_for_doc                   
			,name_manager                 
			,birth_date							
			,nationality                         
			,info_person                       
			,person_phone_number       
			,created_by 						
			,tax_code     
			,counter_agent_type
			,description
			, logo_url
			into  					
				v_trade_mark                    ,   
				v_juridical_name                ,   
				v_type_juridical                 ,   
				v_jur_inn                           ,   
				v_postal_code                   ,   
				v_oked                             ,   
				v_country_id						,	
				v_city                               ,   
				v_region                            ,   
				v_address                         ,   
				v_account_number            ,   
				v_filial_code                      ,   
				v_phone_number               ,   
				v_email_for_info                ,   
				v_email_for_lead               ,   
				v_email_for_doc                ,   
				v_name_manager              ,   
				v_birth_date						,	
				v_nationality                      ,   
				v_info_person                    ,   
				v_person_phone_number    ,   
				v_created_by 					,	
				v_tax_code    ,
				v_counter_agent_type,
				v_description,
				v_logo_url

from ib_client_jur_info    t where client_id =  i_client_id ;
       if i_email_for_lead is null then
       		 i_email_for_lead := v_email_for_lead;
    	end if;
       if i_email_for_doc is null then
       		 i_email_for_doc := v_email_for_doc;
    	end if;  
    	if i_logo_url is null then
       		 i_logo_url := v_logo_url;
    	end if;
     if i_description is null then
       		 i_description := v_description;
    	end if;
     if i_counter_agent_type is null then
       		 i_counter_agent_type := v_counter_agent_type;
    	end if;
       if i_name_manager is null then
       		 i_name_manager := v_name_manager;
    	end if;
       if i_birth_date is null then
       		 i_birth_date := v_birth_date;
    	end if;
       if i_nationality is null then
       		 i_nationality := v_nationality;
    	end if;
       if i_info_person is null then
       		 i_info_person := v_info_person;
    	end if;
       if i_person_phone_number is null then
       		 i_person_phone_number := v_person_phone_number;
    	end if;
       if i_created_by is null then
       		 i_created_by := v_created_by;
    	end if;
       if i_info_person is null then
       		 i_info_person := v_info_person;
    	end if;
       if i_tax_code is null then
       		 i_tax_code := v_tax_code;
    	end if;
    
       if i_trade_mark is null then
       		 i_trade_mark := v_trade_mark;
    	end if;
       if i_juridical_name is null then
       		 i_juridical_name := v_juridical_name;
    	end if;
       if i_type_juridical is null then
       		 i_type_juridical := v_type_juridical;
    	end if;
       if i_jur_inn is null then
       		 i_jur_inn := v_jur_inn;
    	end if;
       if i_postal_code is null then
       		i_postal_code := v_postal_code;
    	end if;
       if i_oked is null then
       		 i_oked := v_oked;
    	end if;
       if i_country_id is null then
       		 i_country_id := v_country_id;
    	end if;
       if i_city is null then
       		 i_city := v_city;
    	end if;
       if i_region is null then
       		 i_region := v_region;
    	end if;
       if i_address is null then
       		 i_address := v_address;
    	end if;
       if i_account_number is null then
       		 i_account_number := v_account_number;
    	end if;
       if i_filial_code is null then
       		 i_filial_code := v_filial_code;
    	end if;
       if i_phone_number is null then
       		 i_phone_number := v_phone_number;
    	end if;
       if i_email_for_info is null then
       		 i_email_for_info := v_email_for_info;
    	end if;
	update ib_client_jur_info 
			set  					
			trade_mark                 =  i_trade_mark                    ,   
			juridical_name             =  i_juridical_name                ,  
			type_juridical              =  i_type_juridical                 ,    
			jur_inn                        =  i_jur_inn                           ,   
			postal_code                =  i_postal_code                   ,   
			oked                          =  i_oked                             ,    
			country_id					=	i_country_id						,	
			city                            =  i_city                               ,   
			region                         =  i_region                            ,  
			address                      =  i_address                         ,   
			account_number         =  i_account_number            ,    
			filial_code                   =  i_filial_code                      ,   
			phone_number            =  i_phone_number               ,   
			email_for_info             =  i_email_for_info                ,   
			email_for_lead            =  i_email_for_lead               ,    
			email_for_doc             =  i_email_for_doc                ,   
			name_manager           =  i_name_manager              ,   
			birth_date					=	i_birth_date						,	
			nationality                   =  i_nationality                      ,  
			info_person                 =  i_info_person                    ,  
			person_phone_number =  i_person_phone_number    ,  
			created_by 				=	i_created_by 					,	
			tax_code                    =  i_tax_code    ,                  
			counter_agent_type 		=i_counter_agent_type,
			description= i_description,
			logo_url= i_logo_url
		where client_id = i_client_id ;
	
	return true;
	exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_client_id ||'', v_object_id, v_err_text || 'edit_client_jur_info', 'ERROR');
        return false;
END;
$$;

alter function edit_client_jur_info(integer, varchar, varchar, varchar, varchar, varchar, varchar, integer, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, integer, varchar, integer, varchar, varchar) owner to interhub_user;

