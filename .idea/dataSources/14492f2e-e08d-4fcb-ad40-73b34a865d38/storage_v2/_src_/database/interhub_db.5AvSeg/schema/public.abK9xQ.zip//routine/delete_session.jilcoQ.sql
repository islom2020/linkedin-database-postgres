create function delete_session(i_session_id character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
    v_condition varchar := '';
BEGIN
   delete from ib_sessions  where session_id = i_session_id;
    return true;
exception
    when others then
        perform log_action_atx(i_session_id || '', 2, 'Данный не нфйден ид : delete_sessions' || v_condition, 'OK');
        return  false;
END;
$$;

alter function delete_session(varchar) owner to interhub_user;

