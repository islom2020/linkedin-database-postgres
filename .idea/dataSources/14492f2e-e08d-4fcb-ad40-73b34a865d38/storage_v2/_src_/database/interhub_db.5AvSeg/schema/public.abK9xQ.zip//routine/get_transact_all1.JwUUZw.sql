create function get_transact_all1(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_id bigint DEFAULT NULL::bigint, i_merchant_id integer DEFAULT NULL::integer, i_transact_date_from character varying DEFAULT to_char(now(), 'dd.mm.yyyy'::text), i_transact_date_to character varying DEFAULT NULL::character varying, i_agent_id integer DEFAULT NULL::integer, i_state_id integer DEFAULT NULL::integer, i_gateway_id integer DEFAULT NULL::integer, i_client_account character varying DEFAULT NULL::character varying, i_agent_transact_id character varying DEFAULT NULL::character varying, i_gateway_merchant_id integer DEFAULT NULL::integer, i_gateway_transact_id character varying DEFAULT NULL::character varying, i_tran_type integer DEFAULT NULL::integer) returns SETOF ib_v_transacts
    language plpgsql
as
$$
DECLARE
    v_transact_count integer := 0;
    v_condition      varchar := '';
   r record;
   v_gateway_condition varchar := '';
  v_transact_amount 	numeric;
begin
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_merchant_id is not null then
        v_condition := v_condition || ' and t.merchant_id  = ' || i_merchant_id;
    end if;
    if i_gateway_merchant_id  is not null then
        v_condition := v_condition || ' and t.gateway_merchant_id  = ' || i_gateway_merchant_id;
    end if;
   
    if i_gateway_id is not null then
    for r in (
        select s.id from ib_gateway_merchants  s where s.gateway_id  = i_gateway_id ) 
    	loop 
        	 v_gateway_condition := v_gateway_condition ||  r.id ||' ,';
       end loop;
     if v_gateway_condition != '' then 
      v_gateway_condition :=  substring (v_gateway_condition ,  1, length(v_gateway_condition) -1); 
     v_condition := v_condition || ' and t.gateway_merchant_id  in ( ' ||v_gateway_condition|| ' )';
    else 
    	 v_condition := v_condition || ' and t.gateway_id  = ' || i_gateway_id;
     end if;
    
    end if;
    if i_tran_type is not null then
        v_condition := v_condition || ' and t.tran_type  = ' || i_tran_type;
    end if;
    if i_agent_id is not null then
        v_condition := v_condition || ' and t.agent_id  = ' || i_agent_id;
    end if;
    if i_state_id is not null then
        v_condition := v_condition || ' and t.state_id  = ' || i_state_id;
    end if;
    if i_agent_transact_id is not null then
        v_condition := v_condition || ' and t.agent_transact_id  = ''' || i_agent_transact_id || '''';
    end if;
     if i_gateway_transact_id  is not null then
        v_condition := v_condition || ' and t.gateway_transact_id   = ''' || i_gateway_transact_id  || '''';
    end if;
    if i_client_account is not null then
        v_condition := v_condition || 'and lower(t.client_account) like ''%' ||
                       lower(i_client_account) || '%' || '''';
    end if;
    if i_transact_date_from is not null and i_transact_date_to is not null  then
        v_condition := v_condition ||
                       ' and  t.transact_date between  to_date( ''' ||
                       i_transact_date_from || ''', ''dd.mm.yyyy'') and   to_date( ''' ||
                       i_transact_date_to || ''', ''dd.mm.yyyy'')';
     
    end if;


    EXECUTE 'select  count(*) , sum(transact_amount) from ib_transacts t where 1=1 ' || v_condition into v_transact_count, v_transact_amount ;
    return query execute '
select t.id, 
       t.client_account, 
       t.transact_date,
       t.agent_transact_id,
       t.gateway_transact_id, 
       t.commission_amount,
           t.currency_id,
       t.created_date,
       t.transact_amount,
       t.currency_id :: varchar as currency_code ,
       t.amount_in_currency,
       t.amount_out_currency,
       t.info, 
       c.name currency_name,
       ( select a.name from ib_agents  a where a.id  = t.agent_id)as agent_name  , 
       m.name merchant_name, 
       m.name as category_name,
       (select o.name  from ib_object_states o   where o.id  = t.state_id and o.object_id = 7) as state_name,
       g.name as gateway_merchant_name, 
       (SELECT gt.name
        FROM ib_gateways gt
        WHERE gt.id = g.gateway_id) AS gateway_name, 
		tran_type ,   ' || v_transact_count::integer || '   as count, '||
				v_transact_amount || ' as total_amount    from   ib_currencies c ,ib_transacts t
                          LEFT JOIN ib_merchants m ON m.id = t.merchant_id
                          LEFT JOIN ib_gateway_merchants g ON g.id = t.gateway_merchant_id
        where  c.id  = t.currency_id ' || v_condition ||
                         'order by 1 desc limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;

end ;
$$;

alter function get_transact_all1(integer, integer, bigint, integer, varchar, varchar, integer, integer, integer, varchar, varchar, integer, varchar, integer) owner to interhub_user;

