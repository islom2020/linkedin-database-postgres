create function edit_category(i_id integer, i_name character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_created_by         integer := 1;
    v_object_id constant integer := 2;
    v_name               varchar(300);
BEGIN
    select id, name
    into
        v_reference_id, v_name
    from ib_categories
    where id = i_id;
    if not found then
        v_err_text := 'takaya id ne nayden ';
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
    end if;

    if i_name is null then
        i_name := v_name;
    end if;

    update ib_categories
    set name = i_name
    where id = i_id;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
END;
$$;

alter function edit_category(integer, varchar) owner to interhub_user;

