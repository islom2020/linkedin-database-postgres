create function get_object_states(i_id integer DEFAULT NULL::integer, i_object_id integer DEFAULT NULL::integer, i_name character varying DEFAULT NULL::character varying, i_condition character varying DEFAULT NULL::character varying) returns SETOF ib_object_states
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
    v_condition varchar := '';
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_name is not null then
        v_condition := v_condition || 'and lower(t.name) like ''%' || lower(i_name) || '%' || '''';
    end if;
    if i_condition is not null then
        v_condition := v_condition || 'and lower(t.condition) like ''%' || lower(i_condition) || '%' || '''';
    end if;
    if i_object_id is not null then
        v_condition := v_condition || ' and  t.object_id = ' || i_object_id;
    end if;
    RETURN QUERY
        execute 'SELECT * FROM ib_object_states t  WHERE  1= 1 ' || v_condition;
    IF NOT FOUND THEN
        perform log_action_atx(v_condition, 2, 'Обжек статус ид  Данный не найден : ' || v_condition, 'ERROR');
    END IF;
END;
$$;

alter function get_object_states(integer, integer, varchar, varchar) owner to interhub_user;

