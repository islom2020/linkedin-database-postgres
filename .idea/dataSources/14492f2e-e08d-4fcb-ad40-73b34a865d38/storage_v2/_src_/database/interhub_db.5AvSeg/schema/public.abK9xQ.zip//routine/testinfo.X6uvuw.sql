create function testinfo() returns void
    language plpgsql
as
$$
declare
  id                bigint;
 r record;
begin

	for r in (select t.id ,  t.info from ib_transacts_2020_09 t where length(t.info ) >100 and not exists(select 1 from 
		ib_transacts_info c where c.transact_id =  t.id ) )
		loop 
			insert into ib_transacts_info (transact_id , info) values (r.id,  r.info );
			update  ib_transacts_2020_08 x set info = '' where x.id =  r.id ;
		end loop;
	exception when others then 
		  perform log_action_atx( 'erro ',5, sqlerrm, 'ERROR');
	end;
$$;

alter function testinfo() owner to interhub_user;

