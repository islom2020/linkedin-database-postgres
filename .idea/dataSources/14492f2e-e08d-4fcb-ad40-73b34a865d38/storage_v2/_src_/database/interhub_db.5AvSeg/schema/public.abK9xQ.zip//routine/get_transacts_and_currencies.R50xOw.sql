create function get_transacts_and_currencies(i_id bigint DEFAULT NULL::integer, i_client_account character varying DEFAULT NULL::character varying, i_merchant_id integer DEFAULT NULL::integer, i_agent_id integer DEFAULT NULL::integer, i_state_id integer DEFAULT NULL::integer, i_gateway_merchant_id integer DEFAULT NULL::integer, i_agent_transact_id character varying DEFAULT NULL::character varying, i_transact_amount bigint DEFAULT NULL::bigint)
    returns TABLE(id bigint, agent_id integer, transact_amount bigint, state_id integer, client_account character varying, currency_id integer, gateway_merchant_id integer, merchant_id integer, transact_date timestamp without time zone, agent_transact_id character varying, gateway_transact_id character varying, payment_type_id integer, params text, commission_amount bigint, amount_in_currency numeric, info character varying, currency_code character varying, price bigint, currency_date date, created_date date, difference bigint, nominal integer)
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    rec         RECORD;
    v_ref_id    varchar;
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_agent_id is not null then
        v_condition := v_condition || ' and  t.agent_id = ' || i_agent_id;
    end if;
    if i_client_account is not null then
        v_condition := v_condition || ' and  t.client_account = ' || i_client_account;
    end if;
    if i_merchant_id is not null then
        v_condition := v_condition || ' and t.merchant_id = ' || i_merchant_id;
    end if;
    if i_gateway_merchant_id is not null then
        v_condition := v_condition || ' and t.gateway_merchant_id  = ' || i_gateway_merchant_id;
    end if;
    if i_agent_transact_id is not null then
        v_condition := v_condition || ' and t.agent_transact_id = ' || i_agent_transact_id;
    end if;
    if i_transact_amount is not null then
        v_condition := v_condition || ' and t.transact_amount = ' || i_transact_amount;
    end if;
    if i_state_id is not null then
        v_condition := v_condition || ' and t.state_id = ' || i_state_id;
    end if;
    return query execute 'SELECT    t.id
                            , t.agent_id
                            , t.transact_amount
                            , t.state_id 
                            , t.client_account
                            , t.currency_id
                            , t.gateway_merchant_id 
                             , t.merchant_id
                            , t.transact_date
                            , t.agent_transact_id
                            , t.gateway_transact_id
                            , t.payment_type_id
                            , t.params
                            , t.commission_amount
                            , t.amount_in_currency
                            ,  t.info 
                            ,r.currency_code
                            ,r.price
                            ,r.currency_date
                            ,r.created_date
                            ,r.difference
                            ,r.nominal
                    FROM public.ib_transacts t,  ib_merchants m, ib_gateway_merchants g ,
                        ib_currencies r where t.merchant_id = m.id  and
                            g.id  = t.gateway_merchant_id and t.currency_id = r.id ' || v_condition;

    IF NOT FOUND THEN
        if i_id is not null then
            v_ref_id := i_id;
        elsif i_client_account is not null then
            v_ref_id := i_client_account;
        end if;
        perform log_action_atx(v_ref_id, 7, 'Данный не нфйден ид :get_transacts_and_currencies' || 1, 'OK');
    END IF;
END;
$$;

alter function get_transacts_and_currencies(bigint, varchar, integer, integer, integer, integer, varchar, bigint) owner to interhub_user;

