create function get_cards_page(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_id integer DEFAULT NULL::integer, i_pan character varying DEFAULT NULL::character varying, i_cvv character varying DEFAULT NULL::character varying, i_expiry_date character varying DEFAULT NULL::character varying, i_card_holder character varying DEFAULT NULL::character varying, i_user character varying DEFAULT NULL::character varying, i_token character varying DEFAULT NULL::character varying, i_payment_id character varying DEFAULT NULL::character varying, i_capture_id character varying DEFAULT NULL::character varying, i_refund_id character varying DEFAULT NULL::character varying, i_ordered_by character varying DEFAULT NULL::character varying, i_is_desc character varying DEFAULT NULL::character varying, i_oson_card_id integer DEFAULT NULL::integer)
    returns TABLE(id integer, pan character varying, cvv character varying, expiry_date character varying, card_holder character varying, created_date timestamp without time zone, info character varying, "user" character varying, token character varying, payment_id character varying, capture_id character varying, refund_id character varying, params character varying, oson_card_id integer, country character varying, bank character varying, count integer)
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
    v_condition varchar := '';
begin
	
	if i_ordered_by is   null then
       i_ordered_by := '1';
    end if;
      if i_is_desc  ='Y' then
       i_ordered_by := i_ordered_by || ' desc ';
    end if;
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_oson_card_id is not null then
        v_condition := v_condition || ' and t.oson_card_id = ' || i_oson_card_id;
    end if;
    if i_pan is not null then
        v_condition := v_condition || 'and lower(t.pan) like ''%' || lower(i_pan) || '%' || '''';
    end if;
   
   if i_user is not null then
        v_condition := v_condition || 'and lower(t.user) like ''%' || lower(i_user) || '%' || '''';
    end if;
   
    if i_token is not null then
        v_condition := v_condition || ' and  t.token = ''' || i_token || '''';
    end if;
   
      if i_payment_id is not null then
        v_condition := v_condition || ' and  t.payment_id = ''' || i_payment_id || '''';
    end if;
      if i_capture_id is not null then
        v_condition := v_condition || ' and  t.capture_id = ''' || i_capture_id || '''';
    end if;
      if i_refund_id is not null then
        v_condition := v_condition || ' and  t.refund_id = ''' || i_refund_id || '''';
    end if;
   
    if i_cvv is not null then
        v_condition := v_condition || ' and  t.cvv = ''' || i_cvv || '''';
    end if;
   
    if i_expiry_date is not null then
        v_condition := v_condition || ' and  t.expiry_date = ''' || i_expiry_date || '''';
    end if;
      if i_card_holder is not null then
        v_condition := v_condition || ' and lower(t.card_holder) like ''%' || lower(i_card_holder) || '%' || '''';
    end if;
    RETURN QUERY
        execute 'SELECT t.*, 
						count(*) over()::integer as count  FROM ib_cards t  WHERE  1= 1 ' || v_condition ||
                         ' order by '||i_ordered_by||'  limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;
    IF NOT FOUND THEN
        perform log_action_atx(v_condition, 5, 'Card Данный не найден : ' || v_condition, 'ERROR');
    END IF; 
END;
$$;

alter function get_cards_page(integer, integer, integer, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, integer) owner to interhub_user;

