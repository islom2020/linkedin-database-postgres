create function generate_id_transact() returns bigint
    language plpgsql
as
$$
DECLARE
    v_id          integer ;
    v_seq_id      integer ;
    v_real_number varchar;
    v_other       varchar;
    v_seq_id_var  varchar := '';
    v_big_seq_id  bigint;
begin
    SELECT nextval('transact_generate_seq') into v_seq_id;
    SELECT floor(random() * 10 + 1)::integer into v_id;
    if v_seq_id + v_id > 999 then
        SELECT setval('transact_generate_seq', 100) into v_seq_id;
        v_seq_id := v_seq_id + v_id;
    else
        SELECT setval('transact_generate_seq', (v_seq_id + v_id)) into v_seq_id;
    end if;

    SELECT date_part('epoch', CURRENT_TIMESTAMP)::numeric into v_other;

    SELECT SUBSTRING(v_other,
                     1,
                     strpos(v_other, '.') - 1) AS real_number
    into v_real_number;
    v_other := v_real_number || v_seq_id;--|| substr(v_other, 0, 3) || i_agent_id :: varchar;
    v_big_seq_id := v_other :: bigint;
    return v_big_seq_id;
END;
$$;

alter function generate_id_transact() owner to interhub_user;

