create function add_gateway_merchant(i_name character varying, i_gateway_id integer, i_min_amount bigint, i_max_amount bigint, i_state_id integer, i_commission_up numeric, i_commission_down numeric, i_gateway_merchant_id integer, i_gateway_check_id integer, i_gateway_pay_id integer, i_currency_id integer, i_category_id integer DEFAULT NULL::integer, i_info character varying DEFAULT NULL::character varying, i_can_check_request integer DEFAULT 1, i_merchant_id integer DEFAULT NULL::integer, i_gateway_merchant_code character varying DEFAULT NULL::character varying, i_can_pay_request integer DEFAULT NULL::integer) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_date               date    := now();
    v_id_max             integer;
    v_user               integer =2;
    v_name               varchar;
    v_object_id constant integer := 3;
   v_gateway_merchant_Code integer;
BEGIN
    if i_gateway_id is null then
        raise notice 'gateway_id musn`t  be null ';
        return false;
    end if;
    select name into v_name from ib_gateways t where t.id = i_gateway_id;
    INSERT INTO public.ib_gateway_merchants ( name
                                            , gateway_id
                                            , min_amount
                                            , max_amount
                                            , state_id
                                            , created_by
                                            , created_date
                                            , commission_up
                                            , commission_down
                                            , gateway_merchant_id
                                            , gateway_check_id
                                            , gateway_pay_id
                                            , currency_id
                                            ,category_id
                                            ,info
                                            ,can_check_request
                                            ,merchant_id
                                            ,gateway_merchant_code
                                            , can_pay_request)
    VALUES ( i_name
           , i_gateway_id
           , i_min_amount
           , i_max_amount
           , i_state_id
           , v_user
           , now()
           , i_commission_up
           , i_commission_down
           , i_gateway_merchant_id
           , i_gateway_check_id
           , i_gateway_pay_id
           , i_currency_id
          ,i_category_id,
         	i_info
         ,i_can_check_request
         ,i_merchant_id
         ,i_gateway_merchant_code,i_can_pay_request) returning id into v_gateway_merchant_Code;
       if i_gateway_merchant_code is null then 
      		 update ib_gateway_merchants set gateway_merchant_Code =  v_gateway_merchant_Code||'' where id  = v_gateway_merchant_Code;
        end if;
    return true;
exception
    when others THEN
        select max(id) into v_id_max from ib_gateway_merchants;
        perform log_action_atx(v_id_max || '', v_object_id, sqlerrm || 'add_gateway_merchant', 'ERROR');
        return false;
END;
$$;

alter function add_gateway_merchant(varchar, integer, bigint, bigint, integer, numeric, numeric, integer, integer, integer, integer, integer, varchar, integer, integer, varchar, integer) owner to interhub_user;

