create function ib_delete_transacts_tr() returns trigger
    language plpgsql
as
$$
DECLARE
vDescription TEXT := '';
vId INT;
vReturn RECORD;

BEGIN  
      		  perform log_action_atx(old.id || '', 7,  ' yo can not delete tranzaksii', 'ERROR');
      		 raise exception 'you can not delete from this table ';
        return old; 
   END;
$$;

alter function ib_delete_transacts_tr() owner to interhub_user;

