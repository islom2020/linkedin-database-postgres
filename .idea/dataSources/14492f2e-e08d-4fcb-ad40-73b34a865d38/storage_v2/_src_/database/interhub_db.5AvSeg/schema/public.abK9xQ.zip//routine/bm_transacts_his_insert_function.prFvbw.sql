create function bm_transacts_his_insert_function() returns trigger
    language plpgsql
as
$$
DECLARE
    partition_date    TEXT;
    partition_name    TEXT;
    start_of_month    TEXT;
    end_of_next_month TEXT;
BEGIN
    partition_date := to_char(NEW.transact_date, 'YYYY_MM');
    partition_name := 'bm_transacts_his' || partition_date;
    start_of_month := to_char((NEW.transact_date), 'YYYY-MM') || '-01';
    end_of_next_month := to_char((NEW.transact_date + interval '1 month'), 'YYYY-MM') || '-01';
    IF NOT EXISTS
        (SELECT *
         FROM information_schema.tables
         WHERE table_name = partition_name)
    THEN
        RAISE NOTICE 'A partition has been created %', partition_name;
        EXECUTE format(
                E'CREATE TABLE %I (CHECK ( date_trunc(\'day\', transact_date) >= ''%s'' AND date_trunc(\'day\', transact_date) < ''%s'')) INHERITS (public.bm_transacts_his)',
                partition_name, start_of_month, end_of_next_month);
        -- EXECUTE format('GRANT SELECT ON TABLE %I TO readonly', partition_name); -- use this if you use role based permission
    END IF;
    EXECUTE format('INSERT INTO %I (
 agent_id
     , state_id
     , client_account
     , rate_id
     , gateway_merchant_id
     , merchant_id
     , transact_date
     , agent_check_id
     , check_unique_id
     , payment_type_id
     , params
     , comission_amount
     , created_date
     , transact_amount) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)', partition_name) using
        NEW.agent_id,
        NEW.state_id,
        NEW.client_account,
        NEW.rate_id,

        NEW.gateway_merchant_id,
        NEW.merchant_id,
        NEW.transact_date,
        NEW.agent_check_id,

        NEW.check_unique_id,
        NEW.payment_type_id,
        NEW.params,
        NEW.comission_amount,

        NEW.created_date,
        NEW.transact_amount;
    RETURN NULL;
END
$$;

alter function bm_transacts_his_insert_function() owner to interhub_user;

