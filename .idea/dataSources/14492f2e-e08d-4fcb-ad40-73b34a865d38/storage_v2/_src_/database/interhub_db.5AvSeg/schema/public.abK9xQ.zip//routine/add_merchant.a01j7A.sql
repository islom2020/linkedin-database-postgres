create function add_merchant(i_name character varying, i_gateway_merchant_id integer, i_category_id integer, i_min_amount bigint, i_max_amount bigint, i_currency_id integer, i_state_id integer DEFAULT 1, i_info character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_id_max             integer;
    v_object_id constant integer := 1;
BEGIN
    insert into ib_merchants (name, gateway_merchant_id,
                              category_id, min_amount,
                              max_amount , currency_id,state_id, info)
    values (i_name,
            i_gateway_merchant_id,
            i_category_id,
            i_min_amount,
            i_max_amount, i_currency_id ,i_state_id ,i_info);
    return true;
exception
    when others THEN
        select max(id) into v_id_max from ib_merchants;
        perform log_action_atx(v_id_max ||'', v_object_id, sqlerrm ||' add_merchant', 'ERROR');
        return false;
END;
$$;

alter function add_merchant(varchar, integer, integer, bigint, bigint, integer, integer, varchar) owner to interhub_user;

