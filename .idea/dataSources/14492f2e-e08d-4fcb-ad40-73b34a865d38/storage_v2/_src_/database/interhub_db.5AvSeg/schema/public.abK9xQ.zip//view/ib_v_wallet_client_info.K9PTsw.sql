create view ib_v_wallet_client_info
            (id, first_name, surname, last_name, birth_date, doc_number, nationality, gender, birth_address, expiry_doc,
             authority, registration_address, doc_photo_url, mail_address, self_photo, state_id, client_id, info,
             created_date, region_id, modified_date, created_doc_date, doc_address_photo, oson_file, yandex_file,
             qiwi_file, client_wallet_type, filial_id, count)
as
SELECT t.id,
       t.first_name,
       t.surname,
       t.last_name,
       t.birth_date,
       t.doc_number,
       t.nationality,
       t.gender,
       t.birth_address,
       t.expiry_doc,
       t.authority,
       t.registration_address,
       t.doc_photo_url,
       t.mail_address,
       t.self_photo,
       t.state_id,
       t.client_id,
       t.info,
       t.created_date::character varying  AS created_date,
       t.region_id,
       t.modified_date::character varying AS modified_date,
       t.created_doc_date,
       t.doc_address_photo,
       t.oson_file,
       t.yandex_file,
       t.qiwi_file,
       c.client_wallet_type,
       t.filial_id,
       count(c.*) OVER ()::integer        AS count
FROM ib_wallet_client_info t
         LEFT JOIN ib_clients c ON c.id = t.client_id;

alter table ib_v_wallet_client_info
    owner to interhub_user;

