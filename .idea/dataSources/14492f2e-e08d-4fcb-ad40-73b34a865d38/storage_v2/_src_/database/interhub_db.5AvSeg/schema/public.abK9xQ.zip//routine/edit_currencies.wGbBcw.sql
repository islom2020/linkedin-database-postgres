create function edit_currencies(i_id integer, i_mode_price bigint) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_object_id constant integer := 2;
BEGIN

    update ib_currencies
    set mode_price = i_mode_price
    where id = i_id;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
END;
$$;

alter function edit_currencies(integer, bigint) owner to interhub_user;

