create function edit_wallet(i_id integer, i_fullname character varying DEFAULT NULL::character varying, i_state_id integer DEFAULT NULL::integer, i_wallet_type integer DEFAULT NULL::integer, i_phone_number character varying DEFAULT NULL::character varying, i_mail_address character varying DEFAULT NULL::character varying, i_currency_id integer DEFAULT NULL::integer, i_deposit_state integer DEFAULT NULL::integer, i_withdraw_state integer DEFAULT NULL::integer) returns boolean
    language plpgsql
as
$$
DECLARE
    v_object_id constant integer := 5;
    v_wallet_type        integer;
    v_phone_number       varchar(200) ;
    v_fullname           varchar(300);
    v_state_id           integer;
    v_err_text           varchar;
    v_mail_address       varchar;
    v_password           varchar;
    v_currency_id        integer;
   	v_withdraw_state 	 integer;
  	v_deposit_state 	 integer;
BEGIN
    select fullname, state_id, phone_number, wallet_type, mail_address, password, currency_id, deposit_state, withdraw_state 
    into
        v_fullname , v_state_id, v_phone_number ,v_wallet_type, v_mail_address,v_password, v_currency_id,v_deposit_state , v_withdraw_state
    from ib_wallets
    where id = i_id;
    if not found then
        v_err_text := 'takaya id ne nayden ';
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
    end if;
    if i_wallet_type is null then
        i_wallet_type := v_wallet_type;
    end if;
     if i_deposit_state is null then
        i_deposit_state := v_deposit_state;
    end if;
   
     if i_withdraw_state is null then
        i_withdraw_state := v_withdraw_state;
    end if;
   
    if i_currency_id is null then
        i_currency_id := v_currency_id;
    end if;
    
    if i_fullname is null then
        i_fullname := v_fullname;
    end if;
    if i_mail_address is null then
        i_mail_address := v_mail_address;
    end if;
    if i_state_id is null then
        i_state_id := v_state_id;
    end if;
    if i_phone_number is null then
        i_phone_number := v_phone_number;
    end if;
    update ib_wallets
    set fullname     = i_fullname,
        wallet_type  = i_wallet_type,
        phone_number = i_phone_number,
        state_id     = i_state_id,
        mail_address = i_mail_address, 
        currency_id  = i_currency_id,
        withdraw_state = i_withdraw_state,
        deposit_state = i_deposit_state
        
    where id = i_id;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', v_object_id, v_err_text || ' edit_wallet_client ', 'ERROR');
        return false;
END;
$$;

alter function edit_wallet(integer, varchar, integer, integer, varchar, varchar, integer, integer, integer) owner to interhub_user;

