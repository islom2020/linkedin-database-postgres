create function get_gateways_page(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_id integer DEFAULT NULL::integer, i_name character varying DEFAULT NULL::character varying, i_login character varying DEFAULT NULL::character varying, i_request_token character varying DEFAULT NULL::character varying, i_ordered_by character varying DEFAULT NULL::character varying, i_is_desc character varying DEFAULT NULL::character varying)
    returns TABLE(id integer, name character varying, login character varying, password character varying, currency_id integer, state_id integer, pay_url character varying, small_logo character varying, amount_unit bigint, ip_address character varying, check_status_url character varying, client_id integer, request_token character varying, count integer)
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
    v_condition varchar := '';
   v_gatways_count integer;
begin
	 if i_ordered_by is   null then
          i_ordered_by := '1';
     end if;
	  if i_is_desc  ='Y' then
          i_ordered_by := i_ordered_by || ' desc ';
      end if;
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_name is not null then
        v_condition := v_condition || 'and lower(t.name) like ''%' || lower(i_name) || '%' || '''';
    end if;
   if i_request_token is not null then
        v_condition := v_condition || 'and  t.i_request_token ''' || i_request_token ||  '''';
    end if;
    if i_login is not null then
        v_condition := v_condition || 'and t.login like ''%' || i_login || '%' || '''';
    end if;
       EXECUTE 'select  count(*)  from ib_gateways t where 1=1 ' || v_condition into v_gatways_count;

    return query execute ' SELECT  id  ,
 name ,
 login , 
 password , 
 currency_id,
 state_id ,
 pay_url,
 small_logo, 
 amount_unit,
 ip_address,
 check_status_url,
 client_id , 
 request_token, '||v_gatways_count ||' as count  FROM ib_gateways t
      WHERE   1= 1 ' || v_condition||
                         ' order by '||i_ordered_by||'   limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;


    if not found then
        perform log_action_atx(v_condition, 3, 'Данный не нфйден ид :get_gateways' || v_condition, 'ERROR');
    end if;
END;
$$;

alter function get_gateways_page(integer, integer, integer, varchar, varchar, varchar, varchar, varchar) owner to interhub_user;

