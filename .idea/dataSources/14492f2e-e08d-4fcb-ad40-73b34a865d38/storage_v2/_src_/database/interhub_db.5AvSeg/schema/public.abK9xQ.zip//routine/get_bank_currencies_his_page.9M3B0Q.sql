create function get_bank_currencies_his_page(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_currency_id integer DEFAULT NULL::integer, i_currency_date character varying DEFAULT NULL::character varying)
    returns TABLE(id integer, currency_id integer, purchase_amount numeric, sell_amount numeric, currency_date character varying, created_date character varying, count integer)
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    v_date      date    := now();
BEGIN
    if i_currency_id is not null then
        v_condition := ' and c.currency_id = ' || i_currency_id;
    end if;
   if i_currency_date is not null then
        v_condition := v_condition ||
                       ' and  to_char( t.created_date, ''dd.mm.yyyy'' )  = ''' ||
                       i_currency_date || '''';
    end if;
    return query execute ' SELECT  c.id,c.currency_id,c.purchase_amount,c.sell_amount, c.currency_date::varchar  as currency_date,created_date::varchar  as created_date,  count(*) over() ::integer as count 
            FROM   ib_bank_currencies_his c
      WHERE  1 = 1 ' || v_condition ||
                         ' order by 1 desc limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;

END;
$$;

alter function get_bank_currencies_his_page(integer, integer, integer, varchar) owner to interhub_user;

