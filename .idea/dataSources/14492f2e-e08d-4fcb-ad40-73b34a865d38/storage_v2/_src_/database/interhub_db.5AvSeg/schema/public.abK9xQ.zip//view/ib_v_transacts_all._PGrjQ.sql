create view ib_v_transacts_all
            (id, agent_id, state_id, client_account, currency_id, gateway_merchant_id, merchant_id, transact_date,
             agent_transact_id, gateway_transact_id, payment_type_id, params, commission_amount, created_date,
             transact_amount, amount_in_currency, amount_out_currency, info, currency_code, price, currency_date,
             currency_name, agent_name, payment_type, commission, merchant_name, category_id, category_name, state_name,
             gateway_merchant_name, gateway_id, gateway_name, tran_type, count, total_amount)
as
SELECT t.id,
       t.agent_id,
       t.state_id,
       t.client_account,
       t.destination_currency_id    AS currency_id,
       t.gateway_merchant_id,
       t.merchant_id,
       t.transact_date,
       t.agent_transact_id,
       t.gateway_transact_id,
       t.payment_type_id,
       t.params,
       t.commission_amount,
       t.created_date,
       t.transact_amount,
       t.amount_in_currency,
       t.amount_out_currency,
       t.info,
       r.currency_code,
       r.price,
       r.currency_date,
       r.name                       AS currency_name,
       a.name                       AS agent_name,
       a.payment_type,
       a.commission,
       m.name                       AS merchant_name,
       m.category_id,
       (SELECT ct.name
        FROM ib_categories ct
        WHERE ct.id = m.id)         AS category_name,
       o.name                       AS state_name,
       g.name                       AS gateway_merchant_name,
       g.gateway_id,
       (SELECT gt.name
        FROM ib_gateways gt
        WHERE gt.id = g.gateway_id) AS gateway_name,
       t.tran_type,
       1                            AS count,
       1::numeric                   AS total_amount
FROM ib_agents a,
     ib_object_states o,
     ib_currencies r,
     ib_transacts t
         LEFT JOIN ib_merchants m ON m.id = t.merchant_id
         LEFT JOIN ib_gateway_merchants g ON g.id = t.gateway_merchant_id
WHERE t.destination_currency_id = r.id
  AND a.id = t.agent_id
  AND o.object_id = 7
  AND t.state_id = o.id
ORDER BY t.id DESC;

alter table ib_v_transacts_all
    owner to interhub_user;

