create function reverse_deposit(i_from_client_id integer, i_to_client_id integer, i_dr_amount numeric, i_from_client_type_id integer, i_to_client_type_id integer, i_currency_id integer, i_group_id bigint, i_from_currency_id integer, i_commission_amount numeric, i_from_jur_id integer DEFAULT NULL::integer, i_to_jur_id integer DEFAULT NULL::integer) returns integer
    language plpgsql
as
$$
DECLARE
    v_count          integer := 0 ;
    v_dep            numeric  := 0;
    v_object_id      integer := 4;
    v_currency_code  varchar;
    v_client_account ib_client_accounts%rowtype;
    v_res            boolean;
     v_res1            integer;
   v_exch_amount numeric;
 v_from_amount	numeric;
v_exchange_transact  ib_exchange_transacts%rowtype;
v_is_wallet integer;
v_client_id integer;
BEGIN
 ------    gateway account
    select t.*
    into v_client_account
    from ib_client_accounts t
    where t.client_id = i_from_client_id
      and currency_id = i_currency_id
      and t.client_type_id = i_from_client_type_id
      and t.account_type_id = i_from_client_type_id
	  and coalesce (t.juridical_id,  i_from_jur_id) =  i_from_jur_id
      and t.condition = 'A' for update;
if i_currency_id  =  i_from_currency_id   then    
    v_client_account.balance := v_client_account.balance - (i_dr_amount - i_commission_amount);

    select add_client_deposit(v_client_account.id, v_client_account.balance, (i_dr_amount - i_commission_amount), 0,
                              i_group_id)
    into v_res;
	 if v_res = false then
            return -1;
     end if;
   
    update ib_client_accounts
    set balance = v_client_account.balance
    where id  = v_client_account.id;
   ---------agentdan qaytarish
select t.*
    into v_client_account
    from ib_client_accounts t
    where t.client_id = i_to_client_id
      and currency_id = i_currency_id
      and t.client_type_id = i_to_client_type_id
      and t.account_type_id = i_to_client_type_id
				      and coalesce (t.juridical_id,  i_to_jur_id) =  i_to_jur_id
      and t.condition = 'A' for update; 
     
      v_client_account.balance := v_client_account.balance + i_dr_amount;

    select add_client_deposit(v_client_account.id, v_client_account.balance,  0,(i_dr_amount ),
                              i_group_id)
    into v_res;
	 if v_res = false then
            return -1;
     end if;
   
    update ib_client_accounts
    set balance = v_client_account.balance
    where id  = v_client_account.id;

 else   ------exchange reverse bulsa 
    	begin
				select * into v_exchange_transact   from ib_exchange_transacts t where t.transact_id = i_group_id;
			v_from_amount := v_exchange_transact.to_amount; 
		exception when others then 
				raise; 
		end; 
		
	---------   cut client gateway_Account  
	    select t.* into v_client_account  from ib_client_accounts  t 
  					where t.client_type_id  = i_from_client_type_id
  					and t.account_type_id  = i_from_client_type_id
  					and t.client_id = i_from_client_id 
  					and t.currency_id  = i_from_currency_id
		  and coalesce (t.juridical_id,  i_from_jur_id) =  i_from_jur_id
  					and condition ='A'  for update;
  				if not found then 
  						raise;
  				end if;
  					v_client_account.balance :=  v_client_account.balance - v_from_amount;
  				select add_client_deposit(v_client_account.id, v_client_account.balance, v_from_amount , 0,i_group_id)
	    into v_res;
			    if v_res = false then
			        raise;
			    end if;
		
	  	update ib_client_accounts
	    set balance = v_client_account.balance
	    where id = v_client_account.id;
	
	------ put to exchanger account  from_currency
		 select t.* into v_client_account  from ib_client_accounts  t 
  					where t.client_type_id  = 0
  					and t.account_type_id  = 6
  					and t.currency_id  = i_from_currency_id
  					and condition ='A'  for update;
  				if not found then 
  					perform  log_action_atx(i_from_client_id || '', v_object_id, sqlerrm || ' can not find account  exchange_currency ', 				'ERROR');
  					raise;
  				end if;
  			v_client_account.balance :=  v_client_account.balance + v_from_amount;
  		select add_client_deposit(v_client_account.id, v_client_account.balance, 0, v_from_amount, i_group_id)
	    into v_res;
			    if v_res = false then
			        raise;
			    end if;
		
	  	update ib_client_accounts
	    set balance = v_client_account.balance
	    where id = v_client_account.id;
	   
	   ------------ cut exchanger account to_currency 
	    select t.* into v_client_account  from ib_client_accounts  t 
  					where t.client_type_id  = 0
  					and t.account_type_id  = 6
  					and t.currency_id  = i_currency_id
  					and condition ='A'  for update;
  				if not found then 
  					perform  log_action_atx(i_from_client_id || '', v_object_id, sqlerrm || ' can not find account  exchange_currency ', 'ERROR');
  					raise;
  				end if;
  				v_client_account.balance :=  v_client_account.balance - v_exchange_transact.from_amount;
  			select add_client_deposit(v_client_account.id, v_client_account.balance, v_exchange_transact.from_amount, 0, i_group_id)
	    	into v_res;
			    if v_res = false then
			        raise;
			    end if;
		
	  	update ib_client_accounts
	    set balance = v_client_account.balance
	    where id = v_client_account.id;
	 -------put to agent account     
	     select t.* into v_client_account  from ib_client_accounts  t 
  					where t.client_type_id  = i_to_client_type_id
  					and t.account_type_id  = i_to_client_type_id
  					and t.client_id = v_exchange_transact.source_client_id
	  and coalesce (t.juridical_id,  i_to_jur_id) =  i_to_jur_id
  					and t.currency_id  = i_currency_id
  					and condition ='A'  for update;
  				if not found then 
  					raise;
  				end if;
  					v_client_account.balance :=  v_client_account.balance + (v_exchange_transact.from_amount + i_commission_amount);
  				select add_client_deposit(v_client_account.id, v_client_account.balance, 0 ,
  									(v_exchange_transact.from_amount + i_commission_amount),i_group_id)
	    into v_res;
			    if v_res = false then
			        raise;
			    end if;
		
	  	update ib_client_accounts
	    set balance = v_client_account.balance
	    where id = v_client_account.id;
	   -----------  change exchange transact status 
	   update ib_exchange_transacts  set state_id  = 4 where id  = v_exchange_transact.id;
	  ------------
 end if;
    if i_commission_amount > 0 and i_commission_amount is not null then   -----------------------  commissiyasini qaytarish
            select t.*
            into v_client_account
            from ib_client_accounts t
            where t.client_id = -1 
            and t.currency_id = i_currency_id
              and t.client_type_id = -1
              and t.account_type_id = 1
              and t.condition = 'A' for update;
				 if not found then 
						raise 'commission account can not find ';
					end if;
            v_client_account.balance := v_client_account.balance - i_commission_amount;
 				
        
        select add_client_deposit(v_client_account.id, v_client_account.balance, i_commission_amount, 0, i_group_id,
                                  i_is_commission => 'Y')
        into v_res;
        if v_res = false then
            return -1;
        end if;
       
       
            update ib_client_accounts
            set balance = v_client_account.balance
            where id =  v_client_account.id;
    end if;
    return 1;
exception
    when others then
        perform log_action_atx(i_from_client_id || '', v_object_id, sqlerrm || 'reverse_deposit', 'ERROR');
        return -1;

END;
$$;

alter function reverse_deposit(integer, integer, numeric, integer, integer, integer, bigint, integer, numeric, integer, integer) owner to interhub_user;

