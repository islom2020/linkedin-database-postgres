create function edit_session(i_id integer DEFAULT NULL::integer, i_session_id character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_id integer;
    v_res_funct  boolean;
    v_object_id integer:= 2;
    v_condition varchar := '';
BEGIN
  if i_id is not  null then 
     update ib_sessions set created_Date = now() where  id = i_id;
     return true; 
 else 
     update ib_sessions set created_Date = now() where  session_id = i_session_id;
    return true;
  end if;
 return false;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_session_id, v_object_id, v_err_text|| 'edit_session', 'ERROR');
        return false;
END;
$$;

alter function edit_session(integer, varchar) owner to interhub_user;

