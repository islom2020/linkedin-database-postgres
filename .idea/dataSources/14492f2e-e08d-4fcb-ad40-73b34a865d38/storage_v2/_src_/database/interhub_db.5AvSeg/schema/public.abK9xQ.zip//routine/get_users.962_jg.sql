create function get_users(i_id integer DEFAULT NULL::integer, i_login character varying DEFAULT NULL::character varying, i_password character varying DEFAULT NULL::character varying, i_condition character varying DEFAULT NULL::character varying, i_fullname character varying DEFAULT NULL::character varying, i_role_id integer DEFAULT NULL::integer, i_access_priority character varying DEFAULT NULL::character varying, i_owner_id integer DEFAULT NULL::integer, i_filial_id integer DEFAULT NULL::integer) returns SETOF ib_users
    language plpgsql
as
$$
declare
  v_reference_id integer;

v_err_text varchar;

v_condition varchar = '';

begin if i_login is not null then v_condition := v_condition || ' and t.login =''' || i_login || '''';

end if;

if i_access_priority is not null then v_condition := v_condition || ' and t.access_priority =''' || i_access_priority || '''';

end if;

if i_owner_id is not null then v_condition := v_condition || ' and t.owner_id =' || i_owner_id ;

end if;  

if i_filial_id is not null then v_condition := v_condition || ' and t.filial_id =' || i_filial_id ;

end if; 

if i_password is not null then v_condition := v_condition || ' and  t.password =''' || i_password || '''';

end if;

if i_fullname is not null then v_condition := v_condition || 'and lower(t.fullname ) like ''%' || lower(i_fullname) || '%' || '''';

end if;

if i_condition is not null then v_condition := v_condition || ' and  t.conidition =''' || i_condition || '''';

end if;

if i_role_id is not null then v_condition := v_condition || ' and  t.role_id =' || i_role_id ;

end if;

if i_id is not null then v_condition := v_condition || ' and  t.id =' || i_id ;

end if;

return QUERY execute 'SELECT * FROM ib_users t  WHERE  1= 1 ' || v_condition;

exception
when others then v_err_text := sqlerrm;

perform log_action_atx(i_id || '',
0,
v_err_text,
'ERROR');

end ;

$$;

alter function get_users(integer, varchar, varchar, varchar, varchar, integer, varchar, integer, integer) owner to interhub_user;

