create function add_juridical_wallet(i_name character varying, i_type character varying, i_currency_id integer DEFAULT 860, i_client_id integer DEFAULT NULL::integer, i_token character varying DEFAULT NULL::character varying) returns integer
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 5;
    v_curr_wallet_state  integer := 2;
    v_wallet        ib_wallets%rowtype;
    v_client             ib_clients%rowtype;
   v_parent_wallet_id integer;
   v_client_condition varchar := 'A';
  v_wallet_id  integer;
  v_account_id integer;
    v_wallet_count    integer;
   v_client_id integer;
   v_count integer;
BEGIN
   /*
  if i_Client_id is null then 
    select add_client(i_client_name => i_name, i_client_type => 'J') into i_client_id;
  else 
    select count(*) into v_count from ib_clients t where t.id   = i_client_id and client_type  = 'J';
    if   v_count =0 then 
      raise 'can not find client';  
    end if;
  end if ;  */
 	if i_client_id is null then
 	select add_client(i_client_name => i_name, i_client_type => 'J',i_client_wallet_type=>100) into i_client_id;            
		  if   i_client_id =-1 then 
     		 raise 'can not create  client';  
   		 end if;    
		    insert into ib_wallets(fullname, state_id, phone_number, wallet_type, 
		                           currency_id, client_id)
		    values (i_name, v_curr_wallet_state, i_client_id , 100, 
		            i_currency_id, i_client_id)  returning id into v_parent_wallet_id ;
		   
		       
	else 
	
		select   count(*)  into   v_count from ib_wallets t where t.client_id  =  i_client_id and t.wallet_type =  100;
		  if   v_count =0 then 
      		 	 insert into ib_wallets(fullname, state_id, phone_number, wallet_type, 
		                           currency_id, client_id)
		    values (i_name, v_curr_wallet_state, i_client_id , 100, 
		            i_currency_id, i_client_id)  returning id into v_parent_wallet_id ;
		   	
    	  end if;
--   	 	select   t.client_id  into   v_client_id from ib_wallets t where t.id  =  v_parent_wallet_id and t.wallet_type =  100;
	end if;
	
if  i_type ='M'  then 
	SELECT public.add_client_account_mode(i_client_id,i_currency_id,v_object_id , 7) into v_account_id;
     if v_account_id  !=  -1  then 
      perform   add_jur_wallet_child(i_parent_wallet_id =>  v_parent_wallet_id , i_name => i_name ,   i_account_id =>v_account_id  , i_type =>  'M' ,  i_token=> i_token);
     else 
       raise 'can not create account merchant wallet';
     end if;
 end if;
if   i_type ='A'  then
      SELECT public.add_client_account_mode(i_client_id,i_currency_id,v_object_id , 8) into v_account_id;
    if v_account_id  !=  -1  then 
    perform   add_jur_wallet_child( i_parent_wallet_id =>  v_parent_wallet_id ,  i_name => i_name , i_account_id =>v_account_id  ,i_type =>  'A', i_token=>i_token );
     else 
       raise 'can not create account merchant wallet';
     end if;
 end if;     
   return 1;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_name , v_object_id,
                               v_err_text || 'add_wallets',
                               'ERROR');
        return -1 ;
END;
$$;

alter function add_juridical_wallet(varchar, varchar, integer, integer, varchar) owner to interhub_user;

