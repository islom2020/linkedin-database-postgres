create function edit_merch_max_min() returns integer
    language plpgsql
as
$$
DECLARE 
v_id integer;
r               record;
v_merchants ib_merchants%rowtype;
begin
	
	for r in (	select t.merchant_id from ib_agent_merchant  t      )
	 loop
			select * into v_merchants  from ib_merchants c where c.id  = r.merchant_id;
				update
			ib_agent_merchant
		set
			min_amount = v_merchants.min_amount,
			max_amount = v_merchants.max_amount
		where
			merchant_id = v_merchants.id;
	 end loop ;
	 return 1;
	exception when others then 
	 perform log_action_atx(  '22', 2, sqlerrm, 'ERROR');
        return -1;
	END;
$$;

alter function edit_merch_max_min() owner to interhub_user;

