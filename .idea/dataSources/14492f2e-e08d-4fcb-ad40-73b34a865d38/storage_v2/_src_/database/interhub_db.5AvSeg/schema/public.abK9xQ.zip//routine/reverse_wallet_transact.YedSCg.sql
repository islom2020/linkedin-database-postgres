create function reverse_wallet_transact(i_id bigint) returns boolean
    language plpgsql
as
$$
DECLARE
    v_currency_price             bigint;
    v_source_account_id           integer;
    v_destination_account_id      integer;
    v_source_client_type_id      integer;
    v_destination_client_type_id integer;
    v_date                       date    := now();
    v_id_max                     bigint  := -1;
    v_object_id constant         integer := 7;
   v_destination_currency_id 	 integer;
   v_source_currency_id     	 integer;
    v_res                        integer;
    v_wallet_transact            ib_wallet_transacts%rowtype;
BEGIN
	
    select *
    into v_wallet_transact
    from ib_wallet_transacts
    where id = i_id for update;

   if not found then
            return false;
        end if;
    if v_Wallet_transact.state_id  != 6 then  
    		return false;
    end if;
       if v_wallet_transact.payment_type = 2 then
        select c.id    into v_source_account_id  
       				from ib_wallets t,  ib_client_accounts c  where t.phone_number = v_wallet_transact.source 
       			and t.currency_id  = v_wallet_transact.currency_id and c.client_id = t.client_id  and c.client_type_id = 5
       			and t.currency_id = c.currency_id ;
       			   if not found then
        		     	return false;
				   end if;
        select t.account_id 
        into v_destination_account_id  
        from ib_jur_wallet_childs t where t.id  = v_wallet_transact.destination::integer;
   if not found then
            return false;
        end if;

    elsif v_wallet_transact.payment_type = 1 then
         select t.account_id   into v_source_account_id  
        from ib_jur_wallet_childs t where t.id  = v_wallet_transact.source::integer;
 		
       	if not found then
            return false;
        end if; 
        select c.id    into v_destination_account_id  
       				from ib_wallets t,  ib_client_accounts c  where t.phone_number = v_wallet_transact.destination 
       			and t.currency_id  = v_wallet_transact.destination_currency_id and c.client_id = t.client_id  and c.client_type_id = 5
       			and t.currency_id = c.currency_id ; 
   if not found then
            return false ;
        end if;
    elsif v_wallet_transact.payment_type = 3 then
         select c.id    into v_source_account_id  
       				from ib_wallets t,  ib_client_accounts c  where t.phone_number = v_wallet_transact.source 
       			and t.currency_id  = v_wallet_transact.currency_id and c.client_id = t.client_id  and c.client_type_id = 5
       			and t.currency_id = c.currency_id ;
       		   if not found then
        		   return false ;
       		   end if;
        select c.id    into v_destination_account_id  
       				from ib_wallets t,  ib_client_accounts c  where t.phone_number = v_wallet_transact.destination 
       			and t.currency_id  = v_wallet_transact.destination_currency_id and c.client_id = t.client_id  and c.client_type_id = 5
       			and t.currency_id = c.currency_id ; 
          if not found then
            return false;
        end if;
        v_source_client_type_id := 5;
        v_destination_client_type_id := 5;
    end if;


    select reverse_wallet_deposit( i_from_account_id => v_destination_account_id,
                            i_to_account_id   =>  v_source_account_id,
    						i_dr_amount => v_wallet_transact.transact_amount,
                            i_currency_id => v_wallet_transact.currency_id,
                            i_from_currency_id => v_wallet_transact.destination_currency_id,
                            i_group_id => i_id,
                            i_commission_amount=>v_wallet_transact.commission_amount)
    into v_res;
    if v_res = -1 then
        return false ;
    end if;
   
    update ib_wallet_transacts set state_id = 8 where id = i_id;
    return true;
exception
    when others THEN
        perform log_action_atx(i_id` || '', v_object_id, sqlerrm || 'reverse_wallet_transacts', 'ERROR');
        return false;
END;
$$;

alter function reverse_wallet_transact(bigint) owner to interhub_user;

