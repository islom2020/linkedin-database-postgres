create function get_service_field_values(i_id integer DEFAULT NULL::integer, i_title character varying DEFAULT NULL::character varying, i_field_id integer DEFAULT NULL::integer, i_parent_id integer DEFAULT NULL::integer) returns SETOF ib_service_field_values
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    rec         RECORD;
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_title is not null then
        v_condition := v_condition || ' and  t.title = ' || i_title;
    end if;
    if i_field_id is not null then
        v_condition := v_condition || ' and  t.field_id = ' || i_field_id;
    end if;
    if i_parent_id is not null then
        v_condition := v_condition || ' and t.parent_id = ' || i_parent_id;
    end if;

    return query execute 'select t.* 
                            FROM ib_service_field_values t   where 
                          1=1 ' || v_condition;

    IF NOT FOUND THEN
        perform log_action_atx(v_condition, 1, 'Данный не нфйден ид :get_service_field_values ' || 1, 'OK');
    END IF;
END;
$$;

alter function get_service_field_values(integer, varchar, integer, integer) owner to interhub_user;

