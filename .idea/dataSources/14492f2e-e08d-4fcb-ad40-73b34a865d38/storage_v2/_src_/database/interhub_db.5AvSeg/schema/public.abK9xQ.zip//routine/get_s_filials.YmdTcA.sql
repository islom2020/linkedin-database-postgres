create function get_s_filials(i_id integer DEFAULT NULL::integer, i_name character varying DEFAULT NULL::character varying, i_condition character varying DEFAULT NULL::character varying) returns SETOF ib_s_filials
    language plpgsql
as
$$
DECLARE
v_object_id integer := 3;
v_condition varchar := '';
rec RECORD;
BEGIN
 if i_id is not null then 
    v_condition  := v_condition || ' and t.id = ' || i_id;
end if;

 if i_condition  is not null then 
    v_condition  := v_condition || ' and t.condition  = ''' || i_condition ||'''';
end if;
if i_name is not null then 
    v_condition  := v_condition || ' and lower(t.name) like ''%' ||lower(i_name) || '%'||  ''''; 
end if;
     return query  execute   'SELECT
             t.*        
        from public.ib_s_filials t where 1=1 ' ||v_condition ; 
exception when others then 
        if i_id is not null then  
            perform log_action_atx(i_id || '' ,  v_object_id,'Данный не нaйден ид :' || i_id,  'ERROR');
         else 
           perform log_action_atx('ib_s_filials' ,  v_object_id,'Данный не нaйден ид ib_s_filials :' || i_id,  'ERROR');
         end if;
END;
$$;

alter function get_s_filials(integer, varchar, varchar) owner to interhub_user;

