create function add_jur_wallet_child(i_name character varying, i_parent_wallet_id integer, i_account_id integer, i_type character varying, i_token character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 5; 
begin
	if i_parent_wallet_id is null then 
		raise 'wallet id can not null ';
	end if;
insert 	into ib_jur_wallet_childs (name ,  parent_wallet_id ,  account_id ,"token" ,   "type"  )
values(i_name ,
i_parent_wallet_id ,
i_account_id ,
i_token ,
i_type );
	return true;
	exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_parent_wallet_id  || '' , v_object_id,
                               v_err_text || ' add_jur_wallet_child',
                               'ERROR');
        return false;
END;
$$;

alter function add_jur_wallet_child(varchar, integer, integer, varchar, varchar) owner to interhub_user;

