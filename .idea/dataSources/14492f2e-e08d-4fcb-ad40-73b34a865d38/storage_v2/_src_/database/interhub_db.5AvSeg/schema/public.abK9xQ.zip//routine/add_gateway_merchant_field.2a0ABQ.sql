create function add_gateway_merchant_field(i_code character varying, i_service_field_id integer DEFAULT NULL::integer, i_description character varying DEFAULT NULL::character varying, i_ordered integer DEFAULT NULL::integer, i_min_length integer DEFAULT NULL::integer, i_field_type character varying DEFAULT NULL::character varying, i_is_required character varying DEFAULT NULL::character varying, i_gateway_merch_id integer DEFAULT NULL::integer, i_max_length integer DEFAULT NULL::integer, i_regexp character varying DEFAULT NULL::character varying, i_title character varying DEFAULT NULL::character varying, i_example character varying DEFAULT NULL::character varying, i_custom_type character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_id_max             integer;
    v_object_id constant integer := 1;
BEGIN
    INSERT INTO public.ib_gateway_merchant_fields ( code
                                          , description
                                          , ordered
                                          , min_length
                                          , field_type 
                                          , is_required
                                          , gateway_merch_id
                                          , max_length
                                          , regexp
                                          , title
                                          , example 
                                          , service_field_id
                                          ,custom_type
                                          )
    VALUES (i_code,
            i_description,
            i_ordered,
            i_min_length,
            i_field_type, 
            i_is_required,
            i_gateway_merch_id
                , i_max_length
                                          , i_regexp
                                          , i_title
                                          , i_example
                                         ,i_service_field_id
                                         ,i_custom_type);
    return true;
exception
    when others THEN
        select max(id) into v_id_max from ib_gateway_merchant_fields;
        perform log_action_atx(v_id_max ||'', v_object_id, sqlerrm || ' ib_gateway_merchant_fields ', 'ERROR');
        return false;
END;
$$;

alter function add_gateway_merchant_field(varchar, integer, varchar, integer, integer, varchar, varchar, integer, integer, varchar, varchar, varchar, varchar) owner to interhub_user;

