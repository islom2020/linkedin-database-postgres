create view ib_v_operation_list_wallet
            (group_id, debit_amount, source_currency_id, credit_amount, destination_currency_id, comission_amount,
             source_client_name, source_client_id, destination_client_name, destination_client_id, credit_account,
             debit_account, deposit_date, transact_type, count)
as
SELECT t.group_id,
       max(a.transact_amount)          AS debit_amount,
       max(a.currency_id)              AS source_currency_id,
       max(a.destination_amount)       AS credit_amount,
       max(a.destination_currency_id)  AS destination_currency_id,
       max(a.commission_amount)        AS comission_amount,
       CASE max(a.payment_type)
           WHEN 1 THEN (SELECT max(cl.client_name::text) AS max
                        FROM ib_clients cl,
                             ib_agents ag
                        WHERE ag.client_id = cl.id
                          AND ag.id = max(a.source::text)::integer)
           ELSE (SELECT max(ag.fullname::text) AS max
                 FROM ib_wallets ag
                 WHERE ag.phone_number::text = max(a.source::text))
           END                         AS source_client_name,
       CASE max(a.payment_type)
           WHEN 1 THEN (SELECT max(cl.id) AS max
                        FROM ib_clients cl,
                             ib_agents ag
                        WHERE ag.client_id = cl.id
                          AND ag.id = max(a.source::text)::integer)
           ELSE (SELECT max(ag.client_id) AS max
                 FROM ib_wallets ag
                 WHERE ag.phone_number::text = max(a.source::text))
           END                         AS source_client_id,
       CASE max(a.payment_type)
           WHEN 2 THEN (SELECT max(cl.client_name::text) AS max
                        FROM ib_clients cl,
                             ib_agents ag
                        WHERE ag.client_id = cl.id
                          AND ag.id = max(a.destination::text)::integer)
           ELSE (SELECT max(ag.fullname::text) AS max
                 FROM ib_wallets ag
                 WHERE ag.phone_number::text = max(a.destination::text))
           END                         AS destination_client_name,
       CASE max(a.payment_type)
           WHEN 2 THEN (SELECT max(cl.id) AS max
                        FROM ib_clients cl,
                             ib_agents ag
                        WHERE ag.client_id = cl.id
                          AND ag.id = max(a.destination::text)::integer)
           ELSE (SELECT max(ag.client_id) AS max
                 FROM ib_wallets ag
                 WHERE ag.phone_number::text = max(a.destination::text))
           END                         AS destination_client_id,
       (SELECT f.client_account
        FROM ib_client_accounts f,
             ib_client_deposit r
        WHERE f.id = r.account_id
          AND r.credit_amount = max(t.credit_amount)
          AND r.group_id = t.group_id) AS credit_account,
       (SELECT f.client_account
        FROM ib_client_accounts f,
             ib_client_deposit r
        WHERE f.id = r.account_id
          AND r.debit_amount = max(t.debit_amount)
          AND r.group_id = t.group_id) AS debit_account,
       max(t.deposit_date)             AS deposit_date,
       'W'::text                       AS transact_type,
       1                               AS count
FROM ib_client_deposit t,
     ib_client_accounts c,
     ib_wallet_transacts a
WHERE a.id = t.group_id
  AND c.id = t.account_id
GROUP BY t.group_id;

alter table ib_v_operation_list_wallet
    owner to interhub_user;

