create function log_action_atx(i_reference_id character varying, i_object_id integer, i_text character varying, i_code character varying) returns void
    language plpgsql
as
$$
DECLARE
    v_date timestamp    := now();
    v_user integer := 2;
BEGIN
    insert into ib_protocols (reference_id, object_id, error_backtrace, created_date, created_by, code)
    values (i_reference_id, i_object_id, i_text, v_date, v_user, i_code);

END;
$$;

alter function log_action_atx(varchar, integer, varchar, varchar) owner to interhub_user;

