create function get_agent_merchant_page(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_id integer DEFAULT NULL::integer, i_agent_id integer DEFAULT NULL::integer, i_merchant_id integer DEFAULT NULL::integer, i_state_id integer DEFAULT NULL::integer, i_is_main character varying DEFAULT NULL::character varying, i_currency_id integer DEFAULT NULL::integer, i_ordered_by character varying DEFAULT NULL::character varying, i_is_desc character varying DEFAULT NULL::character varying)
    returns TABLE(id integer, agent_id integer, merchant_id integer, commission_down numeric, commission_to_agent numeric, commission_from_agent numeric, currency_id integer, min_amount numeric, max_amount numeric, state_id integer, is_main character varying, count integer)
    language plpgsql
as
$$
DECLARE
    v_ref_id    varchar := '';
    rec         RECORD;
v_agent_merchant_count integer;
   v_condition varchar := '';
begin
	if i_ordered_by is   null then
       i_ordered_by := '1';
    end if;
   if i_is_desc  ='Y' then
       i_ordered_by := i_ordered_by || ' desc ';
    end if;
   
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_currency_id is not null then
        v_condition := v_condition || ' and t.currency_id = ' || i_currency_id;
    end if;
   
    if i_agent_id is not null then
        v_condition := v_condition || ' and t.agent_id = ' || i_agent_id ;
    end if;
    if i_merchant_id is not null then
        v_condition := v_condition || ' and  t.merchant_id = ' || i_merchant_id ;
    end if;
    if i_is_main is not null then
        v_condition := v_condition || ' and  t.is_main = ''' || i_is_main||'''' ;
    end if;
   if i_state_id is not null then
        v_condition := v_condition || ' and t.state_id  = ' || i_state_id ;
    end if;
       EXECUTE 'select  count(*)  from ib_agent_merchant t where 1=1 ' || v_condition into v_agent_merchant_count;

    RETURN QUERY
        execute 'SELECT id ,
 agent_id ,
 merchant_id  ,
 commission_down ,
 commission_to_agent ,
 commission_from_agent  ,
 currency_id  ,
min_amount ,
 max_amount ,
state_id, is_main ,' || v_agent_merchant_count || '  as count  FROM ib_agent_merchant t  WHERE  1= 1 ' || v_condition||
                         ' order by ' || i_ordered_by  ||' limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;
    IF NOT FOUND THEN
        if i_id is not null then
            v_ref_id := i_id || '';
        elsif i_agent_id is not null then
            v_ref_id := i_agent_id || '' ;
        elsif i_merchant_id is not null then
            v_ref_id := i_merchant_id || '';
        else
            v_ref_id := 'agent_merchant';
        end if;

        perform log_action_atx(v_ref_id, 2, 'Агент Данный не найден : ' || v_ref_id, 'ERROR');
    END IF;
END;
$$;

alter function get_agent_merchant_page(integer, integer, integer, integer, integer, integer, varchar, integer, varchar, varchar) owner to interhub_user;

