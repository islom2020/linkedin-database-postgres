create function get_gateway_field_values(i_id integer DEFAULT NULL::integer, i_title character varying DEFAULT NULL::character varying, i_field_id integer DEFAULT NULL::integer, i_service_field_value_id integer DEFAULT NULL::integer, i_gateway_value_ids character varying DEFAULT NULL::character varying) returns SETOF ib_gateway_field_values
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    rec         RECORD;
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_title is not null then
        v_condition := v_condition || ' and  t.title = ''' || i_title||'''';
    end if;
     if i_gateway_value_ids is not null then
        v_condition := v_condition || ' and  t.gateway_value_ids = ''' || i_gateway_value_ids||'''';
    end if;
    if i_field_id is not null then
        v_condition := v_condition || ' and  t.field_id = ' || i_field_id;
    end if;
    
  if i_service_field_value_id is not null then
        v_condition := v_condition || ' and t.service_field_value_id = ' || i_service_field_value_id;
    end if;
    return query execute 'select t.* 
                            FROM ib_gateway_field_values t  where 
                          1=1 ' || v_condition;

    IF NOT FOUND THEN
        perform log_action_atx(v_condition, 1, 'Данный не нфйден ид :ib_gateway_field_values ' || 1, 'OK');
    END IF;
END;
$$;

alter function get_gateway_field_values(integer, varchar, integer, integer, varchar) owner to interhub_user;

