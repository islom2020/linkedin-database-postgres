create function get_s_banks(i_filial_code character varying DEFAULT NULL::character varying, i_bank_name character varying DEFAULT NULL::character varying) returns SETOF ib_s_banks
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 5;
     v_condition varchar := '';
    begin 
	    
	     
	     if i_filial_code  is not null then
       		 v_condition := v_condition || ' and t.filial_code  =  ''' || i_filial_code ||'''';
   		 end if;
   	 
   		 
   		 	if i_bank_name is not null then
       		 v_condition := v_condition || ' and t.bank_name like ' ||  '''%|| i_bank_name%' || '''' ;
   		 end if;
   		  
   		return query execute ' SELECT  t.* FROM ib_s_banks  t
      WHERE   1= 1 ' || v_condition;
  exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(v_condition, v_object_id, v_err_text || 'ib_s_banks', 'ERROR');
        
END;
$$;

alter function get_s_banks(varchar, varchar) owner to interhub_user;

