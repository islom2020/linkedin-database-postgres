create function get_wallet_types(i_id integer DEFAULT NULL::integer, i_type_name character varying DEFAULT NULL::character varying, i_condition character varying DEFAULT NULL::character varying) returns SETOF ib_wallet_types
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
    v_condition varchar := '';
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;

    if i_condition is not null then
        v_condition := v_condition || ' and t.condition = ' || i_condition;
    end if;
    if i_type_name is not null then
        v_condition := v_condition || 'and lower(t.type_name ) like ''%' || lower(i_type_name) || '%' || '''';
    end if;

    RETURN QUERY
        execute 'SELECT * FROM ib_wallet_types t  WHERE  1= 1 ' || v_condition;
    IF NOT FOUND THEN
        perform log_action_atx(v_condition, 5, 'wallet type not found  : get_client_wallet ' || v_condition, 'ERROR');
    END IF;
END ;
$$;

alter function get_wallet_types(integer, varchar, varchar) owner to interhub_user;

