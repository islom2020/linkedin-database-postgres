create function edit_settings(i_key character varying, i_value character varying, i_condition character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 2;
BEGIN
    update ib_settings
    set value     =i_value,
        condition =i_condition
    where key = i_key;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx('ih_settings update', v_object_id, v_err_text, 'ERROR');
        return false;
END;
$$;

alter function edit_settings(varchar, varchar, varchar) owner to interhub_user;

