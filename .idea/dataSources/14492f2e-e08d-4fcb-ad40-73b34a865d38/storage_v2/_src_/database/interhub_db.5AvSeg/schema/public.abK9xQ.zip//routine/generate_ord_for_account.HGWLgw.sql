create function generate_ord_for_account(i_count integer) returns character varying
    language plpgsql
as
$$
DECLARE
    v_err_text varchar:='';
    v_ord_id varchar:=''||(i_count+1);
begin
    LOOP
        EXIT WHEN length(v_ord_id) = 3 ;

        v_ord_id := '0'||v_ord_id;
    END LOOP ;
    return  v_ord_id;
exception
    when others THEN
        v_err_text := sqlerrm;
END ;
$$;

alter function generate_ord_for_account(integer) owner to interhub_user;

