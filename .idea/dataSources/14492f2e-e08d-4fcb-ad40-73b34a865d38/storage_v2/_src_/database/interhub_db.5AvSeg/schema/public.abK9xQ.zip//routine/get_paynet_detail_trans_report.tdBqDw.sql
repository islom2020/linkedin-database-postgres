create function get_paynet_detail_trans_report(i_from_date character varying, i_to_date character varying)
    returns TABLE(start_id bigint, end_id bigint)
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_created_by         integer := 1;
    v_object_id constant integer := 2;
   v_client_account ib_Client_accounts%rowtype;
--  v_over_cleint_account 	ib_Client_accounts%rowtype;
	v_start_id bigint;
	v_end_id bigint;
BEGIN 
	
	select  r.id into v_start_id  from ib_transacts r
    			where (r.transact_date ,r.id) in( select min(t.transact_date )  , min(t.id)       
    				from ib_transacts t where t.transact_date >=
       				to_date(i_from_date , 'dd.mm.yyyy')  
       				and  t.transact_date <= to_date(i_to_date , 'dd.mm.yyyy') ) ;  
       		select  r.id into v_end_id  from ib_transacts r
    			where (r.transact_date ,r.id) in 	  ( select max(t.transact_date )  , max(t.id)       
    				from ib_transacts t where t.transact_date >=
       				to_date(i_from_date , 'dd.mm.yyyy')  
       				and  t.transact_date <= to_date(i_to_date , 'dd.mm.yyyy') );
	 return  query select v_start_id as state_id ,  v_end_id as end_id ;
   
	 
 exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_from_date || '', v_object_id, v_err_text, 'ERROR');
        
END;
$$;

alter function get_paynet_detail_trans_report(varchar, varchar) owner to interhub_user;

