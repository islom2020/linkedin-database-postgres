create function get_agent_merchant(i_id integer DEFAULT NULL::integer, i_agent_id integer DEFAULT NULL::integer, i_merchant_id integer DEFAULT NULL::integer, i_state_id integer DEFAULT NULL::integer, i_is_main character varying DEFAULT NULL::character varying, i_currency_id integer DEFAULT NULL::integer) returns SETOF ib_agent_merchant
    language plpgsql
as
$$
DECLARE
    v_ref_id    varchar := '';
    rec         RECORD;
    v_condition varchar := '';
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_agent_id is not null then
        v_condition := v_condition || ' and t.agent_id = ' || i_agent_id ;
    end if;
    if i_merchant_id is not null then
        v_condition := v_condition || ' and  t.merchant_id = ' || i_merchant_id ;
    end if;
   
     if i_currency_id is not null then
        v_condition := v_condition || ' and  t.currency_id = ' || i_currency_id ;
    end if;
       if i_is_main is not null then
        v_condition := v_condition || ' and  t.is_main = ' || i_is_main ;
    end if;
    if i_state_id is not null then
        v_condition := v_condition || ' and t.state_id  = ' || i_state_id ;
    end if;
    RETURN QUERY
        execute 'SELECT * FROM ib_agent_merchant t  WHERE  1= 1 ' || v_condition;
    IF NOT FOUND THEN
        if i_id is not null then
            v_ref_id := i_id || '';
        elsif i_agent_id is not null then
            v_ref_id := i_agent_id || '' ;
        elsif i_merchant_id is not null then
            v_ref_id := i_merchant_id || '';
        else
            v_ref_id := 'agent_merchant';
        end if;

        perform log_action_atx(v_ref_id, 2, 'Агент Данный не найден : ' || v_ref_id, 'ERROR');
    END IF;
END;
$$;

alter function get_agent_merchant(integer, integer, integer, integer, varchar, integer) owner to interhub_user;

