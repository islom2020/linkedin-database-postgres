create function setting_over_account(i_id integer, i_is_overdraft character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_created_by         integer := 1;
    v_object_id constant integer := 2;
   v_client_account ib_Client_accounts%rowtype;
  v_over_cleint_account 	ib_Client_accounts%rowtype;
BEGIN
    select  t.* into v_client_account
    from ib_client_accounts t 
    where t.id  =  i_id  for update ;
   if not found then
        v_err_text := 'takaya id ne nayden ';
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
    end if;
   
   if i_is_overdraft ='Y' then 
   		select * into v_over_cleint_account 
   				from ib_client_accounts r where 
   			r.client_id  = v_client_account.client_id and 
   			r.currency_id = v_client_account.currency_id and
   			r.client_type_id =v_client_account.client_type_id;
   		 	if not found then
		        v_err_text := ' over_account  can not find ';
		        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
		        return false;
    		end if;
   	update ib_client_accounts set is_overdraft =  'Y' where id  =  i_id;
   elsif i_is_overdraft ='N' then 
   		select * into v_over_cleint_account 
   				from ib_client_accounts r where 
   			r.client_id  = v_client_account.client_id and 
   			r.currency_id = v_client_account.currency_id and
   			r.client_type_id =v_client_account.client_type_id;
   		 	if not found then
		        v_err_text := ' over_account  can not find ';
		        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
		        return false;
    		end if;
    	if v_over_cleint_account.balance != 0  then 
    		 	 perform log_action_atx(i_id || '', v_object_id, 'qarzdorlikni yopishingiz kerak ', 'ERROR');
		        return false;
    	end if;
    update ib_client_accounts set is_overdraft =  'Y' where id  =  i_id;
   end if;
    
   
   return true ;
 exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
END;
$$;

alter function setting_over_account(integer, varchar) owner to interhub_user;

