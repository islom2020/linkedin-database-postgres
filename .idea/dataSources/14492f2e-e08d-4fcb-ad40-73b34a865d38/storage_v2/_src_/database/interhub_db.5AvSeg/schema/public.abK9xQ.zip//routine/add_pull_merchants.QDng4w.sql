create function add_pull_merchants(i_gateway_merchant_id integer, i_merchant_id integer, i_gateway_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 1;
BEGIN
    insert into
	ib_S_pull_merchants ( gateway_merchant_id,
	merchant_id ,
	gateway_id)
    values ( 
            i_gateway_merchant_id,
            i_merchant_id,
            i_gateway_id  );
    return true;
exception
    when others THEN 
        perform log_action_atx(i_gateway_merchant_id ||'', v_object_id, sqlerrm ||' ib_S_pull_merchants', 'ERROR');
        return false;
END;
$$;

alter function add_pull_merchants(integer, integer, integer) owner to interhub_user;

