create view test_view_transacts
            (id, agent_id, state_id, client_account, currency_id, gateway_merchant_id, merchant_id, transact_date,
             agent_transact_id, gateway_transact_id, payment_type_id, params, commission_amount, created_date,
             transact_amount, amount_in_currency, info, amount_out_currency, tran_type)
as
SELECT t.id,
       t.agent_id,
       t.state_id,
       t.client_account,
       t.destination_currency_id AS currency_id,
       t.gateway_merchant_id,
       t.merchant_id,
       t.transact_date,
       t.agent_transact_id,
       t.gateway_transact_id,
       t.payment_type_id,
       t.params,
       t.commission_amount,
       t.created_date,
       t.transact_amount,
       t.amount_in_currency,
       t.info,
       t.amount_out_currency,
       t.tran_type
FROM ib_transacts t
WHERE t.state_id = 6
  AND NOT (EXISTS(SELECT icd.id,
                         icd.account_id,
                         icd.debit_amount,
                         icd.credit_amount,
                         icd.balance,
                         icd.group_id,
                         icd.deposit_date
                  FROM ib_client_deposit icd
                  WHERE icd.group_id = t.id))
  AND t.agent_id = 5
LIMIT 500;

alter table test_view_transacts
    owner to interhub_user;

