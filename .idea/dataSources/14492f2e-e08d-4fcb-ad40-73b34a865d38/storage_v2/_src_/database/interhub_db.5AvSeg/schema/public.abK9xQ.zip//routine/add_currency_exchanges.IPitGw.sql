create function add_currency_exchanges(i_amount numeric, i_from_currency_id integer, i_to_currency_id integer) returns boolean
    language plpgsql
as
$$
declare
	v_amount numeric;
begin
	 
	if i_Amount = 0 then 
		return false ;
	end if;
 	if i_from_currency_id  in ( 840,978) and i_to_currency_id = 643    then 
		  update ib_s_currency_exchanges  t set amount  =  1/i_amount  , modified_date = now()
	  	where from_currency_id  =  i_to_currency_id  and  to_currency_id  = i_from_currency_id; 
	  begin 
			  insert into ib_s_currency_exchanges_his 
			  (from_currency_id  ,
				to_currency_id  ,
				amount , 
				modified_by )values (
					i_from_currency_id,
					i_to_currency_id,
					i_amount,
					1
			);
		exception when others then 
			 perform log_action_atx(i_from_currency_id || '', 10, sqlerrm || 'add_currency_exchanges ', 'ERROR');
		end ;
	  
	end if; 
	  update ib_s_currency_exchanges  t set amount  =  i_amount  , modified_date = now()
	  	where from_currency_id  =  i_from_currency_id  and  to_currency_id  =i_to_currency_id; 
return true;
	  exception when others then 
	  perform log_action_atx(i_from_currency_id || '', 10, sqlerrm || 'add_exchange_amount ', 'ERROR');
        return false ;
end;
$$;

alter function add_currency_exchanges(numeric, integer, integer) owner to interhub_user;

