create function get_settings(i_key character varying DEFAULT NULL::character varying, i_condition character varying DEFAULT NULL::character varying) returns SETOF ib_settings
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
    v_condition varchar := '';
BEGIN
    if i_key is not null then
        v_condition := v_condition || ' and t.key =''' || i_key || '''';
    end if;
    if i_condition is not null then
        v_condition := v_condition || ' and  t.condition  = ''' || i_condition || '''';
    end if;
    RETURN QUERY
        execute 'SELECT * FROM ib_settings t  WHERE  1= 1 ' || v_condition;
    IF NOT FOUND THEN
        perform log_action_atx(v_condition, 2, 'Агент Данный не найден :get_settings ' || v_condition, 'ERROR');
    END IF;
END;
$$;

alter function get_settings(varchar, varchar) owner to interhub_user;

