create function ib_transacts_insert_function() returns trigger
    language plpgsql
as
$$
DECLARE
    partition_date    TEXT;
    partition_name    TEXT;
    start_of_month    TEXT;
    end_of_next_month TEXT;
BEGIN
    partition_date := to_char(NEW.transact_date, 'YYYY_MM');
    partition_name := 'ib_transacts_' || partition_date;
    start_of_month := to_char((NEW.transact_date), 'YYYY-MM') || '-01';
    end_of_next_month := to_char((NEW.transact_date + interval '1 month'), 'YYYY-MM') || '-01';
    IF NOT EXISTS
        (SELECT *
         FROM information_schema.tables
         WHERE table_name = partition_name)
    THEN
        RAISE NOTICE 'A partition has been created %', partition_name;
        EXECUTE format(
                E'CREATE TABLE %I (CHECK ( date_trunc(\'day\', transact_date) >= ''%s'' AND date_trunc(\'day\', transact_date) < ''%s'')) INHERITS (public.ib_transacts)',
                partition_name, start_of_month, end_of_next_month);
        -- EXECUTE format('GRANT SELECT ON TABLE %I TO readonly', partition_name); -- use this if you use role based permission
             EXECUTE 'alter table ' || partition_name || ' add primary key   (id) '; 
                EXECUTE 'CREATE   INDEX '  || partition_name || '_agent_gatwey_idx ON '  ||   partition_name || ' (agent_id,  state_id ,  currency_id )';
           EXECUTE ' ALTER TABLE '|| partition_name||'  ADD CONSTRAINT uk_agent_'||partition_name||'  UNIQUE  (agent_id , agent_transact_id) '; 
            
    END IF;
    EXECUTE format('INSERT INTO %I (  
      id
    , agent_id
    , state_id
    , client_account
    , destination_currency_id
    , gateway_merchant_id
    , merchant_id
    , transact_date
    , agent_transact_id
    , gateway_transact_id
    , payment_type_id
    , params
    , commission_amount
    , created_date
    , transact_amount
    , amount_in_currency
    , info  
	,  amount_out_currency
	, tran_type
	,gateway_transact_date
	,source_currency_id) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21)', partition_name) using
      NEW.id
    , NEW.agent_id
    , NEW.state_id
    , NEW.client_account
    , NEW.destination_currency_id
    , NEW.gateway_merchant_id
    , NEW.merchant_id
    , NEW.transact_date
    , NEW.agent_transact_id
    , NEW.gateway_transact_id
    , NEW.payment_type_id
    , NEW.params
    , NEW.commission_amount
    , NEW.created_date
    , NEW.transact_amount
    , NEW.amount_in_currency
    , NEW.info
    , new.amount_out_currency
    ,new.tran_type
    ,new.gateway_transact_date
    ,new.source_currency_id;
    RETURN NULL;
END
$$;

alter function ib_transacts_insert_function() owner to interhub_user;

