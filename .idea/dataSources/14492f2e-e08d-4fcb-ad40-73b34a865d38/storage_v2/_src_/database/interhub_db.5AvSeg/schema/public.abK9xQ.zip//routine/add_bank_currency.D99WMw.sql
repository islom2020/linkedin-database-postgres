create function add_bank_currency(i_currency_id integer, i_purchase_amount numeric, i_sell_amount numeric, i_currency_date date DEFAULT NULL::date) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_date               timestamp    := now();
    v_object_id constant integer := 6;
    v_count              integer := 0 ;
    v_price              numeric  := 0;
    
BEGIN

     
    begin 
        insert into ib_bank_currencies ( currency_id
                                  , purchase_amount
                                  ,sell_amount
                                  , currency_date  )
        values (i_currency_id,
                i_purchase_amount,
                i_sell_amount,
                i_currency_date );
   exception   WHEN unique_violation THEN  
   			insert into ib_bank_currencies_his select * from ib_bank_currencies  where currency_id =  i_currency_id ;
   		delete from ib_bank_currencies where currency_id = i_currency_id;
	   	 insert into ib_bank_currencies ( currency_id
	                                  , purchase_amount
	                                  ,sell_amount
	                                  , currency_date  )
	        values (i_currency_id,
	                i_purchase_amount,
	                i_sell_amount,
	                i_currency_date );
   end;
   
     
    return true;
exception
    when others THEN
        
        perform log_action_atx(i_currency_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
END;
$$;

alter function add_bank_currency(integer, numeric, numeric, date) owner to interhub_user;

