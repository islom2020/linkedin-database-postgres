create function add_client(i_client_name character varying, i_client_type character varying, i_client_inn character varying DEFAULT NULL::character varying, i_phone_number character varying DEFAULT NULL::character varying, i_address character varying DEFAULT NULL::character varying, i_condition character varying DEFAULT 'A'::character varying, i_client_wallet_type integer DEFAULT NULL::integer, i_info character varying DEFAULT NULL::character varying) returns integer
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_object_id constant integer := 1;
    v_id                 integer;
    v_client_code        varchar;
BEGIN
    insert into ib_clients ( client_name
                           , client_type
                           , address
                           , client_inn
                           , condition
                           , phone_number
                           ,client_wallet_type
                            ,info)
    values (i_client_name, i_client_type, i_address, i_client_inn, i_condition, i_phone_number,i_client_wallet_type,i_info)
    returning id into v_id;

    return v_id;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_client_name, v_object_id, v_err_text || 'add_client', 'ERROR');
        return 0;
END;
$$;

alter function add_client(varchar, varchar, varchar, varchar, varchar, varchar, integer, varchar) owner to interhub_user;

