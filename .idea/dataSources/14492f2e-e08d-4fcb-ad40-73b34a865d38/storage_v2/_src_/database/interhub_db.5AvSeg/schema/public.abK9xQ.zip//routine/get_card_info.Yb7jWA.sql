create function get_card_info(i_card_id integer) returns SETOF ib_cards_info
    language plpgsql
as
$$
DECLARE
    v_user   integer := 2;
    v_ref_id integer;
begin
		return query select * from ib_cards_info t where t.card_id =  i_card_id ;	
	END;
$$;

alter function get_card_info(integer) owner to interhub_user;

