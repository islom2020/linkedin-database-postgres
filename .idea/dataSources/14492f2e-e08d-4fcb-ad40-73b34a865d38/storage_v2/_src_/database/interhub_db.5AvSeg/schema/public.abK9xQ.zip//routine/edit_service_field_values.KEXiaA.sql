create function edit_service_field_values(i_id integer, i_title character varying DEFAULT NULL::character varying, i_field_id integer DEFAULT NULL::integer, i_parent_id integer DEFAULT NULL::integer) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_created_by         integer := 1;
    v_object_id constant integer := 2;
   v_title varchar ;
   v_field_id integer ;
  v_parent_id integer;
 v_service_field_value_id integer;
    v_name               varchar(300);
BEGIN
    select   title, field_id, parent_id 
    into
         v_title, v_field_id, v_parent_id 
    from ib_service_field_values
    where id = i_id;
    if not found then
        v_err_text := 'takaya id ne nayden ';
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
    end if;

    if i_title is null then
        i_title := v_title;
    end if;
 	if i_field_id is null then
        i_field_id := v_field_id;
    end if;
    if i_parent_id is null then
        i_parent_id := v_parent_id;
    end if; 
   
    update ib_service_field_values
    set  title = i_title,
    field_id=  i_field_id,
    parent_id =i_parent_id
    where id = i_id;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
END;
$$;

alter function edit_service_field_values(integer, varchar, integer, integer) owner to interhub_user;

