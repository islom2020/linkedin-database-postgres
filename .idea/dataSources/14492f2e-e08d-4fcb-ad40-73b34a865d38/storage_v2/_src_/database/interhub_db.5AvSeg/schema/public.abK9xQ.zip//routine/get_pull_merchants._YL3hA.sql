create function get_pull_merchants(i_id integer DEFAULT NULL::integer, i_gateway_merchant_id integer DEFAULT NULL::integer, i_gateway_id integer DEFAULT NULL::integer, i_merchant_id integer DEFAULT NULL::integer) returns SETOF ib_s_pull_merchants
    language plpgsql
as
$$
DECLARE
	v_gateway_merchants varchar='';
   v_condition varchar := '';

BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
   
     if i_gateway_id is not null then
		 v_condition := v_condition || ' and t.gateway_id  = ' || i_gateway_id ;
    end if;
   
    if i_gateway_merchant_id is not null then
        v_condition := v_condition || ' and t.gateway_merchant_id  = ' || i_gateway_merchant_id ;
    end if;
   if i_merchant_id is not null then
        v_condition := v_condition || ' and t.merchant_id  = ' || i_merchant_id ;
    end if;
  
    return query execute ' SELECT  t.* FROM ib_s_pull_merchants  t
      WHERE   1= 1 ' || v_condition;

    IF NOT FOUND THEN
        perform log_action_atx(v_condition || '', 2, 'Данный не нaйден ид :' || v_condition, 'OK');
    END IF;
END;
$$;

alter function get_pull_merchants(integer, integer, integer, integer) owner to interhub_user;

