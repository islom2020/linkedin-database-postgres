create function get_bank_currencies_his(i_currency_id integer DEFAULT NULL::integer, i_currency_date character varying DEFAULT NULL::character varying) returns SETOF ib_bank_currencies
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    v_date      date    := now();
BEGIN
    if i_currency_id is not null then
        v_condition := ' and c.currency_id = ' || i_currency_id;
    end if;
   if i_currency_date is not null then
        v_condition := v_condition ||
                       ' and  to_char( t.created_date, ''dd.mm.yyyy'' )  = ''' ||
                       i_currency_date || '''';
    end if;
    return query execute ' SELECT  c.*
            FROM   ib_bank_currencies c
      WHERE  1 = 1 ' || v_condition;

END;
$$;

alter function get_bank_currencies_his(integer, varchar) owner to interhub_user;

