create function get_gateway_merchant_page(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_id integer DEFAULT NULL::integer, i_gateway_id integer DEFAULT NULL::integer, i_category_id integer DEFAULT NULL::integer, i_can_check_request integer DEFAULT NULL::integer, i_state_id integer DEFAULT NULL::integer, i_merchant_id integer DEFAULT NULL::integer, i_ordered_by character varying DEFAULT NULL::character varying, i_is_desc character varying DEFAULT NULL::character varying, i_gateway_merchant_id integer DEFAULT NULL::integer)
    returns TABLE(id integer, name character varying, gateway_id integer, min_amount bigint, max_amount bigint, state_id integer, created_by integer, created_date date, commission_up numeric, commission_down numeric, gateway_merchant_id integer, gateway_check_id integer, gateway_pay_id integer, currency_id integer, category_id integer, info character varying, can_check_request integer, merchant_id integer, count integer)
    language plpgsql
as
$$
DECLARE
    v_object_id integer := 3;
    v_condition varchar := '';
   v_gateway_merchant_count integer;
    rec         RECORD;
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
   	if i_ordered_by is   null then
       i_ordered_by := '1';
    end if;
      if i_is_desc  ='Y' then
       i_ordered_by := i_ordered_by || ' desc ';
    end if;
   if i_category_id is not null then
        v_condition := v_condition || ' and t.category_id = ' || i_category_id;
    end if;
    if i_merchant_id is not null then
        v_condition := v_condition || ' and t.merchant_id = ' || i_merchant_id ;
    end if;
     if i_gateway_merchant_id is not null then
        v_condition := v_condition || ' and t.gateway_merchant_id = ' || i_gateway_merchant_id ;
    end if;
    if i_gateway_id is not null then
        v_condition := v_condition || ' and t.gateway_id = ' || i_gateway_id;
    end if;
     if i_Can_check_request is not null then
        v_condition := v_condition || ' and t.Can_check_request = ' || i_Can_check_request;
    end if;
      if i_state_id is not null then
        v_condition := v_condition || ' and t.state_id  = ' || i_state_id ;
    end if;
       EXECUTE 'select  count(*)  from ib_gateway_merchants t where 1=1 ' || v_condition into v_gateway_merchant_count;

    return query execute 'SELECT
            id ,
 name ,
 gateway_id ,
min_amount,
max_Amount ,
state_id,
created_by ,
created_date,
commission_up,
commission_down,
gateway_merchant_id,
gateway_check_id,
gateway_pay_id,
currency_id,
category_id, 
info,  Can_check_request,  merchant_id , '||   v_gateway_merchant_count || ' as count       
        from public.ib_gateway_merchants t where 1=1  and state_id  = 1 ' || v_condition||
                         ' order by '||i_ordered_by||'   limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;
exception
    when others then
        if i_id is not null then
            perform log_action_atx(i_id || '', v_object_id, 'Данный не нфйден ид :' || i_id, 'ERROR');
        else
            perform log_action_atx('gateway_merchant', v_object_id, 'Данный не нфйден ид :' || i_id, 'ERROR');
        end if;
END;
$$;

alter function get_gateway_merchant_page(integer, integer, integer, integer, integer, integer, integer, integer, varchar, varchar, integer) owner to interhub_user;

