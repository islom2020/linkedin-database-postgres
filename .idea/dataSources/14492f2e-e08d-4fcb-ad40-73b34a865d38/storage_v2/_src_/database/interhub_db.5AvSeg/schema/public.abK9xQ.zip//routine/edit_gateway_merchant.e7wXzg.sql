create function edit_gateway_merchant(i_id integer, i_name character varying DEFAULT NULL::character varying, i_gateway_id integer DEFAULT NULL::integer, i_min_amount bigint DEFAULT NULL::bigint, i_max_amount bigint DEFAULT NULL::bigint, i_state_id integer DEFAULT NULL::integer, i_commission_up numeric DEFAULT NULL::numeric, i_commission_down numeric DEFAULT NULL::numeric, i_gateway_name character varying DEFAULT NULL::character varying, i_gateway_merchant_id integer DEFAULT NULL::integer, i_gateway_check_id integer DEFAULT NULL::integer, i_gateway_pay_id integer DEFAULT NULL::integer, i_info character varying DEFAULT NULL::character varying, i_can_check_request integer DEFAULT NULL::integer, i_merchant_id integer DEFAULT NULL::integer, i_gateway_merchant_code character varying DEFAULT NULL::character varying, i_can_pay_request integer DEFAULT NULL::integer) returns boolean
    language plpgsql
as
$$
DECLARE

    v_err_text            varchar;
    v_created_by          integer := 2;
    v_object_id constant  integer := 3;
    v_name                character varying ;
    v_gateway_id          integer;
    v_min_amount          bigint ;
    v_max_amount          bigint ;
    v_state_id            integer ;
    v_commission_up       numeric ;
    v_commission_down     numeric ;
    v_currency_id         integer ;
    v_gateway_name        character varying ;
    v_gateway_merchant_id integer ;
    v_gateway_check_id    integer ;
    v_gateway_pay_id      integer ;
   	v_category_id		integer;
	   v_info 			varchar;
	  v_merchant_id  integer;
	  v_can_Check_request integer;
	 v_gateway_merchant_code varchar ;
	v_can_pay_request integer ;
BEGIN
    select name
         , gateway_id
         , min_amount
         , max_amount
         , state_id
         , commission_up
         , commission_down
         , name
         , gateway_merchant_id
         , gateway_check_id
         , gateway_pay_id
         , currency_id
         , category_id
         , info
         ,can_check_request
         ,merchant_id
         ,gateway_merchant_code ,
         can_pay_request
    into
        v_name
        , v_gateway_id
        , v_min_amount
        , v_max_amount
        , v_state_id
        , v_commission_up
        , v_commission_down
        , v_gateway_name
        , v_gateway_merchant_id
        , v_gateway_check_id
        , v_gateway_pay_id 
        ,v_currency_id 
        , v_category_id
        , v_info
        ,v_can_Check_request
        ,v_merchant_id
        ,v_gateway_merchant_code
        ,v_can_pay_request
    from ib_gateway_merchants
    where id = i_id;
    if not found then
        v_err_text := 'takaya merchant ne nayden ';
        perform log_action_atx(i_id, v_object_id, v_err_text || ' edit_gateway_merchants', 'ERROR');
        return false;
    end if;
    if i_name is null then
        i_name := v_name;
    end if;
    if i_min_amount is null then
        i_min_amount := v_min_amount;
    end if;
    if i_gateway_merchant_code is null then
        i_gateway_merchant_code := v_gateway_merchant_code;
    end if;
     if i_merchant_id is null then
        i_merchant_id := v_merchant_id;
    end if;
    if i_max_amount is null then
        i_max_amount := v_max_amount;
    end if;
    if i_commission_up is null then
        i_commission_up := v_commission_up;
    end if;

      if i_can_pay_request is null then
        i_can_pay_request := v_can_pay_request;
    end if;

   
    if i_gateway_id is null then
        i_gateway_id := v_gateway_id;
    end if;

     
     if i_info is null then
        i_info := v_info;
    end if;
    if i_state_id is null then
        i_state_id := i_state_id;
    end if;
    if i_commission_down is null then
        i_commission_down := v_commission_down;
    end if;
    if i_gateway_merchant_id is null then
        i_gateway_merchant_id := v_gateway_merchant_id;
    end if;
    if i_gateway_check_id is null then
        i_gateway_check_id := v_gateway_check_id;
    end if;
    if i_gateway_pay_id is null then
        i_gateway_pay_id := v_gateway_pay_id;
    end if;
     if i_can_check_request is null  then 
             i_can_check_request := v_can_check_request;
     end if;
    update ib_gateway_merchants
    set name                = i_name,
        gateway_merchant_id = i_gateway_merchant_id,
        min_amount          = i_min_amount,
        gateway_id          = i_gateway_id,
        max_amount          = i_max_amount,
        gateway_pay_id      = i_gateway_pay_id,
        gateway_check_id    = i_gateway_check_id,
        commission_up       =i_commission_up,
        commission_down  = i_commission_down,
        state_id            =i_state_id,
        info				=i_info,
        can_check_request  = i_can_check_request,
        merchant_id = i_merchant_id,
        gateway_merchant_code = i_gateway_merchant_code,
         can_pay_request =i_can_pay_request
    where id = i_id;
    return true;
exception
    when others THEN
        perform log_action_atx(i_id||'', v_object_id, sqlerrm || ' edit_gateway_merchants', 'ERROR');
        return false;
END;
$$;

alter function edit_gateway_merchant(integer, varchar, integer, bigint, bigint, integer, numeric, numeric, varchar, integer, integer, integer, varchar, integer, integer, varchar, integer) owner to interhub_user;

