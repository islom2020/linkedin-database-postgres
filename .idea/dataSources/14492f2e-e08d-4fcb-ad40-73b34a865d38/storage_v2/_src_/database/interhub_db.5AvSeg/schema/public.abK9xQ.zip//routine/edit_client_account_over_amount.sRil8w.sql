create function edit_client_account_over_amount(i_id integer, i_overdraft_amount numeric, i_dr_or_cr character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_created_by         integer := 1;
    v_object_id constant integer := 2;
   v_client_account ib_Client_accounts%rowtype;
  v_over_cleint_account 	ib_Client_accounts%rowtype;
BEGIN
    select  t.* into v_client_account
    from ib_client_accounts t 
    where t.id  =  i_id  for update ;
   if not found then
        v_err_text := 'takaya id ne nayden ';
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
    end if;
   
   
		select
			r.* 		into v_over_cleint_account
		from
			ib_client_accounts r
		where  r.client_type_id  = v_Client_account.client_type_id 
		and r.client_id  =  v_Client_account.client_id
		and r.account_type_id = 4 
		and r."condition"  = 'A' 
		and r.currency_id = v_Client_account.currency_id;
	  
    if not found then
        v_err_text := 'takaya id ne nayden ';
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
    end if;
	  if i_dr_or_cr ='DR' then 
			v_client_account.overdraft_amount := v_client_account.overdraft_amount + i_overdraft_amount;
		end if;		
    	if i_dr_or_cr ='CR' and ((v_client_account.overdraft_amount - i_overdraft_amount ) +v_over_cleint_account.balance)<0  then 
	 		raise 'overdraft summasi kam';			
		end if;
	if i_dr_or_cr ='CR' then 	 
		v_client_account.overdraft_amount := v_client_account.overdraft_amount - i_overdraft_amount;
	end if;
  update
			ib_client_accounts
		set
			overdraft_amount = v_client_account.overdraft_amount
		where id =  v_client_account.id ;
return true ;
 exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
END;
$$;

alter function edit_client_account_over_amount(integer, numeric, varchar) owner to interhub_user;

