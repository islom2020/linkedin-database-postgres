create function edit_card(i_id integer, i_pan character varying DEFAULT NULL::character varying, i_cvv character varying DEFAULT NULL::character varying, i_expiry_date character varying DEFAULT NULL::character varying, i_card_holder character varying DEFAULT NULL::character varying, i_info character varying DEFAULT NULL::character varying, i_user character varying DEFAULT NULL::character varying, i_token character varying DEFAULT NULL::character varying, i_params character varying DEFAULT NULL::character varying, i_oson_card_id integer DEFAULT NULL::integer, i_payment_id character varying DEFAULT NULL::character varying, i_capture_id character varying DEFAULT NULL::character varying, i_refund_id character varying DEFAULT NULL::character varying, i_country character varying DEFAULT NULL::character varying, i_bank character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_created_by         integer := 1;
    v_object_id constant integer := 5;
   v_state_id integer ;
  	v_pan varchar ;
	 v_cvv varchar ;
	v_expiry_date  varchar ;
	v_card_holder varchar ;
	v_info	varchar ;
	v_user varchar;
	v_token varchar ;
	v_params varchar ;	
	v_oson_card_id integer ;
v_payment_id varchar ;
	  v_capture_id varchar;
		 	 v_refund_id varchar;
		 	v_bank  varchar ;
		 	v_country  varchar ;
begin
	
    select  pan
                          , cvv
                          , expiry_date
                          ,card_holder
                          , info 
                          , "user" 
                          , "token"
                          ,params
                          ,oson_card_id
                          ,country
                          , bank
    into
        v_pan
                          , v_cvv
                          , v_expiry_date
                          ,v_card_holder 
                          , v_info 
                          , v_user
                          , v_token 
                          ,v_params
                          ,v_oson_card_id
                          ,v_payment_id
							,v_capture_id
							,v_refund_id
							,v_country
							,v_bank
    from ib_cards 
    where id = i_id;
    if not found then
        v_err_text := 'takaya card id ne nayden ';
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
    end if;
    if i_pan is null then
        i_pan := v_pan;
    end if;
   if i_bank is null then
        i_bank := v_bank;
    end if;
   
    if i_user is null then
        i_user := v_user;
    end if;
    
    if i_payment_id is null then
        i_payment_id := v_payment_id;
    end if;
    if i_country is null then
        i_country := v_country;
    end if;
    if i_capture_id is null then
        i_capture_id := v_capture_id;
    end if;
    if i_refund_id is null then
        i_refund_id := v_refund_id;
    end if;
   
    if i_oson_card_id is null then
        i_oson_card_id := v_oson_card_id;
    end if;
   
    if i_token is null then
    
        i_token := v_token;
    end if;
   
    if i_params is null then
        i_params := v_params;
    end if;
      if i_info is null then
        i_info := v_info;
    end if;
     if i_cvv is null then
        i_cvv := v_cvv;
    end if;
    if i_expiry_date is null then
        i_expiry_date := v_expiry_date;
    end if;
    if i_card_holder is null then
        i_card_holder := v_card_holder;
    end if;
    
    update ib_cards 
    set pan         = i_pan,
        cvv = i_cvv,
        expiry_date        = i_expiry_date,
        card_holder   = i_card_holder ,
        info =  i_info,
        "user"= i_user,
        "token" = i_token ,
        params= i_params,
        oson_card_id= i_oson_card_id,
       payment_id =  i_payment_id,
      capture_id =  i_capture_id,
      refund_id = i_refund_id,
      country=  i_country , 
      bank =  i_bank
    where id = i_id;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', v_object_id, v_err_text ||' edit_cards ', 'ERROR');
        return false;
END;
$$;

alter function edit_card(integer, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, integer, varchar, varchar, varchar, varchar, varchar) owner to interhub_user;

