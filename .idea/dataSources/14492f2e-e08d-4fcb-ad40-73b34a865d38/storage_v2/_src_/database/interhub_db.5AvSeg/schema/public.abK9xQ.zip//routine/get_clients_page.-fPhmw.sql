create function get_clients_page(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_id integer DEFAULT NULL::integer, i_client_name character varying DEFAULT NULL::character varying, i_client_type character varying DEFAULT NULL::character varying, i_client_inn character varying DEFAULT NULL::character varying, i_phone_number character varying DEFAULT NULL::character varying, i_address character varying DEFAULT NULL::character varying, i_condition character varying DEFAULT NULL::character varying, i_is_juridical_wallet character varying DEFAULT NULL::character varying, i_ordered_by character varying DEFAULT NULL::character varying, i_is_desc character varying DEFAULT NULL::character varying)
    returns TABLE(id integer, client_name character varying, client_type character varying, client_inn character varying, phone_number character varying, address character varying, condition character varying, client_wallet_type integer, created_date timestamp without time zone, modified_date timestamp without time zone, info character varying, count integer)
    language plpgsql
as
$$
DECLARE
    v_reference_id integer;
    v_err_text     varchar;
    v_condition    varchar = '';
   v_clients_count	integer;
BEGIN
	if i_ordered_by is   null then
       i_ordered_by := '1';
    end if;
      if i_is_desc  ='Y' then
       i_ordered_by := i_ordered_by || ' desc ';
    end if;
    if i_id is not null then
        v_condition := v_condition || ' and t.id  =' || i_id;
    end if;
    if i_client_type is not null then
        v_condition := v_condition || ' and t.client_type =''' || i_client_type || '''';
    end if;
    if i_client_inn is not null then
        v_condition := v_condition || ' and t.client_inn =''' || i_client_inn || '''';
    end if;
    if i_phone_number is not null then
        v_condition := v_condition || ' and  t.phone_number =''' || i_phone_number || '''';
    end if;
    if i_client_name is not null then
        v_condition := v_condition || 'and lower(t.client_name ) like ''%' || lower(i_client_name) || '%' || '''';
    end if; 
     
    if i_address is not null then
        v_condition := v_condition || 'and lower(t.address ) like ''%' || lower(i_address) || '%' || '''';
    end if;
   
    if i_condition is not null then
        v_condition := v_condition || ' and  t.conidition =''' || i_condition || '''';
    end if; 
   
  
   if i_is_juridical_wallet   is null then 
     EXECUTE 'select  count(*)  from ib_clients t where 1=1 ' || v_condition into v_clients_count;
    RETURN QUERY
        execute 'SELECT t.id    
				,t.client_name 		
				,t.client_type   		
				,t.client_inn     		
				,t.phone_number   	
				,t.address 			
				,t.condition			
				, t.client_wallet_type,t.created_date,t.modified_date,  t.info,
					'||v_clients_count ||' as count
				 FROM ib_clients t  WHERE  1= 1 ' || v_condition||
                         ' order by '||i_ordered_by||'  limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;
     elsif  i_is_juridical_wallet ='Y' then 
       EXECUTE 'select  count(*)  FROM ib_clients t , ib_wallets s   WHERE   s.client_id =  t.id  and t.client_type != ''P''  ' || v_condition into v_clients_count;
    RETURN QUERY
        execute 'SELECT  t.id    
				,t.client_name 		
				,t.client_type   		
				,t.client_inn     		
				,t.phone_number   	
				,t.address 			
				,t.condition			
				,t.client_wallet_type,t.created_date,t.modified_date,info,
					'||v_clients_count ||' as count FROM ib_clients t , ib_wallets s   WHERE   s.client_id =  t.id  and t.client_type != ''P''  ' || v_condition||
                         ' order by  '||i_ordered_by||'   limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count; 
     end if;
       
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '',5, v_err_text, 'ERROR');
END ;
$$;

alter function get_clients_page(integer, integer, integer, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar) owner to interhub_user;

