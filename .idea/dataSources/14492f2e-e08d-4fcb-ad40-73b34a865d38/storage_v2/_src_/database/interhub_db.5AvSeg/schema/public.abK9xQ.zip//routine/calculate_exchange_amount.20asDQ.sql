create function calculate_exchange_amount(i_amount numeric, i_from_currency_id integer, i_to_currency_id integer) returns numeric
    language plpgsql
as
$$
declare
	v_amount numeric;

begin
select
 t.amount* i_amount  
 into
	v_amount
from
	ib_S_currency_exchanges t
where
	t.from_Currency_id = i_from_currency_id
	and t.to_currency_id = i_to_currency_id
limit 1;

return v_amount ;

end;

$$;

alter function calculate_exchange_amount(numeric, integer, integer) owner to interhub_user;

