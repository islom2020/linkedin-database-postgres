create function exchange_currency(i_from_currency_id integer, i_to_currency_id integer, i_amount numeric, i_transact_id bigint, i_is_wallet character varying DEFAULT NULL::character varying) returns numeric
    language plpgsql
as
$$
DECLARE
 v_object_id integer := 6;
v_amount numeric;
v_source_client_id integer;
v_destination_client_id integer;
v_payment_type varchar;
v_res boolean;
v_dr_client_acc ib_client_accounts%rowtype;
v_transact ib_transacts%rowtype;
   v_wallet_transact ib_wallet_transacts%rowtype;
begin
		select r.amount_in_currency into v_amount from ib_transacts r where r.id = i_transact_id;
	if not found then 
		raise ' transact  is not found ';
	end if;
	/*select trunc(t.amount* i_amount ,2)into v_amount  from
				ib_S_currency_exchanges t where t.from_Currency_id = i_from_currency_id 
  					and t.to_currency_id = i_to_currency_id limit 1;*/
  ---------1- valyutaga pulni haydash				
  				select t.* into v_dr_client_acc  from ib_client_accounts  t 
  					where t.client_type_id  = 0
  					and t.account_type_id  = 6
  					and t.currency_id  = i_from_currency_id
  					and condition ='A'    ;  
  				if not found then 
  					perform  log_action_atx(i_transact_id || '', v_object_id, sqlerrm || ' can not find account  exchange_currency ', 				'ERROR');
  					return -1;
  				end if;
		v_dr_client_acc.balance :=  v_dr_client_acc.balance + i_amount;
  		select add_client_deposit(v_dr_client_acc.id, v_dr_client_acc.balance, 0, i_amount, i_transact_id)
	    into v_res;
	    if v_res = false then
	        return -1;
	    end if;
		
  	update ib_client_accounts
    set balance = v_dr_client_acc.balance
    where id = v_dr_client_acc.id;
   if v_amount =0  or v_amount is null then 
   		raise ' exchange amount cant be null or 0 ';
   end if;
   --------- 2- valyutniy exchangerdan pulni haydash
	   select t.* into v_dr_client_acc  from ib_client_accounts  t 
	  					where t.client_type_id  = 0
	  					and t.account_type_id  = 6
	  					and t.currency_id  = i_to_currency_id
	  					and condition ='A'   ;
	  				if not found then 
	  					perform  log_action_atx(i_transact_id || '', v_object_id, sqlerrm || ' exchange_currency ', 'ERROR');
	  					return -1;
	  				end if;
		v_dr_client_acc.balance :=  v_dr_client_acc.balance -  v_amount;
  		select add_client_deposit(v_dr_client_acc.id, v_dr_client_acc.balance, v_amount,0  , i_transact_id)
  		  into v_res;
	    if v_res = false then
	        raise;
	    end if;
	   
	   update ib_client_accounts
    set balance = v_dr_client_acc.balance
    where id = 	v_dr_client_acc.id; 
   --------  add excghange_transsacts  
   if i_is_wallet is null then  ---  wallet bulmasa  
		select t.* into v_transact from ib_transacts t where t.id = i_transact_id;
	select a.client_id into  v_source_client_id from 
			ib_agents a
		where a.id = v_transact.agent_id;
	select g.client_id into  v_destination_client_id from  
			ib_gateway_merchants  a , ib_gateways g  
		where  g.id  = a.gateway_id 
		and a.id = v_transact.gateway_merchant_id;
	v_payment_type := 'P';
	
	else ----- -wallet tranzaksiyalari bulsa  
		select c.* into v_wallet_transact  from ib_wallet_transacts c where c.id  = i_transact_id  ;
			if not found then 
			perform  log_action_atx(i_transact_id || '', v_object_id, sqlerrm || 
			' can not find transact  wallet_transact exchange_currency ', 				'ERROR');
  					return -1;
  			 end if;
  			----- walletning qaysi tipligiga qarab source va destinationni olish 
  			if v_wallet_transact.payment_type = 1 then  					----  agent wallet to wallet 
  			 v_source_client_id :=  v_wallet_transact.source :: integer; 
		        select t.client_id into v_destination_client_id from ib_wallets t
		       				where t.phone_number = v_wallet_transact.destination;
  			elsif v_wallet_transact.payment_type =2 then  									 ---- wallet to   agent  
  				 select t.client_id into v_source_client_id from ib_wallets t
  					where t.phone_number = v_wallet_transact.source;
        		   v_destination_client_id :=  v_wallet_transact.destination::integer;
        
  			else 																	----  wallet to wallet 
  			 	  select t.client_id into v_source_client_id from ib_wallets t 
  			 	 			where t.phone_number = v_wallet_transact.source;
      			  select t.client_id into v_destination_client_id from ib_wallets t 
      			 			where t.phone_number = v_wallet_transact.destination;

  			end if;
  			v_payment_type = 'W';
	end if;
			insert
			into
			 ib_exchange_transacts (
			 from_currency_id,
			to_currency_id,
			transact_id,
			source_client_id,
			destination_client_id,
			from_amount,
			to_amount,
			payment_type,
			created_date,
			state_id)
		values(i_from_currency_id,
		i_to_currency_id,
		i_transact_id,
		v_source_client_id,
		v_destination_client_id,
		i_amount,
		v_amount,
		v_payment_type,
		now(),
		2);
	  
		return v_amount ;
exception  when others then
        perform log_action_atx(i_transact_id || '', v_object_id, sqlerrm || ' exchange_currency', 'ERROR');
        return -1;
END;
$$;

alter function exchange_currency(integer, integer, numeric, bigint, varchar) owner to interhub_user;

