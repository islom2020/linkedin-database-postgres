create function get_agents_page(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_id integer DEFAULT NULL::integer, i_token character varying DEFAULT NULL::character varying, i_name character varying DEFAULT NULL::character varying, i_ordered_by character varying DEFAULT NULL::character varying, i_is_desc character varying DEFAULT NULL::character varying)
    returns TABLE(id integer, name character varying, payment_type integer, token character varying, commission bigint, currency_id integer, client_id integer, count integer)
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
    v_condition varchar := '';
   v_agent_count integer;
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
   	if i_ordered_by is   null then
       i_ordered_by := '1';
    end if;
      if i_is_desc  ='Y' then
       i_ordered_by := i_ordered_by || ' desc ';
    end if;
    if i_name is not null then
        v_condition := v_condition || 'and lower(t.name) like ''%' || lower(i_name) || '%' || '''';
    end if;
    if i_token is not null then
        v_condition := v_condition || ' and  t.token = ''' || i_token || '''';
    end if;
       EXECUTE 'select  count(*)  from ib_agents t where 1=1 ' || v_condition into v_agent_count;

    RETURN QUERY
        execute 'SELECT  id ,
      name  ,
      payment_type   ,
      token  ,
      commission ,
      currency_id ,
      client_id  ,'|| 
      v_agent_count || ' as count   FROM ib_agents t  WHERE  1= 1 ' || v_condition||  
                         ' order by '||i_ordered_by||'  limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;
    IF NOT FOUND THEN
        perform log_action_atx(v_condition, 2, 'Агент Данный не найден : ' || v_condition, 'ERROR');
    END IF;
END;
$$;

alter function get_agents_page(integer, integer, integer, varchar, varchar, varchar, varchar) owner to interhub_user;

