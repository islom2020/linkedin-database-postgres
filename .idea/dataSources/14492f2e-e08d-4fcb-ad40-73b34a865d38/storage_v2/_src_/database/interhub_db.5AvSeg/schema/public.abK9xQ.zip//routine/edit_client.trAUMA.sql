create function edit_client(i_id integer, i_client_name character varying DEFAULT NULL::character varying, i_client_type character varying DEFAULT NULL::character varying, i_client_inn character varying DEFAULT NULL::character varying, i_phone_number character varying DEFAULT NULL::character varying, i_address character varying DEFAULT NULL::character varying, i_condition character varying DEFAULT NULL::character varying, i_client_wallet_type integer DEFAULT NULL::integer, i_info character varying DEFAULT NULL::character varying) returns integer
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_client_type        varchar;
    v_object_id constant integer := 2;
    v_phone_number       varchar;
    v_address            varchar ;
    v_name               varchar(300);
    v_client_wallet_type integer;
    v_client_inn         varchar;
    v_Condition          varchar;
   v_info				varchar ;
BEGIN
    select client_name, address, client_inn, condition, phone_number, client_type,client_wallet_type,info
    into
        v_name , v_address, v_client_inn , v_condition ,v_phone_number, v_client_type, v_client_wallet_type,v_info
    from ib_clients
    where id = i_id;
    if not found then
        v_err_text := 'takaya id ne nayden :: edit_client';
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
    end if;
    if i_client_name is null then
        i_client_name := v_name ;
    end if;
    if i_address is null then
        i_address := v_address;
    end if;
    if i_client_inn is null then
        i_client_inn := v_client_inn;
    end if;
    if i_condition is null then
        i_condition := v_condition;
    end if;
   if i_info is null then
        i_info := v_info;
    end if;
    if i_client_wallet_type is null then
        i_client_wallet_type :=v_client_wallet_type;
    end if;
    if i_phone_number is null then
        i_phone_number := v_phone_number;
    end if;
    update ib_clients
    set client_name  = i_client_name,
        client_inn= i_client_inn,
        address      = i_address,
        condition= i_condition,
        client_type  = i_client_type,
        phone_number = i_phone_number,
        client_wallet_type = i_client_wallet_type,
        modified_date  =  now(),
        info =  i_info
    where id = i_id;
    return 1;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', v_object_id, v_err_text || ' edit_client ', 'ERROR');
        return -1;
END;
$$;

alter function edit_client(integer, varchar, varchar, varchar, varchar, varchar, varchar, integer, varchar) owner to interhub_user;

