create function add_gateway(i_name character varying, i_login character varying, i_password character varying, i_currency_id integer, i_state_id integer, i_pay_url character varying, i_small_logo character varying, i_amount_unit bigint, i_ip_address character varying, i_check_url character varying, i_client_id integer DEFAULT NULL::integer, i_check_status_url character varying DEFAULT ''::character varying, i_request_token character varying DEFAULT NULL::character varying, i_has_billing integer DEFAULT NULL::integer) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_date               date    := now();
    v_id_max             integer;
    v_object_id constant integer := 3;
    v_id                 integer;
      v_count	integer := 0 ;

    v_client_id          integer;
BEGIN
    if i_Client_id is null then 
		select add_client(i_client_name => i_name, i_client_type => 'J') into i_client_id;
	else 
		select count(*) into v_count from ib_clients t where t.id   = i_client_id and client_type  = 'J';
		if 	v_count =0 then 
			raise 'can not find client';	
		end if;
	end if ;
    INSERT INTO public.ib_gateways ( name
                                   , login
                                   , password
                                   , currency_id
                                   , state_id
                                   , pay_url
                                   , small_logo
                                   , amount_unit
                                   , ip_address
                                   , check_url, client_id
                                   ,check_status_url
                                   , request_token
                                   ,has_billing)
    VALUES (i_name,
            i_login,
            i_password,
            i_currency_id,
            i_state_id,
            i_pay_url,
            i_small_logo,
            i_amount_unit,
            i_ip_address,
            i_check_url,
            i_client_id,
            i_check_status_url,
            i_request_token,
            i_has_billing)
    returning id into v_id;
  perform add_client_account_mode(i_client_id=> i_client_id,i_currency_id=> i_currency_id, i_client_type_id=>v_object_id,  i_account_type_id =>v_object_id ,i_jur_id=>v_id );
    return true;
exception
    when others THEN
        select max(id) into v_id_max from ib_gateways;
        perform log_action_atx(v_id_max || '', v_object_id, sqlerrm || 'add_gateway', 'ERROR');
        return false;
END;
$$;

alter function add_gateway(varchar, varchar, varchar, integer, integer, varchar, varchar, bigint, varchar, varchar, integer, varchar, varchar, integer) owner to interhub_user;

