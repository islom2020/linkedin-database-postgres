create function add_session(i_session_id character varying, i_user_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_created_by         integer := 1;
    v_date               date    := now()::date;
    v_object_id constant integer := 2;
    v_id integer;
    v_res_funct  boolean;
BEGIN
    insert into ib_sessions ( session_id
                          , user_id
                          ,  created_date)
    values (i_session_id, i_user_id,now() );

    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_session_id, v_object_id, v_err_text|| 'add_session', 'ERROR');
        return false;
END;
$$;

alter function add_session(varchar, integer) owner to interhub_user;

