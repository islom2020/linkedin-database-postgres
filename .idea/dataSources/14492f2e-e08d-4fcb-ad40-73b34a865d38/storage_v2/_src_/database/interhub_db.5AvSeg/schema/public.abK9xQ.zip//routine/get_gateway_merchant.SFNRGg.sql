create function get_gateway_merchant(i_id integer DEFAULT NULL::integer, i_gateway_id integer DEFAULT NULL::integer, i_category_id integer DEFAULT NULL::integer, i_can_check_request integer DEFAULT NULL::integer, i_state_id integer DEFAULT NULL::integer, i_merchant_id integer DEFAULT NULL::integer, i_gateway_merchant_code character varying DEFAULT NULL::character varying, i_can_pay_request integer DEFAULT NULL::integer, i_gateway_merchant_id integer DEFAULT NULL::integer) returns SETOF ib_gateway_merchants
    language plpgsql
as
$$
DECLARE
    v_object_id integer := 3;
    v_condition varchar := '';
    rec         RECORD;
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_category_id is not null then
        v_condition := v_condition || ' and t.category_id = ' || i_category_id;
    end if;
    if i_gateway_id is not null then
        v_condition := v_condition || ' and t.gateway_id = ' || i_gateway_id;
    end if;
    
    if i_gateway_merchant_id is not null then
        v_condition := v_condition || ' and t.gateway_merchant_id = ' || i_gateway_merchant_id;
    end if;
    if i_merchant_id is not null then
        v_condition := v_condition || ' and t.merchant_id = ' || i_merchant_id;
    end if;
    if i_Can_check_request is not null then
        v_condition := v_condition || ' and t.Can_check_request = ' || i_Can_check_request;
    end if;
      if i_gateway_merchant_code is not null then
        v_condition := v_condition || ' and t.gateway_merchant_code = ''' || i_gateway_merchant_code ||'''';
    end if;
    if i_state_id is not null then
        v_condition := v_condition || ' and t.state_id  = ' || i_state_id ;
    end if; 
    if i_can_pay_request is not null then
        v_condition := v_condition || ' and t.can_pay_request  = ' || i_can_pay_request ;
    end if; 
   
    return query execute 'SELECT
             t.*
        from public.ib_gateway_merchants t where 1=1   ' || v_condition;
exception
    when others then
        if i_id is not null then
            perform log_action_atx(i_id || '', v_object_id, 'Данный не нфйден ид :' || i_id, 'ERROR');
        else
            perform log_action_atx('gateway_merchant', v_object_id, 'Данный не нфйден ид :' || i_id, 'ERROR');
        end if;
END;
$$;

alter function get_gateway_merchant(integer, integer, integer, integer, integer, integer, varchar, integer, integer) owner to interhub_user;

