create function cut_emission_deposit(i_client_id integer, i_deposit bigint, i_currency_id integer, i_client_type_id integer, i_dr_amount bigint, i_cr_amount bigint, i_group_id bigint) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_object_id constant integer := 4;
    v_curr_code          varchar;
    v_cr_acc_code        varchar;
    v_date               date    := now();
    v_dr_acc_code        varchar;
BEGIN
    i_currency_id :=860;
    begin
        select currency_code
        into v_curr_code
        from ib_currencies
        where id = i_currency_id;
    exception
        when others then
            return false;
    end;

    v_cr_acc_code := '8888888' || v_curr_code;
    v_dr_acc_code := '7777777' || v_curr_code;

    insert into ib_client_deposit
    ( client_id
    , deposit
    , dr_acc_code
    , cr_acc_code
    , cr_amount
    , dr_amount
    , client_type_id
    , oper_date
    , currency_id,
      group_id)
    values (i_client_id,
            i_deposit,
            v_dr_acc_code,
            v_cr_acc_code,
            i_cr_amount,
            i_dr_amount
               , i_client_type_id,
            v_date,
            i_currency_id,
            i_group_id);
    return true;
exception
    when others THEN
        perform log_action_atx(i_client_id || '', v_object_id, sqlerrm || ' cut_emission_deposit', 'ERROR');
        return false;
END;
$$;

alter function cut_emission_deposit(integer, bigint, integer, integer, bigint, bigint, bigint) owner to interhub_user;

