create function send_to_wallet(i_source_jur_id integer, i_destination character varying, i_destination_currency_id integer, i_commission_amount numeric, i_transact_amount numeric, i_owner_jur_id integer, i_agent_transaction_id character varying DEFAULT NULL::character varying, i_info character varying DEFAULT NULL::character varying, i_params character varying DEFAULT NULL::character varying) returns bigint
    language plpgsql
as
$$
DECLARE
    v_currency_price             numeric ;
    v_source					varchar;
    v_destination      		varchar;
    v_source_client_type_id      integer;
    v_destination_client_type_id integer;
    v_date                       date    := now();
    v_id_max                     bigint  := -1;
    v_object_id constant         integer := 7;
    v_commission                 integer;
    v_res                        integer;
    v_state_id                   integer :=2;
    v_source_currency_id			integer;
    v_err_text 	varchar :='';
	   	v_source_amount				numeric;
  v_result	boolean;
   v_destination_amount 		numeric;
BEGIN

    begin
        select t.price
        into v_currency_price
        from ib_currencies t
        where t.id = i_destination_currency_id;
    exception
        when others then
            perform log_action_atx(i_destination_currency_id || '', v_object_id, 'can not find commission  ' || sqlerrm, 'ERROR');
            return -1;
    end;

    select generate_id_transact(1) into v_id_max;
    v_id_max := '2' || v_id_max;
   
   	select * from check_limit_wallet_destination(i_destination,  i_transact_amount ) into  v_result ;
	if v_result = false then 
			v_err_text:= ' limit problem ';
				v_state_id := 7;
--			raise ' limit problem ';
		end if;
    if i_transact_amount <= 0  then  
    	return -3;
    end if;
    
     select t.client_account,  t.currency_id into v_source, v_source_currency_id  
     				from ib_Client_accounts t ,  ib_jur_wallet_childs c where
     	  c.account_id  = t.id and t.account_type_id  = 8  and c.id  = i_source_jur_id
     	and c."type"  = 'A';
       	if not found then
       	v_err_text:= '  agent id not found ';
       	v_state_id := 7;	
--            return -1;
        end if;		
       
        select a.client_account  into  v_destination   
       				from ib_wallets t,  ib_client_accounts  a where t.phone_number = i_destination and a.client_id  = t.client_id 
       				and t.currency_id  = i_destination_currency_id and a.currency_id  =  t.currency_id   and a.account_type_id  = 5;
		if not found then
			v_err_text:= ' destination account not found ';
			v_state_id := 7;
--            return -1;
        end if;
        
       /*
       select t.value into v_commission from ib_settings t where t."key"  = 'commission_wallet';

      	      	if v_commission >  0  then
      	 	 i_commission_amount := i_transact_amount * ( v_commission  ) / 100;
  	    else 
    	 	i_commission_amount := 0;
 	   end if;*/
       
			v_destination_amount :=  (i_transact_amount -i_commission_amount );
--    LOCK TABLE ib_wallet_transacts IN ACCESS EXCLUSIVE MODE;
    INSERT INTO ib_wallet_transacts ( id
                                    , source
                                    , destination
                                    , payment_type
                                    , currency_id
                                    , commission_amount
                                    , state_id
                                    , transact_amount
                                    , created_date
                                    ,  owner_jur_id 
                                     ,modified_date 
                                     ,destination_amount
                                     ,destination_currency_id
                                     ,agent_transaction_id
                                      , info 
                                      ,params)
    VALUES ( v_id_max
           , i_source_jur_id :: varchar
           , i_destination
           , 1
           , v_source_currency_id
           , i_commission_amount
           , v_state_id 
           , i_transact_amount
           , now()
           , i_owner_jur_id
           , now()
           , v_destination_amount
           , i_destination_currency_id
          ,i_agent_transaction_id
 		 , i_info  
  	       	, i_params);

if  v_err_text =  '' and v_state_id  = 2 then 
	    select take_deposit_from_account(i_from_Client_account => v_source,
							i_transact_amount  => i_transact_amount, 
	                        i_group_id => v_id_max)
	    into v_res;
	    if v_res = -1 then
	    	v_err_text:= ' agent depositdan olishda muammo ';
	    	v_state_id := 7;
--	        raise  'cannot take_deposit deposit';
	    end if;
	     
	 if v_err_text ='' and v_state_id  = 2 then 
		    select return_deposit_client_account(i_to_client_account  => v_destination,
		                          i_transact_amount  => i_transact_amount,
		                          i_currency_id => i_destination_currency_id,
		                          i_group_id => v_id_max,
		                          i_from_currency_id =>  v_source_currency_id,
		                          i_commission_amount => i_commission_amount,
		                          i_is_wallet=> 'Y')
		  	  into v_res;
		
			  v_state_id :=6;
			    if v_res = -1 then
			    	v_err_text:= ' client walleti depositida  tashashda muammo ';
			    	v_state_id := 4;
			    end if;
 	 end if;
  
 end if;
	   if v_err_text  =  ''  then 
		v_err_text := null;
	end if;

    update ib_wallet_transacts t set state_id = v_state_id , info  = v_err_text where   t.id = v_id_max;
   if v_state_id  =  6 then 
   		return v_id_max;
 	end if;
 return -1;
exception
    when others THEN
        perform log_action_atx(v_id_max || '', v_object_id, sqlerrm || 'send_to_wallet_transacts', 'ERROR');
        return -1;
END;
$$;

alter function send_to_wallet(integer, varchar, integer, numeric, numeric, integer, varchar, varchar, varchar) owner to interhub_user;

