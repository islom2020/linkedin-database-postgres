create function get_transact_info(i_transact_id bigint) returns SETOF ib_transacts_info
    language plpgsql
as
$$
DECLARE
    v_user   integer := 2;
    v_ref_id integer;
begin
		return query select * from ib_transacts_info t where t.transact_id =  i_transact_id ;	
	END;
$$;

alter function get_transact_info(bigint) owner to interhub_user;

