create function add_client_account_mode(i_client_id integer, i_currency_id integer, i_client_type_id integer, i_account_type_id integer, i_is_overdraft character varying DEFAULT 'N'::character varying, i_overdraft_amount bigint DEFAULT 0, i_jur_id integer DEFAULT NULL::integer) returns integer
    language plpgsql
as
$$
DECLARE
    v_reference_id   integer;
    v_err_text       varchar;
    v_client_account varchar;
    v_id             integer;
    v_client_id      varchar;
    v_prefix         varchar;
    v_ord            varchar;
    v_count          integer;
BEGIN
    select t.code into v_prefix from ib_s_client_account_types t where type_id = i_account_type_id;
    select generate_id_client_for_account(abs(i_client_id)) into v_client_id;
    select count(*)
    into v_count
    from ib_client_accounts
    where currency_id = i_currency_id
      and account_type_id = i_account_type_id
      and client_type_id = i_client_type_id
      and client_id = i_client_id;
    select generate_ord_for_account(v_count) into v_ord;

    v_client_account := v_prefix || abs(i_client_type_id) || i_currency_id || v_client_id  || v_ord;

    insert into ib_client_accounts ( client_id,
                                     client_type_id,
                                     balance
                                   , client_account
                                   , currency_id
                                   , created_date
                                   , modified_by
                                   , modified_on
                                   , condition 
                                     ,account_type_id
                                     ,juridical_id)
    values (i_client_id,
            i_client_type_id,
            0,
            v_client_account,
            i_currency_id,
            now(),
            -1,
            now(),
            'A', 
            i_account_type_id,
            i_jur_id) 
             
    returning id into v_id;
	if i_account_type_id  = 4 then 
		update ib_client_accounts  set is_overdraft  = 'Y'  ,  overdraft_amount = i_overdraft_amount  
			where client_id = i_client_id  and client_type_id  = i_client_type_id and account_type_id  = i_client_type_id;  
	end if;
--    perform add_client_deposit(v_id, 0, 0, 0, -1);
    return v_id;
exception
    when others THEN
        v_err_text := sqlerrm;
        select max(id) into v_reference_id from ib_client_accounts;
        perform log_action_atx(v_reference_id + 1 || '', 2, v_err_text || ' add_client_account ', 'ERROR');
        return -1;
END ;
$$;

alter function add_client_account_mode(integer, integer, integer, integer, varchar, bigint, integer) owner to interhub_user;

