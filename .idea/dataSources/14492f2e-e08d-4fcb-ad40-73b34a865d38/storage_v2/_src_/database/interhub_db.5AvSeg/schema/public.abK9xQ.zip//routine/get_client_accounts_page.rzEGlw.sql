create function get_client_accounts_page(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_id integer DEFAULT NULL::integer, i_client_id integer DEFAULT NULL::integer, i_client_type_id integer DEFAULT NULL::integer, i_client_account character varying DEFAULT NULL::character varying, i_is_last character varying DEFAULT NULL::character varying, i_is_commission character varying DEFAULT NULL::character varying, i_is_emission character varying DEFAULT NULL::character varying, i_currency_id integer DEFAULT NULL::integer, i_is_wallet_emission character varying DEFAULT NULL::character varying, i_is_worker character varying DEFAULT NULL::character varying, i_is_over_account character varying DEFAULT 'N'::character varying, i_account_type_id integer DEFAULT NULL::integer, i_ordered_by character varying DEFAULT NULL::character varying, i_is_desc character varying DEFAULT NULL::character varying)
    returns TABLE(id integer, client_id integer, client_type_id integer, balance numeric, client_account character varying, currency_id integer, created_date date, modified_by integer, modified_on timestamp without time zone, condition character varying, is_overdraft character varying, overdraft_amount numeric, account_type_id integer, juridical_id integer, count integer)
    language plpgsql
as
$$
DECLARE
    v_condition     varchar := '';
    v_currency_code varchar := '';
begin
	
 	if i_ordered_by is   null then
       i_ordered_by := '1';
    end if;
      if i_is_desc  ='Y' then
       i_ordered_by := i_ordered_by || ' desc ';
    end if;
    if i_client_id is not null then
        v_condition := v_condition || ' and t.client_id = ' || i_client_id;
    end if;
    if i_client_type_id is not null then
        v_condition := v_condition || ' and t.client_type_id  = ' || i_client_type_id;
    end if;
    if i_account_type_id is not null then
        v_condition := v_condition || ' and t.account_type_id  = ' || i_account_type_id;
    end if;
   
    if i_is_over_account  is not null  then 
		if  i_is_over_account  ='Y' then
        	v_condition := v_condition || ' and t.account_type_id  = ' || 4;
       	else 
       		v_condition := v_condition || ' and t.account_type_id  != ' || 4;
       	end if;
    end if;
   
   
    if i_currency_id is not null then
        v_condition := v_condition || ' and t.currency_id  = ' || i_currency_id;
    end if;
   
    if i_id is not null then
        v_condition := v_condition || ' and t.id  = ' || i_id;
    end if;
    if i_client_account is not null then
        v_condition := v_condition || ' and t.client_account  = ''' || i_client_account || '''';
    end if;

    if i_is_commission is not null then
        v_condition :=   ' and t.id  = -1' ;
    end if;
    if i_is_emission = 'Y' and i_is_wallet_emission is null        then
        v_condition := ' and t.client_account   like  ''' || '7777777%' || '''';
	elsif i_is_emission = 'Y' and i_is_wallet_emission ='Y' and i_is_worker is null then 
		v_condition := ' and t.client_account   like  ''' || '55555%' || '''';
    elsif i_is_emission = 'Y' and i_is_wallet_emission ='Y' and i_is_worker ='Y' then 
		v_condition := ' and t.client_account   like  ''' || '666666%' || '''';
	
    end if;
   
    return query execute ' SELECT  t.* , count(*) over() ::integer  from    ib_client_accounts t  where
                             1=1 ' || v_condition ||  
                         ' order by '||i_ordered_by||'  limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;
end;
$$;

alter function get_client_accounts_page(integer, integer, integer, integer, integer, varchar, varchar, varchar, varchar, integer, varchar, varchar, varchar, integer, varchar, varchar) owner to interhub_user;

