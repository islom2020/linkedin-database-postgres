create function drop_database() returns void
    language plpgsql
as
$$
DECLARE
    r      RECORD;
    v_text varchar;
BEGIN
    -- triggers

    -- extensions (see below), only if necessary
   /* FOR r IN (SELECT pns.*
              FROM pg_catalog.pg_tables  pns
              WHERE pns.tablename NOT like 'pg_%' and  pns.tableowner  ='interhub_user'
    )
        LOOP
            EXECUTE format('DROP table  %I.%I(%s);',
                           r.nspname, r.proname,
                           pg_get_function_identity_arguments(r.oid));
            EXECUTE 'alter SEQUENCE ' || r.sequencename || ' rename to ' || v_text;
        END LOOP;*/
    -- functions / procedures
    /* FOR r IN (SELECT pns.nspname, pp.proname, pp.oid
                FROM pg_proc pp, pg_namespace pns
                WHERE pns.oid=pp.pronamespace
                    AND pns.nspname NOT IN ('information_schema', 'pg_catalog', 'pg_toast')
                     and 
                    proname like 'db%'
            ) LOOP
            EXECUTE format('DROP FUNCTION %I.%I(%s);',
                    r.nspname, r.proname,
                    pg_get_function_identity_arguments(r.oid));
        END LOOP;*/
    -- nōn-default schemata we own; assume to be run by a not-superuser

    RAISE NOTICE 'Okk!';
END;
$$;

alter function drop_database() owner to interhub_user;

