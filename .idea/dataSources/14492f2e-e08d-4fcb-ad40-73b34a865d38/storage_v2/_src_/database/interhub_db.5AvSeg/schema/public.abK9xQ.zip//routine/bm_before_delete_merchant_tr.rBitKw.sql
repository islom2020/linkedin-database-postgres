create function bm_before_delete_merchant_tr() returns trigger
    language plpgsql
as
$$
DECLARE
    vDescription TEXT := '';
    vId          INT;
    vReturn      RECORD;

BEGIN
    vId := NEW.id;
    IF (TG_OP = 'INSERT') THEN
        vDescription := vDescription || 'added.Id: ' || vId;
        INSERT INTO bm_protocols (reference_id, object_id, error_backtrace,
                                  created_date, created_by, code)
        values (old.id, 3, vDescription, now(), 2, 'INSERT');
        vReturn := new;
    ELSIF (TG_OP = 'DELETE') THEN
        vDescription := vDescription || 'added.Id: ' || vId;
        INSERT INTO bm_protocols (reference_id, object_id, error_backtrace,
                                  created_date, created_by, code)
        values (old.id, 3, vDescription, now(), 2, 'DELETE');
        raise exception 'you can not delete from this table ';
        vReturn := old;
    END IF;
    return vReturn;
END;
$$;

alter function bm_before_delete_merchant_tr() owner to interhub_user;

