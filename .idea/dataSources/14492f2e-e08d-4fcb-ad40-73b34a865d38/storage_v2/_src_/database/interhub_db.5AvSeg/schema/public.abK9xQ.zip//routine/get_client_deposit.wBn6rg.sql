create function get_client_deposit(i_account_id integer) returns SETOF ib_client_deposit
    language plpgsql
as
$$
DECLARE
    v_condition     varchar := '';
    v_currency_code varchar := '';
BEGIN
    return query SELECT t.* from ib_client_deposit t where account_id = i_account_id;
end;
$$;

alter function get_client_deposit(integer) owner to interhub_user;

