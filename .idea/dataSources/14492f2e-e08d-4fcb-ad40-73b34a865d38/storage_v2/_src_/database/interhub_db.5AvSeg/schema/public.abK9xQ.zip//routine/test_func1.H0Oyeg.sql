create function test_func1() returns boolean
    language plpgsql
as
$$
declare
v_id integer;
v_gateway_currency_id  integer;
    v_agents             ib_agents%rowtype;
  v_client_id  integer;
 v_res integer;
 v_agent_merchants ib_Agent_merchant%rowtype;
    v_var           varchar ;
    v_count         integer := 0 ;
    v_dep           bigint  := 0;
    v_currency_code varchar := '';
    r               record;
BEGIN
    for r in (select
				*
			from
				test_view_transacts)
        loop
                           
	          select c.client_id , t.currency_id into v_client_id, v_gateway_currency_id from ib_gateway_merchants t ,  ib_gateways c 
	       		where t.id = r.gateway_merchant_id and c.id = t.gateway_id;
	       	if not found then 
	       	raise 'something is err';
	       	end if;
	        begin
		         
		        select t.*
		        into v_agent_merchants
		        from ib_agent_merchant t
		        where agent_id = r.agent_id
		          and merchant_id = r.merchant_id;
		    exception
		        when others then
		            perform log_action_atx(r.id || '', 7, sqlerrm, 'ERROR');
		            return false;
		    end;
	       
	       	select t.* into v_agents from ib_agents t where id = r.agent_id;
	       	 if not found then 
	       		raise 'something is err111';
	       	end if;
	       
	       
           select take_deposit(i_client_id => v_agents.client_id,
                            i_dr_amount => r.transact_amount,
                            i_client_type_id => 2,
                            i_currency_id => v_agent_merchants.currency_id,
                            i_group_id => r.id) 
             into v_res;
	        if v_res = -1 then
	            return
	                false;
	        end if;   
	       
	        select return_deposit(i_client_id => v_client_id,
	                              i_cr_amount =>  r.transact_amount,
	                              i_client_type_id => 3,
	                              i_currency_id => v_gateway_currency_id,
	                              i_group_id => r.id,
	                               i_from_currency_id =>  v_agent_merchants.currency_id,
	                              i_commission_amount => r.commission_amount)    into v_res;
	        if v_res = -1 then
	            return
	                false;
	        end if;   
                           
                           
        end loop;
       return true;
exception
		        when others then
		            perform log_action_atx(r.id || '', 7, sqlerrm, 'ERROR');
		            return false;
end;

$$;

alter function test_func1() owner to interhub_user;

