create function get_agents(i_id integer DEFAULT NULL::integer, i_token character varying DEFAULT NULL::character varying, i_name character varying DEFAULT NULL::character varying, i_state_id integer DEFAULT NULL::integer, i_client_id integer DEFAULT NULL::integer) returns SETOF ib_agents
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
    v_condition varchar := '';
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_client_id is not null then
        v_condition := v_condition || ' and t.client_id = ' || i_client_id;
    end if;
    if i_name is not null then
        v_condition := v_condition || 'and lower(t.name) like ''%' || lower(i_name) || '%' || '''';
    end if;
    if i_token is not null then
        v_condition := v_condition || ' and  t.token = ''' || i_token || '''';
    end if;
    if i_state_id is not null then
        v_condition := v_condition || ' and  t.state_id = ''' || i_state_id || '''';
    end if;
    RETURN QUERY
        execute 'SELECT * FROM ib_agents t  WHERE  1= 1 ' || v_condition;
    IF NOT FOUND THEN
        perform log_action_atx(v_condition, 2, 'Агент Данный не найден : ' || v_condition, 'ERROR');
    END IF;
END;
$$;

alter function get_agents(integer, varchar, varchar, integer, integer) owner to interhub_user;

