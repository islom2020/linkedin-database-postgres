create function add_client_jur_info(i_juridical_name character varying, i_type_juridical character varying, i_country_id integer, i_city character varying, i_region character varying DEFAULT NULL::character varying, i_address character varying DEFAULT NULL::character varying, i_account_number character varying DEFAULT NULL::character varying, i_filial_code character varying DEFAULT NULL::character varying, i_phone_number character varying DEFAULT NULL::character varying, i_email_for_info character varying DEFAULT NULL::character varying, i_email_for_lead character varying DEFAULT NULL::character varying, i_email_for_doc character varying DEFAULT NULL::character varying, i_name_manager character varying DEFAULT NULL::character varying, i_birth_date character varying DEFAULT NULL::character varying, i_nationality character varying DEFAULT NULL::character varying, i_info_person character varying DEFAULT NULL::character varying, i_trade_mark character varying DEFAULT NULL::character varying, i_jur_inn character varying DEFAULT NULL::character varying, i_postal_code character varying DEFAULT NULL::character varying, i_oked character varying DEFAULT NULL::character varying, i_person_phone_number character varying DEFAULT NULL::character varying, i_created_by integer DEFAULT NULL::integer, i_tax_code character varying DEFAULT NULL::character varying, i_counter_agent_type integer DEFAULT NULL::integer, i_description character varying DEFAULT NULL::character varying, i_logo_url character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 2;
    v_client_id integer;
begin
		select add_client(i_client_name => i_juridical_name, i_client_type => 'J') into v_client_id;
	if i_type_juridical ='Y' then 
		i_type_juridical ='J';
	end if;
		if 	v_client_id is null  then 
			raise 'can not create client';	
		end if;
	insert into ib_client_jur_info (
client_id                              ,         
trade_mark                          ,         
juridical_name                     ,         
type_juridical                       ,         
jur_inn                                 ,         
postal_code                         ,         
oked                                   ,         
country_id                           ,         
city                                     ,         
region                                 ,         
address                               ,         
account_number                  ,         
filial_code                            ,         
phone_number                     ,         
email_for_info                      ,         
email_for_lead                     ,         
email_for_doc                      ,         
name_manager                    ,         
birth_date                            ,         
nationality                           ,         
info_person                         ,         
person_phone_number         ,         
created_by,                                   
tax_code,
counter_agent_type,
 description,
  logo_url
)values (
			v_client_id                              ,      
			i_trade_mark                          ,      
			i_juridical_name                     ,      
			i_type_juridical                       ,      
			i_jur_inn                                 ,      
			i_postal_code                         ,      
			i_oked                                   ,      
			i_country_id                           ,      
			i_city                                     ,      
			i_region                                 ,      
			i_address                               ,      
			i_account_number                  ,      
			i_filial_code                            ,      
			i_phone_number                     ,      
			i_email_for_info                      ,      
			i_email_for_lead                     ,      
			i_email_for_doc                      ,      
			i_name_manager                    ,      
			i_birth_date                            ,      
			i_nationality                           ,      
			i_info_person                         ,      
			i_person_phone_number         ,      
			i_created_by ,
			i_tax_code,
			i_counter_agent_type,
			i_description
			,i_logo_url
);
return true;
	exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_juridical_name , v_object_id, v_err_text || 'add_client_jur_info', 'ERROR');
        return false;
END;
$$;

alter function add_client_jur_info(varchar, varchar, integer, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, integer, varchar, integer, varchar, varchar) owner to interhub_user;

