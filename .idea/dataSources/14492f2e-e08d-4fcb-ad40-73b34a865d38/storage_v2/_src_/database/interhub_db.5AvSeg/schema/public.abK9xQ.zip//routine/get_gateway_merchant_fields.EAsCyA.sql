create function get_gateway_merchant_fields(i_id integer DEFAULT NULL::integer, i_code character varying DEFAULT NULL::character varying, i_gateway_merch_id integer DEFAULT NULL::integer, i_service_field_id integer DEFAULT NULL::integer, i_field_type character varying DEFAULT NULL::character varying, i_custom_type character varying DEFAULT NULL::character varying) returns SETOF ib_gateway_merchant_fields
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    rec         RECORD;
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
     if i_service_field_id is not null then
        v_condition := v_condition || ' and t.service_field_id = ' || i_service_field_id;
    end if;
      if i_custom_type is not null then
        v_condition := v_condition || ' and t.custom_type =  ''' || i_custom_type || '''';
    end if;
    if i_field_type  is not null then
        v_condition := v_condition || ' and  t.field_type = ''' || i_field_type || '''';
    end if;
     
       if i_gateway_merch_id is not null then
        v_condition := v_condition || ' and t.gateway_merch_id = ' || i_gateway_merch_id;
    end if;
    if i_code is not null then
        v_condition := v_condition || ' and  t.code = ' || i_code;
    end if; 
    return query execute 'select t.* 
                            FROM ib_gateway_merchant_fields t 
                        where   1=1 ' || v_condition;
END;
$$;

alter function get_gateway_merchant_fields(integer, varchar, integer, integer, varchar, varchar) owner to interhub_user;

