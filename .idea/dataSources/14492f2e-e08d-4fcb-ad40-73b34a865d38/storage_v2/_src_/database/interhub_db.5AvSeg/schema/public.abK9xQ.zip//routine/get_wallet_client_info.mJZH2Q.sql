create function get_wallet_client_info(i_id integer DEFAULT NULL::integer, i_first_name character varying DEFAULT NULL::character varying, i_surname character varying DEFAULT NULL::character varying, i_last_name character varying DEFAULT NULL::character varying, i_birth_date date DEFAULT NULL::date, i_doc_number character varying DEFAULT NULL::character varying, i_nationality character varying DEFAULT NULL::character varying, i_birth_address character varying DEFAULT NULL::character varying, i_mail_address character varying DEFAULT NULL::character varying, i_state_id integer DEFAULT NULL::integer, i_client_id integer DEFAULT NULL::integer, i_region_id integer DEFAULT NULL::integer, i_phone_number character varying DEFAULT NULL::character varying) returns SETOF ib_wallet_client_info
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 5;
     v_condition varchar := '';
    begin 
	    
	     if i_phone_number is not null then 
				 select r.client_id  into  i_client_id  from ib_wallets r 
						where r.phone_number =  i_phone_number ;	    
					if i_client_id is null then 
						i_client_id := -5;
					end if;
		    end if;
	     if i_state_id is not null then
       		 v_condition := v_condition || ' and t.state_id  = ' || i_state_id ;
   		 end if;
	     if i_id is not null then
       		 v_condition := v_condition || ' and t.id  = ' || i_id ;
   		 end if;
   		  if i_region_id is not null then
       		 v_condition := v_condition || ' and t.region_id  = ' || i_region_id ;
   		 end if;
   		  if i_doc_number is not null then
       		 v_condition := v_condition || ' and t.doc_number  = ''' || i_doc_number||'''' ;
   		 end if; 
   		if i_mail_address is not null then
       		 v_condition := v_condition || ' and t.mail_address  = ''' || i_mail_address||'''' ;
   		 end if;
	    if i_first_name is not null then
    		    v_condition := v_condition || ' and lower(t.first_name) like ''%' || lower(i_first_name) || '%' || '''';
  		  end if;
	     if i_surname is not null then
    	    v_condition := v_condition || ' and lower(t.surname) like ''%' || lower(i_surname) || '%' || '''';
   		 end if;
	     if i_last_name is not null then
    	    v_condition := v_condition || ' and lower(t.last_name) like ''%' || lower(i_last_name) || '%' || '''';
   		 end if;
	     if i_client_id is not null then
       		 v_condition := v_condition || ' and t.client_id  = ' || i_client_id ;
   		 end if;
   		return query execute ' SELECT  t.* FROM ib_wallet_client_info  t
      WHERE   1= 1 ' || v_condition;
  exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(v_condition, v_object_id, v_err_text || 'get_wallet_client_info', 'ERROR');
        
END;
$$;

alter function get_wallet_client_info(integer, varchar, varchar, varchar, date, varchar, varchar, varchar, varchar, integer, integer, integer, varchar) owner to interhub_user;

