create function add_agent(i_a integer, i_b integer) returns integer
    language plpgsql
as
$$
DECLARE
    v_c integer := 0;
begin
    v_c := i_a + i_b;
    return v_c;
END;
$$;

alter function add_agent(integer, integer) owner to postgres;

