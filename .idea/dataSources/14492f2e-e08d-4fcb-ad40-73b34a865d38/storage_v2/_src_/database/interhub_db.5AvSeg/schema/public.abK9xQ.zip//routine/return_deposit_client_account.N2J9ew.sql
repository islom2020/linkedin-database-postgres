create function return_deposit_client_account(i_to_client_account character varying, i_transact_amount numeric, i_currency_id integer, i_group_id bigint, i_from_currency_id integer, i_commission_amount numeric DEFAULT NULL::numeric, i_is_wallet character varying DEFAULT NULL::character varying) returns integer
    language plpgsql
as
$$
DECLARE
    v_count               integer := 0 ;
    v_object_id           integer := 4;
    v_dep                 bigint  := 0;
    v_amount_without_comm numeric  := 0;
    v_currency_code       varchar := '';
    v_client_account      ib_client_accounts%rowtype;
    v_res                 boolean;
BEGIN
    select currency_code
    into v_currency_code
    from ib_currencies
    where id = i_currency_id ;
    if i_commission_amount is not null then
        v_amount_without_comm := i_transact_amount - i_commission_amount;
    end if;

    select t.*
    into v_client_account
    from ib_client_accounts t
    where t.client_account  = i_to_client_account
      and t.condition = 'A' for update;
     if not found then 
     	return -1;
     end if;
     if i_currency_id  != i_from_currency_id then 
		select * from exchange_currency(i_from_currency_id=>i_from_currency_id,  
									i_to_currency_id =>i_currency_id,
						 			i_amount=>v_amount_without_comm,
						 			i_transact_id => i_group_id,
						 			i_is_wallet=> i_is_wallet
						 			) into v_amount_without_comm;
		 if v_amount_without_comm = -1 then 
				 perform log_action_atx(i_to_client_account || '', v_object_id,   'from exchanger account could bot give deposit return_deposit', 'ERROR');
		 	return -1;
		 end if;
	end if;				
    v_client_account.balance := v_client_account.balance + v_amount_without_comm;


    select add_client_deposit(v_client_account.id, v_client_account.balance, 0, v_amount_without_comm, i_group_id)
    into v_res;
    if v_res = false then
        raise;
    end if;

    update ib_client_accounts
    set balance = v_client_account.balance
    where  id  =v_client_account.id;
     
    if i_commission_amount > 0 and i_commission_amount is not null then
		    if i_is_wallet is null  then
		        select t.*
		        into v_client_account
		        from ib_client_accounts t
		        where t.client_id = -1
		        and t.currency_id  = i_from_currency_id
		          and t.client_type_id = -1
		          and t.condition = 'A';
		
		        v_client_account.balance := v_client_account.balance + i_commission_amount;
				 if not found then 
						raise 'commission account can not find ';
					end if;
		    elsif i_is_wallet = 'Y' then 
		
		        select t.*
		        into v_client_account
		        from ib_client_accounts t
		        where t.client_id = -2
		        and currency_id =  i_from_currency_id
		          and t.client_type_id = -1
		          and t.condition = 'A';
					if not found then 
						raise 'commission account can not find ';
					end if;
		        v_client_account.balance := v_client_account.balance + i_commission_amount;
		
		     end if;
		       select add_client_deposit(v_client_account.id, v_client_account.balance, 0, i_commission_amount, i_group_id,
				                                  i_is_commission => 'Y')
				        into v_res;
		        if v_res = false then
		           	raise;
		        end if;
        update ib_client_accounts
        	set balance = v_client_account.balance
        where id = v_client_account.id;
    end if;
    return 1;
exception
    when others then
        perform log_action_atx(i_to_client_account || '', v_object_id, sqlerrm || ' return_deposit_client_account', 'ERROR');
        return -1;
END;
$$;

alter function return_deposit_client_account(varchar, numeric, integer, bigint, integer, numeric, varchar) owner to interhub_user;

