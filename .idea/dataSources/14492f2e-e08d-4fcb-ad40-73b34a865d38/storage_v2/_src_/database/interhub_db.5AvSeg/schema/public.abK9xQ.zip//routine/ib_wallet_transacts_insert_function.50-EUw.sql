create function ib_wallet_transacts_insert_function() returns trigger
    language plpgsql
as
$$
DECLARE
    partition_date    TEXT;
    partition_name    TEXT;
    start_of_month    TEXT;
    end_of_next_month TEXT;
BEGIN
    partition_date := to_char(NEW.created_date, 'YYYY_MM');
    partition_name := 'ib_wallet_transacts_' || partition_date;
    start_of_month := to_char((NEW.created_date), 'YYYY-MM') || '-01';
    end_of_next_month := to_char((NEW.created_date + interval '1 month'), 'YYYY-MM') || '-01';
    IF NOT EXISTS
        (SELECT *
         FROM information_schema.tables
         WHERE table_name = partition_name)
    THEN

        RAISE NOTICE 'A partition has been created %', partition_name;
        EXECUTE format(
                E'CREATE TABLE %I (CHECK ( date_trunc(\'day\', created_date) >= ''%s'' AND date_trunc(\'day\', created_date) < ''%s'')) INHERITS (public.ib_wallet_transacts)',
                partition_name, start_of_month, end_of_next_month);
	         EXECUTE 'alter table ' || partition_name || ' add primary key   (id) '; 
             EXECUTE 'CREATE   INDEX '  || partition_name || '_source_dest_idx ON '  ||   partition_name || ' (source,  destination  )';

    END IF;
    EXECUTE format('INSERT INTO %I ( id,
		 source,
		destination,
		payment_type,
		currency_id,
		commission_amount,
		state_id,
		transact_amount,
		created_date,
		owner_jur_id,
		modified_date,
		destination_amount,
		destination_currency_id,
		agent_transaction_id,
info, params ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11, $12 ,$13,$14, $15, $16)', partition_name) using
        NEW.id
        , NEW.source
        , NEW.destination
        , NEW.payment_type
        , NEW.currency_id
        , NEW.commission_amount
        , NEW.state_id
        , NEW.transact_amount
        , NEW.created_date
        ,NEW.owner_jur_id
        ,new.modified_date
        ,new.destination_amount
        ,new.destination_currency_id
       ,new.agent_transaction_id
      ,new.info
     	, new.params;
    RETURN NULL;
END
$$;

alter function ib_wallet_transacts_insert_function() owner to interhub_user;

