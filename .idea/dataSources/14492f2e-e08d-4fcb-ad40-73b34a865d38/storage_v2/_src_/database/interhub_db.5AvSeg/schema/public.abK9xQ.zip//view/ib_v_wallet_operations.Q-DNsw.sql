create view ib_v_wallet_operations
            (group_id, debit_amount, source_currency_id, credit_amount, destination_currency_id, comission_amount,
             source_client_name, source_client_id, destination_client_name, destination_client_id, credit_account,
             debit_account, deposit_date, transact_type, count, total_amount)
as
SELECT a.id                 AS group_id,
       a.transact_amount    AS debit_amount,
       a.currency_id        AS source_currency_id,
       a.destination_amount AS credit_amount,
       a.destination_currency_id,
       a.commission_amount  AS comission_amount,
       CASE a.payment_type
           WHEN 1 THEN ((SELECT r.fullname
                         FROM ib_jur_wallet_childs j,
                              ib_wallets r
                         WHERE r.id = j.parent_wallet_id
                           AND j.id = a.source::integer))::text
           ELSE (SELECT ag.fullname::text AS fullname
                 FROM ib_wallets ag
                 WHERE ag.phone_number::text = a.source::text)
           END              AS source_client_name,
       CASE a.payment_type
           WHEN 1 THEN (SELECT r.client_id
                        FROM ib_jur_wallet_childs j,
                             ib_wallets r
                        WHERE r.id = j.parent_wallet_id
                          AND j.id = a.source::integer)
           ELSE (SELECT ag.client_id
                 FROM ib_wallets ag
                 WHERE ag.phone_number::text = a.source::text)
           END              AS source_client_id,
       CASE a.payment_type
           WHEN 2 THEN (SELECT w.fullname
                        FROM ib_jur_wallet_childs j,
                             ib_wallets w
                        WHERE j.parent_wallet_id = w.id
                          AND w.wallet_type = 2
                          AND j.id = a.destination::integer)
           ELSE (SELECT ag.fullname
                 FROM ib_wallets ag
                 WHERE ag.phone_number::text = a.destination::text)
           END              AS destination_client_name,
       CASE a.payment_type
           WHEN 2 THEN (SELECT w.client_id
                        FROM ib_jur_wallet_childs j,
                             ib_wallets w
                        WHERE j.parent_wallet_id = w.id
                          AND w.wallet_type = 2
                          AND j.id = a.destination::integer)
           ELSE (SELECT ag.client_id
                 FROM ib_wallets ag
                 WHERE ag.phone_number::text = a.destination::text)
           END              AS destination_client_id,
       CASE a.payment_type
           WHEN 1 THEN (SELECT e.client_account
                        FROM ib_client_accounts e,
                             ib_jur_wallet_childs j
                        WHERE j.account_id = e.id
                          AND j.id = a.source::integer)
           ELSE (SELECT c.client_account
                 FROM ib_wallets ag,
                      ib_client_accounts c
                 WHERE ag.client_id = c.client_id
                   AND c.client_type_id = 5
                   AND c.account_type_id = 5
                   AND ag.phone_number::text = a.source::text)
           END              AS credit_account,
       CASE a.payment_type
           WHEN 2 THEN (SELECT e.client_account
                        FROM ib_client_accounts e,
                             ib_jur_wallet_childs j
                        WHERE j.account_id = e.id
                          AND j.id = a.destination::integer)
           ELSE (SELECT c.client_account
                 FROM ib_wallets ag,
                      ib_client_accounts c
                 WHERE ag.client_id = c.client_id
                   AND c.client_type_id = 5
                   AND c.account_type_id = 5
                   AND ag.phone_number::text = a.destination::text)
           END              AS debit_account,
       a.created_date       AS deposit_date,
       'W'::text            AS transact_type,
       1                    AS count,
       1::numeric           AS total_amount
FROM ib_wallet_transacts a
WHERE a.state_id = 6;

alter table ib_v_wallet_operations
    owner to interhub_user;

