create function add_card(i_pan character varying, i_cvv character varying, i_expiry_date character varying, i_card_holder character varying, i_info character varying DEFAULT NULL::character varying, i_user character varying DEFAULT NULL::character varying, i_token character varying DEFAULT NULL::character varying, i_params character varying DEFAULT NULL::character varying, i_oson_card_id integer DEFAULT NULL::integer, i_country character varying DEFAULT NULL::character varying, i_bank character varying DEFAULT NULL::character varying) returns integer
    language plpgsql
as
$$
declare
    v_err_text           varchar;
    v_object_id constant integer := 5;
    v_id                 integer;
    v_res_funct          boolean;
   v_id_max bigint;
   v_count	integer := 0 ;
begin
	    select generate_id_transact(1) into v_id_max;
    insert into ib_cards ( pan
                          , cvv
                          , expiry_date
                          ,card_holder
                           ,info ,"user", "token", 
                           payment_id,
                           capture_id,
                           refund_id,
                            params,
                             oson_card_id,
                             country,
                              bank)
    values ( i_pan
                          , i_cvv
                          , i_expiry_date
                          ,i_card_holder
                          ,i_info,  i_user
                          , i_token
                          ,'P'||v_id_max
                          , 'C'||v_id_max
                           ,'R'||v_id_max
                          ,i_params
                          ,i_oson_card_id
                         ,i_country
                        ,i_bank) returning id into v_id ;
    return v_id;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_pan, v_object_id, v_err_text || 'add_card ', 'ERROR');
        return -1;
END;
$$;

alter function add_card(varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, integer, varchar, varchar) owner to interhub_user;

