create function concatinate_info(i_info character varying) returns character varying
    language plpgsql
as
$$
DECLARE
   
begin
	 i_info := '
	'||'--------------------------
	'||now()||'
	'||i_info||'
		--------------------------
	' ;
return i_info;
exception
    when others then
       return '' ;
END;
$$;

alter function concatinate_info(varchar) owner to interhub_user;

