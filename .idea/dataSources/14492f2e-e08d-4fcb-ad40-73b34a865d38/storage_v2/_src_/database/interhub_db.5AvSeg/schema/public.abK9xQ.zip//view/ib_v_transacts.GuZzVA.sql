create view ib_v_transacts
            (id, client_account, transact_date, agent_transact_id, gateway_transact_id, commission_amount, currency_id,
             created_date, transact_amount, currency_code, amount_in_currency, amount_out_currency, info, currency_name,
             agent_name, merchant_name, category_name, state_name, gateway_merchant_name, gateway_name, tran_type,
             count, total_amount)
as
SELECT t.id,
       t.client_account,
       t.transact_date,
       t.agent_transact_id,
       t.gateway_transact_id,
       t.commission_amount,
       t.destination_currency_id                    AS currency_id,
       t.created_date,
       t.transact_amount,
       t.destination_currency_id::character varying AS currency_code,
       t.amount_in_currency,
       t.amount_out_currency,
       t.info,
       c.name                                       AS currency_name,
       (SELECT a.name
        FROM ib_agents a
        WHERE a.id = t.agent_id)                    AS agent_name,
       m.name                                       AS merchant_name,
       m.name                                       AS category_name,
       (SELECT o.name
        FROM ib_object_states o
        WHERE o.id = t.state_id
          AND o.object_id = 7)                      AS state_name,
       g.name                                       AS gateway_merchant_name,
       (SELECT gt.name
        FROM ib_gateways gt
        WHERE gt.id = g.gateway_id)                 AS gateway_name,
       t.tran_type,
       777                                          AS count,
       7777::numeric                                AS total_amount
FROM ib_currencies c,
     ib_transacts t
         LEFT JOIN ib_merchants m ON m.id = t.merchant_id
         LEFT JOIN ib_gateway_merchants g ON g.id = t.gateway_merchant_id
WHERE c.id = t.destination_currency_id
LIMIT 20;

alter table ib_v_transacts
    owner to interhub_user;

