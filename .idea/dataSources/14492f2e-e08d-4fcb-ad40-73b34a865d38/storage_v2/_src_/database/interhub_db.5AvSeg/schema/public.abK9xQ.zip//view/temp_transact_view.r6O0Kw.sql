create view temp_transact_view
            (id, agent_id, state_id, client_account, currency_id, gateway_merchant_id, merchant_id, transact_date,
             agent_transact_id, gateway_transact_id, payment_type_id, params, commission_amount, created_date,
             transact_amount, amount_in_currency, amount_out_currency, info, agent_name, payment_type, merchant_name,
             state_name, gateway_merchant_name, gateway_id, gateway_name, tran_type, source_currency_id,
             destination_currency_id, gateway_transact_date, count, total_amount)
as
SELECT t.id,
       t.agent_id,
       t.state_id,
       t.client_account,
       t.destination_currency_id                         AS currency_id,
       t.gateway_merchant_id,
       t.merchant_id,
       t.transact_date::character varying                AS transact_date,
       t.agent_transact_id,
       t.gateway_transact_id,
       t.payment_type_id,
       t.params,
       t.commission_amount,
       t.created_date::character varying                 AS created_date,
       t.transact_amount,
       t.amount_in_currency,
       t.amount_out_currency,
       t.info,
       (SELECT a.name
        FROM ib_agents a
        WHERE a.id = t.agent_id)                         AS agent_name,
       1                                                 AS payment_type,
       m.name                                            AS merchant_name,
       (SELECT o.name
        FROM ib_object_states o
        WHERE o.id = t.state_id
          AND o.object_id = 7)                           AS state_name,
       g.name                                            AS gateway_merchant_name,
       g.gateway_id,
       (SELECT gt.name
        FROM ib_gateways gt
        WHERE gt.id = g.gateway_id)                      AS gateway_name,
       t.tran_type,
       (SELECT a.currency_id
        FROM ib_agent_merchant a
        WHERE a.agent_id = t.agent_id
          AND a.merchant_id = t.merchant_id
          AND a.currency_id = t.destination_currency_id) AS source_currency_id,
       g.currency_id                                     AS destination_currency_id,
       t.gateway_transact_date,
       12                                                AS count,
       12::numeric                                       AS total_amount
FROM ib_currencies c,
     ib_transacts t
         LEFT JOIN ib_merchants m ON m.id = t.merchant_id
         LEFT JOIN ib_gateway_merchants g ON g.id = t.gateway_merchant_id
WHERE (c.id = ANY (ARRAY [860, 840, 643, 978]))
  AND c.id = t.destination_currency_id
  AND t.transact_date >= to_date('01.09.2020'::text, 'dd.mm.yyyy'::text)
  AND t.transact_date <= to_date('02.09.2020'::text, 'dd.mm.yyyy'::text);

alter table temp_transact_view
    owner to interhub_user;

