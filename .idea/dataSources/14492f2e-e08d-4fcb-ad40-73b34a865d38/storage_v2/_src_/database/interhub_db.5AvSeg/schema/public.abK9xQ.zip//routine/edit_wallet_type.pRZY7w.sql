create function edit_wallet_type(i_id integer, i_type_name character varying DEFAULT NULL::character varying, i_condition character varying DEFAULT NULL::character varying, i_max_amount bigint DEFAULT NULL::bigint) returns boolean
    language plpgsql
as
$$
DECLARE
    v_object_id constant integer := 5;
    v_type_name          varchar;
    v_condition          varchar;
    v_err_text           varchar;
    v_max_amount         bigint;
BEGIN
    select type_name, max_amount, condition
    into
        v_type_name , v_max_amount, v_condition
    from ib_wallet_types
    where id = i_id;
    if not found then
        v_err_text := 'takaya id ne nayden ';
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
    end if;
    if i_type_name is null then
        i_type_name := v_type_name;
    end if;
    if i_max_amount is null then
        i_max_amount := v_max_amount;
    end if;
    if i_condition is null then
        i_condition := v_condition;
    end if;
    update ib_wallet_types
    set type_name = i_type_name,
        max_amount= i_max_amount,
        condition = i_condition
    where id = i_id;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', v_object_id, v_err_text || ' edit_wallet_client ', 'ERROR');
        return false;
END;
$$;

alter function edit_wallet_type(integer, varchar, varchar, bigint) owner to interhub_user;

