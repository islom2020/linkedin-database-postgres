create view ib_v_juridical_wallet
            (id, name, parent_wallet_id, client_account, account_id, token, type, condition, client_id) as
SELECT t.id,
       t.name,
       t.parent_wallet_id,
       c.client_account,
       t.account_id,
       t.token,
       t.type,
       t.condition,
       c.client_id
FROM ib_client_accounts c,
     ib_jur_wallet_childs t
WHERE c.id = t.account_id;

alter table ib_v_juridical_wallet
    owner to interhub_user;

