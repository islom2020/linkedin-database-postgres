create view ib_v_client_deposit_agent
            (id, debit_amount, commission_amount, credit_amount, balance, group_id, deposit_date, commission_account,
             credit_account, debit_account, client_id)
as
SELECT t.id,
       (SELECT icd.debit_amount
        FROM ib_client_deposit icd,
             ib_client_accounts ica
        WHERE ica.id = icd.account_id
          AND icd.group_id = t.group_id
          AND icd.id <> t.id
          AND icd.account_id <> '-1'::integer) AS debit_amount,
       (SELECT icd.credit_amount
        FROM ib_client_deposit icd,
             ib_client_accounts ica
        WHERE ica.id = icd.account_id
          AND icd.group_id = t.group_id
          AND icd.id <> t.id
          AND icd.account_id = '-1'::integer)  AS commission_amount,
       t.credit_amount,
       t.balance,
       t.group_id,
       t.deposit_date,
       (SELECT ica.client_account
        FROM ib_client_deposit icd,
             ib_client_accounts ica
        WHERE ica.id = icd.account_id
          AND icd.group_id = t.group_id
          AND icd.id <> t.id
          AND icd.account_id = '-1'::integer)  AS commission_account,
       (SELECT ica.client_account
        FROM ib_client_deposit icd,
             ib_client_accounts ica
        WHERE ica.id = icd.account_id
          AND icd.group_id = t.group_id
          AND icd.id <> t.id
          AND icd.account_id <> '-1'::integer) AS credit_account,
       c.client_account                        AS debit_account,
       c.client_id
FROM ib_client_deposit t,
     ib_client_accounts c
WHERE c.id = t.account_id
  AND c.client_type_id = 2;

alter table ib_v_client_deposit_agent
    owner to interhub_user;

