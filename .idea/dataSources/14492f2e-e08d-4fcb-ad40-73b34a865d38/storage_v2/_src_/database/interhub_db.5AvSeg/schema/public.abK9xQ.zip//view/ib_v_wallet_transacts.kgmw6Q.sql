create view ib_v_wallet_transacts
            (id, currency_id, currency_name, source, source_client_name, transact_amount, destination_currency_id,
             destination_currency_name, destination, destination_client_name, destination_amount, created_date,
             commission_amount, state_name, type_name, payment_type, state_id, agent_transaction_id, count,
             total_amount)
as
SELECT t.id,
       t.currency_id,
       (SELECT ic.name
        FROM ib_currencies ic
        WHERE ic.id = t.currency_id)             AS currency_name,
       t.source,
       CASE t.payment_type
           WHEN 1 THEN (SELECT ch.name
                        FROM ib_jur_wallet_childs ch,
                             ib_client_accounts a
                        WHERE ch.account_id = a.id
                          AND a.client_account::text = t.source::text
                        LIMIT 1)
           ELSE (SELECT ag.client_name
                 FROM ib_clients ag
                 WHERE ag.phone_number::text = t.source::text
                 LIMIT 1)
           END                                   AS source_client_name,
       t.transact_amount,
       t.destination_currency_id,
       (SELECT ic.name
        FROM ib_currencies ic
        WHERE ic.id = t.destination_currency_id) AS destination_currency_name,
       t.destination,
       CASE t.payment_type
           WHEN 2 THEN (SELECT ch.name
                        FROM ib_jur_wallet_childs ch,
                             ib_client_accounts a
                        WHERE ch.account_id = a.id
                          AND a.client_account::text = t.destination::text
                        LIMIT 1)
           ELSE (SELECT ag.client_name
                 FROM ib_clients ag
                 WHERE ag.phone_number::text = t.destination::text)
           END                                   AS destination_client_name,
       t.destination_amount,
       t.created_date,
       t.commission_amount,
       (SELECT c.name
        FROM ib_object_states c
        WHERE c.id = t.state_id
          AND c.object_id = 7)                   AS state_name,
       p.type_name,
       t.payment_type,
       t.state_id,
       t.agent_transaction_id,
       1                                         AS count,
       1::numeric                                AS total_amount
FROM ib_wallet_transacts t,
     ib_s_wallet_payment_types p
WHERE t.payment_type = p.id;

alter table ib_v_wallet_transacts
    owner to interhub_user;

