create function get_bank_currencies(i_currency_id integer DEFAULT NULL::integer) returns SETOF ib_bank_currencies
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    v_date      date    := now();
BEGIN
    if i_currency_id is not null then
        v_condition := ' and c.currency_id = ' || i_currency_id;
    end if;
    
    return query execute ' SELECT  c.*
            FROM   ib_bank_currencies c
      WHERE  1 = 1 ' || v_condition;

END;
$$;

alter function get_bank_currencies(integer) owner to interhub_user;

