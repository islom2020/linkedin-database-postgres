create function add_currency(i_currency_code character varying, i_currency character varying, i_price numeric, i_name character varying, i_nominal integer, i_difference bigint, i_currency_date date) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_date               timestamp    := now();
    v_object_id constant integer := 6;
    v_count              integer := 0 ;
    v_price              numeric  := 0;
   r record;
BEGIN

    select count(*), max(t.price) into v_count , v_price from ib_currencies t where t.currency_code = i_currency_code;
    if v_count = 0 then
        insert into ib_currencies ( currency_code
                                  , price
                                  , currency_date
                                  , created_date
                                  , difference
                                  , nominal
                                  , mode_price
                                  , name
                                  , currency)
        values (i_currency_code,
                i_price,
                i_currency_date,
                v_date,
                i_difference
                   , i_nominal
                   , i_mode_price
                   , i_name
                   , i_currency);
    end if;
    if (v_price - (v_price * 7 / 100)) < i_price and i_price < (v_price + (v_price * 7 / 100)) then
        update ib_currencies t
        set price         = i_price,
            currency_date = i_currency_date,
            difference    =i_difference,
            nominal       = i_nominal,
            created_date  = now()
        where currency_code = i_currency_code;
        insert into ib_currencies_history select * from ib_currencies where currency_code = i_currency_code;
    else
        return false;
    end if;
   
	 if  i_currency_code in ('840' , '643','978') then  
	   for r in (select t.* from ib_s_currency_exchanges t where 
	   				from_currency_id =  i_currency_code::integer and  id  not in (1,6,8,9,10)) loop 
		   			perform add_currency_exchanges(i_amount => i_price ,
													i_from_currency_id => r.from_currency_id,
													i_to_currency_id => r.to_currency_id );
					perform add_currency_exchanges(i_amount => 1/i_price ,
													i_from_currency_id => r.to_currency_id ,
													i_to_currency_id =>r.from_currency_id );
												
	   end loop;
	  end if;
    return true;
exception
    when others THEN
        select max(id) into v_reference_id from ib_currencies;
        v_err_text := sqlerrm;
        RAISE INFO 'Error Name:%',SQLERRM;
        perform log_action_atx(v_reference_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
END;
$$;

alter function add_currency(varchar, varchar, numeric, varchar, integer, bigint, date) owner to interhub_user;

