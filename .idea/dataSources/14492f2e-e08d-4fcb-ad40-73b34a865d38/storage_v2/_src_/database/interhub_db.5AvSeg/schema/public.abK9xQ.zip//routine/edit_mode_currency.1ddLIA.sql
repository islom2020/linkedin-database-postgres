create function edit_mode_currency(i_currency_code character varying, i_mode_price bigint) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_object_id constant integer := 6;
    v_count              integer := 0 ;
BEGIN
    select count(*) into v_count from ib_currencies where currency_code = i_currency_code;
    if v_count > 0 then
        update ib_currencies
        set mode_price = i_mode_price
        where currency_code = i_currency_code;
        return true;
    else
        return false;
    end if;

END;
$$;

alter function edit_mode_currency(varchar, bigint) owner to interhub_user;

