create function add_agent(i_name character varying, i_payment_type integer, i_token character varying, i_commission bigint, i_currency_id integer, i_client_id integer DEFAULT NULL::integer, i_state_id integer DEFAULT 1) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_object_id constant integer := 2;
    v_id                 integer;
    v_res_funct          boolean;
    v_client_id          integer;
   v_count	integer := 0 ;
begin
	if i_Client_id is null then 
		select add_client(i_client_name => i_name, i_client_type => 'J') into i_client_id;
	else 
		select count(*) into v_count from ib_clients t where t.id   = i_client_id and client_type  = 'J';
		if 	v_count =0 then 
			raise 'can not find client';	
		end if;
	end if ;
    insert into ib_agents ( name
                          , payment_type
                          , token,
                            commission
                          , currency_id,
                            client_id,
                            state_id)
    values (i_name, i_payment_type, i_token, i_commission, i_currency_id, i_Client_id,  I_state_id )
    returning id into v_id;
      perform add_client_account_mode(i_client_id=> i_client_id,i_currency_id=> i_currency_id, i_client_type_id=>v_object_id,  i_account_type_id =>v_object_id ,i_jur_id=>v_id );

    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(nextval('ib_agent_id_seq') || '', v_object_id, v_err_text || 'add_agent', 'ERROR');
        return false;
END;
$$;

alter function add_agent(varchar, integer, varchar, bigint, integer, integer, integer) owner to interhub_user;

