create function take_deposit_back(i_client_id integer, i_cr_amount numeric, i_client_type_id integer, i_currency_id integer, i_group_id bigint, i_jur_id integer DEFAULT NULL::integer) returns integer
    language plpgsql
as
$$
DECLARE
    v_count          integer := 0 ;
    v_dep            numeric   := 0;
    v_res            boolean := false;
    v_client_account ib_client_accounts%rowtype;

BEGIN
    select t.*
    into v_client_account
    from ib_client_accounts t
    where t.client_id = i_client_id
    	and t.currency_id  = i_currency_id
      and t.client_type_id = i_client_type_id
      and t.account_type_id = i_client_type_id
      and coalesce (t.juridical_id,  i_jur_id) =  i_jur_id
      and t.condition = 'A' for update;
    v_client_account.balance := v_client_account.balance + i_cr_amount;
   select add_client_deposit(v_client_account.id, v_client_account.balance, 0, i_cr_amount, i_group_id)
    into v_res;
    if v_res = false then
        return -1;
    end if;
    update ib_client_accounts
    set balance = v_client_account.balance
    where id = v_client_account.id;
    
    return 1;
exception
    when others then
        perform log_action_atx(i_client_id || '', 4, sqlerrm || 'take_deposit_back', 'ERROR');
        return -1;

END;
$$;

alter function take_deposit_back(integer, numeric, integer, integer, bigint, integer) owner to interhub_user;

