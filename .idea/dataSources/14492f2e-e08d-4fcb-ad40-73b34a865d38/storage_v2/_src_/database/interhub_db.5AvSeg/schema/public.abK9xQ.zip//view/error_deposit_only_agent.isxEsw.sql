create view error_deposit_only_agent (id, account_id, debit_amount, credit_amount, balance, group_id, deposit_date) as
SELECT r.id,
       r.account_id,
       r.debit_amount,
       r.credit_amount,
       r.balance,
       r.group_id,
       r.deposit_date
FROM ib_client_deposit r
WHERE (r.group_id IN (SELECT d.group_id
                      FROM ib_client_deposit d
                      GROUP BY d.group_id
                      HAVING count(d.*) = 1));

alter table error_deposit_only_agent
    owner to interhub_user;

