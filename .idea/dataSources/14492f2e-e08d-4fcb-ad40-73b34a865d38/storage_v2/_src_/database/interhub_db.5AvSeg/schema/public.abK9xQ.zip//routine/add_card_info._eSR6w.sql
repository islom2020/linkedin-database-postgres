create function add_card_info(i_card_id integer, i_info character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_user   integer := 2;
    v_ref_id integer;
begin
	begin 
    insert into ib_cards_info ( card_id , info )
    values ( i_card_id
           , i_info
           ) ;
   exception   WHEN unique_violation THEN 
	    	update ib_cards_info set info = info || ' '|| i_info where card_id =  i_card_id;
       end;         
          return true ;
exception
    when others then 
        perform log_action_atx(i_car_id || '', 7, sqlerrm ||'add_card_info', 'ERROR');
       return false ;
END;
$$;

alter function add_card_info(integer, varchar) owner to interhub_user;

