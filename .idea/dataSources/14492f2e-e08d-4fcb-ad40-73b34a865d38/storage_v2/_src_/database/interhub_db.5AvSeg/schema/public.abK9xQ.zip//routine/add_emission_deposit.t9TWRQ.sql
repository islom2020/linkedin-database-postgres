create function add_emission_deposit(i_currency_id integer, i_deposit numeric, i_is_wallet character varying DEFAULT NULL::character varying, i_user_id integer DEFAULT NULL::integer, i_description character varying DEFAULT NULL::character varying, i_lead_id character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 2;
    v_client_id          integer;
    v_deposit            numeric  := 0 ; 
      v_is_control_jur_deposit       varchar ;
   v_res boolean;
   v_client_account    ib_Client_accounts%rowtype;
  v_group_id 	bigint;
BEGIN 
	 select -nextval('client_deposit_group_id_seq'):: bigint into v_group_id;
	if i_deposit is null  then 
		raise 'deposit 0 dan baland bulishi kerak ';
	end if;
	if i_is_wallet is null then 
		select t.* into v_client_account from ib_client_accounts t where t.account_type_id = 0  and t.currency_id  = i_currency_id
			and t.client_type_id  = 0  and t.client_account   =  '7777777'|| i_currency_id || '001' and 
			t.client_id  = 0  and "condition" = 'A' for update; 
		
	elsif i_is_wallet  ='Y'  then 
		
		select t.* into v_client_account from ib_client_accounts t where t.account_type_id = 0  and t.currency_id  = i_currency_id
			and t.client_type_id  = 0  and t.client_account   =  '666666'|| i_currency_id || '001' and 
			t.client_id  = 0  and "condition" = 'A' for update; 
	end if;
		if i_deposit <0 and   ( v_client_account.balance + i_deposit ) < 0 then 
				raise 'sen buncha pulni demissiya qila olmaysan';
		end if;
 
		v_client_account.balance  := v_client_account.balance +  i_deposit;
	 	if i_deposit <  0 then 
			select  add_client_deposit(v_client_account.id, v_client_account.balance, abs(i_deposit), 0, v_group_id) into v_res;
	 	else 
		 	select  add_client_deposit(v_client_account.id, v_client_account.balance, 0, i_deposit,v_group_id) into v_res;
		end if;  
				if v_res = false then 
			 	     raise ' can not add deposit ';
			    end if;
			     select t.value  into  v_is_control_jur_deposit  
  			from ib_settings t  where key = 'is_control_jur_deposit';
					 if v_is_control_jur_deposit = 'Y' then 
					    	if i_user_id is null then 
					    			raise 'user id should enter';
					    	end if;
					    /*	 if i_lead_id is null then 
					    			raise 'Leads id should enter';
					    	end if;*/
					 	   if i_description is null then 
					    			raise 'Pay purpose  should enter';
					    	end if;
					    	 if i_deposit <0 then  
					    			select
										*
									from
										control_juridical_deposit(i_from_account_id => v_client_account.id,
										i_to_account_id => 0,
										i_amount => i_deposit,
										i_user_id => i_user_id,
										i_group_id => v_group_id,
										i_lead_id =>  i_lead_id,
										i_descreption => i_description ) into v_res ;
							 else 
								select
										*
									from
										control_juridical_deposit(i_from_account_id => 0,
										i_to_account_id => v_client_account.id,
										i_amount => i_deposit,
										i_user_id => i_user_id,
										i_group_id => v_group_id ,
										i_lead_id	=>i_lead_id,
										i_descreption => i_description )  into v_res; 
					    	end if;
								 	if v_res = false then
								 		raise 'can not give permission by admin or superadmin';
								 	end if;
					    end if;    
			   
			   
	update ib_client_accounts
   	     set balance = v_client_account.balance
        where id = v_client_account.id; 
        if i_is_wallet ='Y' then 
	       			select t.* into v_client_account from ib_client_accounts t where t.account_type_id = 0  and t.currency_id  = i_currency_id
					and t.client_type_id  = 0  and t.client_account   =  '55555'|| i_currency_id || '001' and 
					t.client_id  = 0  and "condition" = 'A' for update; 
						v_client_account.balance  := v_client_account.balance -  i_deposit;
			if i_deposit <  0 then 
				select  add_client_deposit(v_client_account.id, v_client_account.balance, 0,abs(i_deposit), v_group_id) into v_res;
	 		else 
		 		select  add_client_deposit(v_client_account.id, v_client_account.balance, i_deposit,0,  v_group_id) into v_res;
			 end if;  
			
					
			if v_res = false then 
				 	     raise ' can not add deposit ';
				    end if;
			update ib_client_accounts
		   	     set balance = v_client_account.balance
		        where id = v_client_account.id; 
       end if;
return  true ;
       exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_currency_id || '', v_object_id, v_err_text || ' add_emission_deposit ', 'ERROR');
        return false;
END;
$$;

alter function add_emission_deposit(integer, numeric, varchar, integer, varchar, varchar) owner to interhub_user;

