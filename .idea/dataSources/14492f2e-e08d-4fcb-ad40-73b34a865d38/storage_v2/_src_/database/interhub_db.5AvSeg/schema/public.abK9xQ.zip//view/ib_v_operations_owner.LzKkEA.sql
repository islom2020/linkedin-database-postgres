create view ib_v_operations_owner
            (group_id, debit_amount, source_currency_id, credit_amount, destination_currency_id, comission_amount,
             source_client_name, source_client_id, destination_client_name, destination_client_id, credit_account,
             debit_account, deposit_date, transact_type, user_name, description, count, total_amount)
as
SELECT t.group_id,
       max(t.debit_amount)             AS debit_amount,
       (SELECT c.currency_id
        FROM ib_client_deposit r,
             ib_client_accounts c
        WHERE c.id = r.account_id
          AND r.group_id = t.group_id
          AND r.debit_amount <> 0::numeric
        LIMIT 1)                       AS source_currency_id,
       max(t.credit_amount)            AS credit_amount,
       (SELECT c.currency_id
        FROM ib_client_deposit r,
             ib_client_accounts c
        WHERE c.id = r.account_id
          AND r.group_id = t.group_id
          AND r.credit_amount <> 0::numeric
        LIMIT 1)                       AS destination_currency_id,
       0                               AS comission_amount,
       (SELECT cl.client_name
        FROM ib_client_deposit r,
             ib_client_accounts c,
             ib_clients cl
        WHERE c.id = r.account_id
          AND r.group_id = t.group_id
          AND r.debit_amount <> 0::numeric
          AND cl.id = c.client_id
        LIMIT 1)                       AS source_client_name,
       (SELECT c.client_id
        FROM ib_client_deposit r,
             ib_client_accounts c
        WHERE c.id = r.account_id
          AND r.group_id = t.group_id
          AND r.debit_amount <> 0::numeric
        LIMIT 1)                       AS source_client_id,
       (SELECT cl.client_name
        FROM ib_client_deposit r,
             ib_client_accounts c,
             ib_clients cl
        WHERE c.id = r.account_id
          AND r.group_id = t.group_id
          AND r.credit_amount <> 0::numeric
          AND cl.id = c.client_id
        LIMIT 1)                       AS destination_client_name,
       (SELECT c.client_id
        FROM ib_client_deposit r,
             ib_client_accounts c
        WHERE c.id = r.account_id
          AND r.group_id = t.group_id
          AND r.credit_amount <> 0::numeric
        LIMIT 1)                       AS destination_client_id,
       (SELECT c.client_account
        FROM ib_client_deposit r,
             ib_client_accounts c
        WHERE c.id = r.account_id
          AND r.group_id = t.group_id
          AND r.credit_amount <> 0::numeric
          AND c.account_type_id <> 4
        LIMIT 1)                       AS credit_account,
       (SELECT c.client_account
        FROM ib_client_deposit r,
             ib_client_accounts c
        WHERE c.id = r.account_id
          AND r.group_id = t.group_id
          AND r.debit_amount <> 0::numeric
          AND c.account_type_id <> 4
        LIMIT 1)                       AS debit_account,
       max(t.deposit_date)             AS deposit_date,
       'O'::text                       AS transact_type,
       (SELECT u.fullname
        FROM ib_jur_client_deposit r,
             ib_users u
        WHERE r.group_id = t.group_id
          AND r.created_by = u.id)     AS user_name,
       (SELECT r.descreption
        FROM ib_jur_client_deposit r
        WHERE r.group_id = t.group_id) AS description,
       1                               AS count,
       1::numeric                      AS total_amount
FROM ib_client_deposit t
WHERE t.group_id < 1000
GROUP BY t.group_id
ORDER BY t.group_id;

alter table ib_v_operations_owner
    owner to interhub_user;

