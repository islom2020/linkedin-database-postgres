create function edit_client_deposit(i_client_id integer, i_client_type_id integer, i_currency_id integer, i_deposit numeric, i_cr_or_dr character varying, i_account_type_id integer, i_jur_id integer, i_is_wallet_agent character varying DEFAULT NULL::character varying, i_auto_calculate character varying DEFAULT NULL::character varying, i_description character varying DEFAULT NULL::character varying, i_user_id integer DEFAULT NULL::integer, i_lead_id character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 2;
    v_client_id          integer;
    v_deposit            numeric  := 0 ;
    v_currency_code      varchar ;
    v_dep                numeric ;
    v_emission_id        integer;
    v_count              integer;
    v_emission_dep       numeric  := 0;
      v_is_control_jur_deposit       varchar ;
    v_group_id           bigint  := 0;
    v_client_account     ib_client_accounts%rowtype;
    v_res                boolean;
    v_over_count         integer := 0;
    v_over_balance       numeric;
    v_total              numeric;
    v_over_id            integer ;
   v_jur_client_amount numeric ;
BEGIN 
	
    select -nextval('client_deposit_group_id_seq'):: bigint into v_group_id;
--
    select *
    into v_client_account
    from ib_client_accounts
    where client_id = i_client_id
      and client_type_id = i_client_type_id
      and account_type_id = i_account_type_id 
      and currency_id = i_currency_id
      and coalesce ( juridical_id,  i_jur_id) =  i_jur_id  ;
 if not found then 
 	raise 'can not find  account';
 end if;
    begin
        select currency_code
        into v_currency_code
        from ib_currencies
        where id = i_currency_id;
    exception
        when others then
            return false;
    end;
   if i_is_wallet_agent is null then 
    select id, balance
    into v_emission_id,
        v_emission_dep
    from ib_client_accounts t
    where t.client_account = '7777777' || v_currency_code || '001' for update;
elsif i_is_wallet_agent = 'Y'  then 
	if i_cr_or_dr ='DR' then 
		select id, balance
	    into v_emission_id,
	        v_emission_dep
	    from ib_client_accounts t
	    where t.client_account = '666666' || v_currency_code || '001' for update;
	 else 
		select id, balance
	    into v_emission_id,
	        v_emission_dep
	    from ib_client_accounts t
	    where t.client_account = '666666' || v_currency_code || '001' for update;
	 end if;
    select count(*) into v_Count
			from
				ib_wallets t ,
				ib_jur_wallet_childs c
			where
				c.parent_wallet_id = t.id
				and t.wallet_type = 100
				and t.client_id = i_client_id ;
  	if v_Count =  0     then
  			raise 'bunaqa wallet agent schot yuq ';
  	end if;
  
end if;
	if i_auto_calculate  = 'Y' then 
		i_cr_or_dr := 'CR';
	select t.balance into i_deposit 
		from ib_client_deposit t where   t.deposit_date    <  current_date  
		and t.account_id  = v_client_account.id  
		and  id =  (select  max(id) from ib_client_deposit r  where  
				r.deposit_date    <  current_date  
					and r.account_id  = v_client_account.id  ) ;
				if i_deposit  > v_client_account.balance then 
 				 	raise 'something is error with auto calculate deposit one day ago ';
--					i_deposit  := v_client_account.balance;	
			end if;
   end if;
  
	    if v_emission_dep < i_deposit and i_cr_or_dr = 'DR' then
	       raise 'deposit emissiyasi kiritilgan puldan kam';
	    end if;
    select t.value  into  v_is_control_jur_deposit  
  			from ib_settings t  where key = 'is_control_jur_deposit';
    --v_deposit := v_deposit + i_deposit;
    if v_is_control_jur_deposit = 'Y' then 
    	/*if i_user_id is null then 
    			raise 'user id should enter';
    	end if;*/
    /*	 if i_lead_id is null then 
    			raise 'Leads id should enter';
    	end if;*/
 	  /* if i_description is null then 
    			raise 'Pay purpose  should enter';
    	end if;*/
    	 if i_cr_or_dr = 'CR' then  
    			select
					*
				from
					control_juridical_deposit(i_from_account_id => v_client_account.id,
					i_to_account_id => v_emission_id,
					i_amount => i_deposit,
					i_user_id => i_user_id,
					i_group_id => v_group_id,
					i_lead_id =>  i_lead_id,
					i_descreption => i_description ) into v_res ;
		 else 
		select
					*
				from
					control_juridical_deposit(i_from_account_id =>  v_emission_id,
					i_to_account_id =>v_client_account.id,
					i_amount => i_deposit,
					i_user_id => i_user_id,
					i_group_id => v_group_id ,
					i_lead_id	=>i_lead_id,
					i_descreption => i_description )  into v_res; 
    	end if;
			 	if v_res = false then
			 		raise 'can not give permission by admin or superadmin';
			 	end if;
    end if; 
    if i_cr_or_dr = 'DR' then
        v_emission_dep := v_emission_dep - i_deposit;     ---- emissiyadan pul olish
        select add_client_deposit(v_emission_id, v_emission_dep, i_deposit, 0, v_group_id) into v_res;
		 if v_res = false then 
		 	raise 'can not added';
		 end if;
       update ib_client_accounts set balance = v_emission_dep where id = v_emission_id;
       
		  if v_client_account.is_overdraft = 'Y' then
		            select count(t.*)
		                 , sum(t.balance)
		                 , max(id)
		            into v_over_count , v_over_balance, v_over_id
		            from ib_client_accounts t
		            where t.account_type_id = 4
		              and t.client_id = i_client_id
		              and t.currency_id = i_currency_id 
		              and t.client_type_id = i_client_type_id
				      and coalesce (t.juridical_id,  i_jur_id) =  i_jur_id
		              and condition = 'A';
		            if v_over_count > 0 and v_over_balance is not null and v_over_balance < 0 then
		                v_total := i_deposit + v_over_balance;
		                if v_total <= 0 then    ---- overdrafti depositidan kup bolgan holat 
		                    select add_client_deposit(v_over_id, v_total, 0, i_deposit, v_group_id) into v_res;
		                   		 if v_res = false then 
					 					raise 'problem with over1';
								 end if;
		                	update ib_client_accounts set balance = v_total where id = v_over_id;
		                   
		                else  ---- overdraftidan qutilgan holat 
		               		 select  add_client_deposit(v_over_id, 0, 0, abs(v_over_balance), v_group_id) into v_res;
		                    	if v_res = false then 
					 					raise 'overdraftidan qutilgan holat ';
								 end if;
		                    update ib_client_accounts set balance = 0 where id = v_over_id;
		                   
		                    v_client_account.balance := v_client_account.balance + v_total;
								select  add_client_deposit(v_client_account.id, v_client_account.balance, 0, v_total, v_group_id) 							into v_res;
		                  	 	if v_res = false then 
					 					raise  'problem with over2';
								 end if;
		                   	update ib_client_accounts set balance = v_client_account.balance where id = v_client_account.id;
		                end if;
		
		            else
		                v_client_account.balance := v_client_account.balance + i_deposit;
		        		  select  add_client_deposit(v_client_account.id, v_client_account.balance, 0, i_deposit, v_group_id) into v_res ;
							if v_res = false then 
					 				 raise 'overdraftsiz holat ';
					   		 end if;
		               update ib_client_accounts set balance = v_client_account.balance where id = v_client_account.id;
		
		            end if;

        else
            v_client_account.balance := v_client_account.balance + i_deposit;
            select  add_client_deposit(v_client_account.id, v_client_account.balance, 0, i_deposit, v_group_id) into v_res;
					if v_res = false then 
			 				 raise 'problem with DR';
			   		 end if;
           update ib_client_accounts set balance = v_client_account.balance where id = v_client_account.id;
        end if;

    elsif i_cr_or_dr = 'CR'    then
    	/*select  j.amount into v_jur_client_amount from ib_jur_client_deposit j where
    		j.from_account_id = v_client_account.id and state_id = 5;
    	if not found then 
    		  perform log_action_atx(i_client_id || '', v_object_id,   ' normal  holat edit_client_deposit ', 'INFO');
    	end if;
    	if v_Client_account.client_type_id = 3  and v_jur_client_amount is not null and 
    		v_client_account.balance <  (v_jur_client_amount+ i_deposit) then 
    			raise 'oldingi pravodkani tasdiqlang ';	
    	end if;	*/
    	if  v_client_account.balance < i_deposit then
    		raise 'client depositida yetarlicha pul mavjud emas ';
    	end if;
        v_emission_dep := v_emission_dep + i_deposit;
        v_client_account.balance := v_client_account.balance - i_deposit;
        select  add_client_deposit(v_client_account.id, v_client_account.balance, i_deposit, 0, v_group_id)into v_res;
        select  add_client_deposit(v_emission_id, v_emission_dep, 0, i_deposit, v_group_id) into v_res;
				if v_res = false then 
			 	     raise 'xatolik';
			    end if;
       	update ib_client_accounts
   	     set balance = v_emission_dep
        where id = v_emission_id;
        update ib_client_accounts set balance = v_client_account.balance 
        where id = v_client_account.id;

    end if;
   return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_client_id || '', v_object_id, v_err_text || ' edit_client_deposit ', 'ERROR');
        return false;
END;
$$;

alter function edit_client_deposit(integer, integer, integer, numeric, varchar, integer, integer, varchar, varchar, varchar, integer, varchar) owner to interhub_user;

