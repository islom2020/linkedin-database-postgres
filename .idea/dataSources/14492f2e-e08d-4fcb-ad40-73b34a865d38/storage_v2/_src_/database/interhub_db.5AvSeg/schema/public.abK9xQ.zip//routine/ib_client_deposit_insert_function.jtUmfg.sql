create function ib_client_deposit_insert_function() returns trigger
    language plpgsql
as
$$
DECLARE
    partition_date    TEXT;
    partition_name    TEXT;
    start_of_month    TEXT;
    end_of_next_month TEXT;
BEGIN
    partition_date := to_char(NEW.deposit_date, 'YYYY_MM');
    partition_name := 'ib_client_deposit_' || partition_date;
    start_of_month := to_char((NEW.deposit_date), 'YYYY-MM') || '-01';
    end_of_next_month := to_char((NEW.deposit_date + interval '1 month'), 'YYYY-MM') || '-01';
    IF NOT EXISTS
        (SELECT *
         FROM information_schema.tables
         WHERE table_name = partition_name)
    THEN
        RAISE NOTICE 'A partition has been created %', partition_name;
        EXECUTE format(
                E'CREATE TABLE %I (CHECK ( date_trunc(\'day\', deposit_date) >= ''%s'' AND date_trunc(\'day\', deposit_date) < ''%s'')) INHERITS (public.ib_client_deposit)',
                partition_name, start_of_month, end_of_next_month);
                EXECUTE 'CREATE   INDEX '  || partition_name || '_group_idx ON '  ||   partition_name || ' (group_id  )';
                EXECUTE 'CREATE   INDEX '  || partition_name || '_account_idx ON '  ||   partition_name || ' (account_id, debit_amount, credit_amount  )';
               
    END IF;
    EXECUTE format('INSERT INTO %I (
  id ,
     account_id ,
     debit_amount,
     credit_amount ,
     balance ,
     group_id ,
     deposit_date ) VALUES($1,$2,$3,$4,$5,$6,$7)', partition_name) using
        NEW.id
        , NEW.account_id
        , NEW.debit_amount
        , NEW.credit_amount
        , NEW.balance
        , NEW.group_id 
        , NEW.deposit_date;
    RETURN NULL;
END
$$;

alter function ib_client_deposit_insert_function() owner to interhub_user;

