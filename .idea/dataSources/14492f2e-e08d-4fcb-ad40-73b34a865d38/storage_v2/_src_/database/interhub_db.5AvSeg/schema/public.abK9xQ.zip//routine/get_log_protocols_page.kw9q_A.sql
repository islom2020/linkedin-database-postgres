create function get_log_protocols_page(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_id integer DEFAULT NULL::integer, i_object_id integer DEFAULT NULL::integer, i_reference_id integer DEFAULT NULL::integer, i_modified_on_from character varying DEFAULT NULL::character varying, i_modified_on_to character varying DEFAULT NULL::character varying, i_modified_by integer DEFAULT NULL::integer, i_info character varying DEFAULT NULL::character varying, i_ordered_by character varying DEFAULT NULL::character varying, i_is_desc character varying DEFAULT NULL::character varying)
    returns TABLE(id integer, reference_id integer, object_id integer, log_text character varying, modified_on timestamp without time zone, modified_by integer, info character varying, count integer)
    language plpgsql
as
$$
DECLARE
v_condition varchar := '';

begin
		if i_object_id is not null then
		  v_condition :=v_condition  || ' and object_id  = ' ||i_object_id;
		end if;
		 if i_ordered_by is   null then
        	  i_ordered_by := '1';
     	end if;
	    if i_is_desc  ='Y' then
         	 i_ordered_by := i_ordered_by || ' desc ';
        end if;
		if i_reference_id is not null then
		v_condition :=v_condition || 'and reference_id = ' || i_reference_id;
		end if;
	if i_id is not null then
		v_condition :=v_condition || 'and reference_id = ' || i_id;
		end if;
		if i_modified_on_from is not null then
			v_condition := v_condition ||  ' and  t.modified_on  >= to_date( ''' ||
                       i_modified_on_from || ''', ''dd.mm.yyyy'')';
		end if;
		
		if i_modified_on_to is not null then
			v_condition := v_condition ||  ' and  t.modified_on  <= to_date( ''' ||
                       i_modified_on_to || ''', ''dd.mm.yyyy'')';
		end if;
		
		if i_modified_by is not null then
			v_condition := v_condition || 'and modified_by = ' || i_modified_by;
		end if;
		if i_info is not null then
			v_condition := v_condition || 'and info = ''' || i_info||'''';
		end if;
return query execute ' SELECT  t.*, count(*)  over()::integer as count  FROM ib_log_protocols  t
      WHERE   1= 1 ' || v_condition ||
                         'order by  '||i_ordered_by||'  limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;
    IF NOT FOUND THEN  
        perform log_action_atx(v_condition || '', 2, 'Данный не найден ид :' || v_condition, 'OK');
    END IF;
end;
$$;

alter function get_log_protocols_page(integer, integer, integer, integer, integer, varchar, varchar, integer, varchar, varchar, varchar) owner to interhub_user;

