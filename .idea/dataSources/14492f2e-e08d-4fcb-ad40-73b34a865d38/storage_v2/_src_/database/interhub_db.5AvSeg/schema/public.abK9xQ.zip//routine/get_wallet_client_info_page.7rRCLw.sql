create function get_wallet_client_info_page(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_id integer DEFAULT NULL::integer, i_first_name character varying DEFAULT NULL::character varying, i_surname character varying DEFAULT NULL::character varying, i_last_name character varying DEFAULT NULL::character varying, i_birth_date date DEFAULT NULL::date, i_doc_number character varying DEFAULT NULL::character varying, i_nationality character varying DEFAULT NULL::character varying, i_birth_address character varying DEFAULT NULL::character varying, i_mail_address character varying DEFAULT NULL::character varying, i_state_id integer DEFAULT NULL::integer, i_client_id integer DEFAULT NULL::integer, i_region_id integer DEFAULT NULL::integer, i_phone_number character varying DEFAULT NULL::character varying, i_wallet_type integer DEFAULT NULL::integer, i_filial_id integer DEFAULT NULL::integer, i_user_id integer DEFAULT NULL::integer)
    returns TABLE(id integer, first_name character varying, surname character varying, last_name character varying, birth_date character varying, doc_number character varying, nationality character varying, gender character varying, birth_address character varying, expiry_doc character varying, authority character varying, registration_address character varying, doc_photo_url character varying, mail_address character varying, self_photo character varying, state_id integer, client_id integer, info character varying, created_date character varying, region_id integer, modified_date character varying, created_doc_date character varying, doc_address_photo character varying, oson_file character varying, yandex_file character varying, qiwi_file character varying, wallet_type integer, filial_id integer, count integer)
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 5;
     v_condition varchar := '';
    v_count  integer :=0 ;
    begin 
		    if i_phone_number is not null then 
				 select r.client_id  into  i_client_id  from ib_wallets r 
						where r.phone_number =  i_phone_number ;
				 if not found then 
					return ;
				end if; 
		    end if;
	     if i_state_id is not null  then
       		 v_condition := v_condition || ' and t.state_id  = ' || i_state_id||  ' and t.client_wallet_type != ' || 3   ;
   		 end if;
	     if i_id is not null then
       		 v_condition := v_condition || ' and t.id  = ' || i_id ;
   		 end if;
   		 if i_region_id is not null then
       		 v_condition := v_condition || ' and t.region_id  = ' || i_region_id ;
   		 end if; 
   		
   		 if i_filial_id is not null then
       		 v_condition := v_condition || ' and t.filial_id  = ' || i_filial_id ;
   		 end if; 
   		
   		 if i_wallet_type is not null then
       		 v_condition := v_condition || ' and t.client_wallet_type  = ' || i_wallet_type ;
   		 end if;
   		  if i_doc_number is not null then
       		 v_condition := v_condition || ' and t.doc_number  = ''' || i_doc_number||'''' ;
   		 end if; 
   		if i_mail_address is not null then
       		 v_condition := v_condition || ' and t.mail_address  = ''' || i_mail_address||'''' ;
   		 end if;
   		 if  i_user_id is not null  then 
   		 	 v_condition := v_condition || ' and t.id  in (  select  wallet_client_info_id from ib_wallet_client_info_his h  where h.user_id = ' || i_user_id || ' ) ' ;
   		 end if;
	    if i_first_name is not null then
    		    v_condition := v_condition || 'and lower(t.first_name) like ''%' || lower(i_first_name) || '%' || '''';
  		  end if;
	     if i_surname is not null then
    	    v_condition := v_condition || 'and lower(t.surname) like ''%' || lower(i_surname) || '%' || '''';
   		 end if;
	     if i_last_name is not null then
    	    v_condition := v_condition || 'and lower(t.last_name) like ''%' || lower(i_last_name) || '%' || '''';
   		 end if;
   		
	     if i_client_id is not null then
       		 v_condition := v_condition || ' and t.client_id  = ' || i_client_id ;
   		 end if;
 		if i_wallet_type is not null then 
	   		EXECUTE 'select  count(*)  from ib_clients  t where 1=1   ' || v_condition into v_count;
   		else 
   			EXECUTE 'select  count(*)  from ib_v_wallet_client_info  t where 1=1   ' || v_condition into v_count;
   		end if;
   		return query execute 'SELECT t.id,
					    t.first_name,
					    t.surname,
					    t.last_name,
					    t.birth_date,
					    t.doc_number,
					    t.nationality,
					    t.gender,
					    t.birth_address,
					    t.expiry_doc,
					    t.authority,
					    t.registration_address,
					    t.doc_photo_url,
					    t.mail_address,
					    t.self_photo,
					    t.state_id,
					    t.client_id,
					    t.info,
					    t.created_date::character varying AS created_date,
					    t.region_id,
					    t.modified_date::character varying AS modified_date,
					    t.created_doc_date,
					    t.doc_address_photo,
					    t.oson_file,
					    t.yandex_file,
					    t.qiwi_file,
					    t.client_wallet_type,
					    t.filial_id, '|| v_count || '  as count 
 				from  ib_v_wallet_client_info t
      WHERE   1= 1     ' || v_condition  ||
                         'order by t.id desc limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;
  exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(v_condition, v_object_id, v_err_text || 'get_wallet_client_info_page', 'ERROR');
        
END;
$$;

alter function get_wallet_client_info_page(integer, integer, integer, varchar, varchar, varchar, date, varchar, varchar, varchar, varchar, integer, integer, integer, varchar, integer, integer, integer) owner to interhub_user;

