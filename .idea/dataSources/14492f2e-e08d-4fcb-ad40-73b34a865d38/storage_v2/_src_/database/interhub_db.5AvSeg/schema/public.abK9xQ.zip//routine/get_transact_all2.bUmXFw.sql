create function get_transact_all2(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_id bigint DEFAULT NULL::bigint, i_merchant_id integer DEFAULT NULL::integer, i_transact_date_from character varying DEFAULT to_char(now(), 'dd.mm.yyyy'::text), i_transact_date_to character varying DEFAULT NULL::character varying, i_agent_id integer DEFAULT NULL::integer, i_state_id integer DEFAULT NULL::integer, i_gateway_id integer DEFAULT NULL::integer, i_client_account character varying DEFAULT NULL::character varying, i_agent_transact_id character varying DEFAULT NULL::character varying, i_gateway_merchant_id integer DEFAULT NULL::integer, i_gateway_transact_id character varying DEFAULT NULL::character varying, i_tran_type integer DEFAULT NULL::integer, i_ordered_by character varying DEFAULT NULL::character varying, i_is_desc character varying DEFAULT NULL::character varying, i_states character varying DEFAULT NULL::character varying, i_category_id integer DEFAULT NULL::integer)
    returns TABLE(id bigint, agent_id integer, state_id integer, client_account character varying, currency_id integer, gateway_merchant_id integer, merchant_id integer, transact_date character varying, agent_transact_id character varying, gateway_transact_id character varying, payment_type_id integer, params text, commission_amount numeric, created_date character varying, transact_amount numeric, amount_in_currency numeric, amount_out_currency numeric, info character varying, agent_name character varying, payment_type integer, merchant_name character varying, state_name character varying, gateway_merchant_name character varying, gateway_id integer, gateway_name character varying, tran_type integer, source_currency_id integer, destination_currency_id integer, gateway_transact_date character varying, count integer, total_amount numeric)
    language plpgsql
as
$$
DECLARE
	    v_transact_count integer := 0;
		   v_total_Count integer:= 0;
	    v_condition      varchar := '';
	   	r record;
	 	rec record;
	   v_gateway_condition varchar := '';
	  v_currency_id 	integer;
	 v_statement varchar;
	  v_transact_amount 	numeric:= 0;
	  v_total_amount	numeric:= 0;
begin
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_merchant_id is not null then
        v_condition := v_condition || ' and t.merchant_id  = ' || i_merchant_id;
    end if;
    if i_ordered_by is   null then
          i_ordered_by := '1';
     end if;
	  if i_is_desc is null  then
          i_ordered_by := i_ordered_by || ' desc ';
      end if;
    if i_gateway_merchant_id  is not null then
        v_condition := v_condition || ' and t.gateway_merchant_id  = ' || i_gateway_merchant_id;
    end if;
   
    if i_gateway_id is not null then
    for r in (
        select s.id from ib_gateway_merchants  s where s.gateway_id  = i_gateway_id ) 
    	loop 
        	 v_gateway_condition := v_gateway_condition ||  r.id ||' ,';
       end loop; 

     if v_gateway_condition != '' then 
      v_gateway_condition :=  substring (v_gateway_condition ,  1, length(v_gateway_condition) -1); 
     v_condition := v_condition || ' and t.gateway_merchant_id  in ( ' ||v_gateway_condition|| ' )';
    else 
    	 v_condition := v_condition || ' and t.gateway_id  = ' || i_gateway_id;
     end if;
    
    end if;
    if i_tran_type is not null then
        v_condition := v_condition || ' and t.tran_type  = ' || i_tran_type;
    end if;
    if i_agent_id is not null then
        v_condition := v_condition || ' and t.agent_id  = ' || i_agent_id;
    end if;
    if i_state_id is not null then
        v_condition := v_condition || ' and t.state_id  = ' || i_state_id;
    end if;
    if i_states is not null then
        v_condition := v_condition || ' and t.state_id  in ( ' || i_states||' ) ';
    end if;
    if i_agent_transact_id is not null then
        v_condition := v_condition || ' and t.agent_transact_id  = ''' || i_agent_transact_id || '''';
    end if;
     if i_gateway_transact_id  is not null then
        v_condition := v_condition || ' and t.gateway_transact_id   = ''' || i_gateway_transact_id  || '''';
    end if;
    if i_client_account is not null then
        v_condition := v_condition || 'and lower(t.client_account) like ''%' ||
                       lower(i_client_account) || '%' || '''';
    end if;
   
    if i_category_id is not null then
        v_condition := v_condition || ' and t.merchant_id in (select id from ib_merchants x where x.category_id =  ' || i_category_id || ' ) ';
    end if;
    if i_transact_date_from is not null then
        v_condition := v_condition ||
                       ' and  t.transact_date  >= to_date( ''' ||
                       i_transact_date_from || ''', ''dd.mm.yyyy'')';
    end if;
    if i_transact_date_to is not null then
        v_condition := v_condition ||
                       ' and  t.transact_date  < to_date( ''' ||
                       i_transact_date_to || ''', ''dd.mm.yyyy'')';
    end if;
	
EXECUTE 'select  count(*)   from ib_transacts t where 1=1 ' || v_condition into v_transact_count;
   v_statement:=  'select
	count(*)  count,
	sum(transact_amount)  total_amount,
	a.currency_id 
from
	ib_transacts t,ib_agents a  where a.id =t.agent_id    ' || v_condition ||  'group by a.currency_id ';
   for rec  in execute v_statement 
   		loop 
   				select * from calculate_exchange_amount(rec.total_amount, rec.currency_id, 860)into 
   					v_transact_amount;
   				v_total_amount := v_total_amount + v_transact_amount;
   				v_total_count := V_total_count +rec.count ;
   		end loop;
   		
    return query execute 'select t.id,
       t.agent_id,
       t.state_id,
       t.client_account,
       t.currency_id,
       t.gateway_merchant_id,
       t.merchant_id,
       t.transact_date::varchar,
       t.agent_transact_id,
       t.gateway_transact_id,
       t.payment_type_id,
       t.params,
       t.commission_amount,
       t.created_date ::varchar,
       t.transact_amount,
       t.amount_in_currency,
       t.amount_out_currency,
       t.info,
       ( select a.name from ib_agents  a where a.id  = t.agent_id)as agent_name  ,' ||
       1 :: integer ||' as payment_type,
       m.name merchant_name,
       (select o.name  from ib_object_states o   where o.id  = t.state_id and o.object_id = 7) as state_name,
       g.name as gateway_merchant_name,
       g.gateway_id,
       (SELECT gt.name
        FROM ib_gateways gt
        WHERE gt.id = g.gateway_id) AS gateway_name, 
		tran_type ,
		 (select currency_id from ib_agent_merchant  a where a.agent_id =  t.agent_id and a.merchant_id= t.merchant_id and a.currency_id = t.currency_id ) as source_currency_id ,
		g.currency_id  destination_currency_id,  t.gateway_transact_date , 
                       '|| v_transact_count|| ' as count, '||  trunc(v_total_amount, 2) || ' as total_amount    from   ib_currencies c ,ib_transacts t
                          LEFT JOIN ib_merchants m ON m.id = t.merchant_id
                          LEFT JOIN ib_gateway_merchants g ON g.id = t.gateway_merchant_id
        where  c.id in (860, 840, 643, 978) and  c.id  = t.currency_id ' || v_condition ||
                         'order by  '||i_ordered_by||'  limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;

end ;
$$;

alter function get_transact_all2(integer, integer, bigint, integer, varchar, varchar, integer, integer, integer, varchar, varchar, integer, varchar, integer, varchar, varchar, varchar, integer) owner to interhub_user;

