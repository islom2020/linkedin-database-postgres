create function edit_user(i_id integer, i_login character varying DEFAULT NULL::character varying, i_password character varying DEFAULT NULL::character varying, i_condition character varying DEFAULT NULL::character varying, i_fullname character varying DEFAULT NULL::character varying, i_role_id integer DEFAULT NULL::integer, i_access_priority character varying DEFAULT NULL::character varying, i_owner_id integer DEFAULT NULL::integer, i_info character varying DEFAULT NULL::character varying, i_filial_id integer DEFAULT NULL::integer) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id integer;
    v_role_id       integer;
    v_err_text     varchar;
    v_login        varchar;
    v_pass         varchar;
    v_fullname     varchar;
    v_condition    varchar;
   v_access_priority varchar ;
    v_filial_id integer;
  v_owner_id   integer;
 v_info  varchar ;
BEGIN
    select login, password, fullname, condition,  role_id,  access_priority,owner_id,  info ,  filial_id 
    into
        v_login , v_pass, v_fullname , v_condition,v_role_id, v_access_priority , v_owner_id, v_info,v_filial_id
    from ib_users
    where id = i_id;
    if not found then
        v_err_text := 'takaya id ne nayden ';
        perform log_action_atx(i_id || '', -1, v_err_text, 'ERROR');
        return false;
    end if;
    if i_login is null then
        i_login := v_login;
    end if;
      if i_access_priority is null then
        i_access_priority := v_access_priority;
    end if;
      if i_filial_id is null then
        i_filial_id := v_filial_id;
    end if;
       if i_owner_id is null then
        i_owner_id := v_owner_id;
    end if;
    if i_password is null then
        i_password := v_pass;
    end if;

    if i_role_id is null then
        i_role_id := v_role_id;
    end if;
    if i_fullname is null then
        i_fullname := v_fullname;
    end if;
    if i_condition is null then
        i_condition := v_condition;
    end if;
   
    if i_info is null then
        i_info := v_info;
    end if;
    update ib_users
    set login     = i_login,
        password  = i_password,
        fullname  = i_fullname,
        condition = i_condition,
        role_id = i_role_id,
        info = i_info,
         access_priority = i_access_priority,
         owner_id =  i_owner_id,
         filial_id = i_filial_id
    where id = i_id;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', -1, v_err_text, 'ERROR');
        return false;
END;
$$;

alter function edit_user(integer, varchar, varchar, varchar, varchar, integer, varchar, integer, varchar, integer) owner to interhub_user;

