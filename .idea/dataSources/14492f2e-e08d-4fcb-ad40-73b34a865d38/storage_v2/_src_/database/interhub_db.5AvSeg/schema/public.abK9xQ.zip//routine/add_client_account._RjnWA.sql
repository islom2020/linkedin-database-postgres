create function add_client_account(i_client_id integer, i_currency_id integer, i_client_type_id integer, i_jur_id integer DEFAULT NULL::integer, i_is_overdraft character varying DEFAULT 'N'::character varying, i_overdraft_amount bigint DEFAULT 0, i_client_condition character varying DEFAULT 'A'::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id   integer;
    v_err_text       varchar;
    v_client_account varchar;
    v_id             integer;
    v_client_id      varchar;
    v_prefix         varchar;
    v_ord            varchar;
BEGIN
    select t.code into v_prefix from ib_s_client_account_types t where type_id = i_client_type_id;
    select generate_id_client_for_account(i_client_id) into v_client_id;
    v_client_account := v_prefix || i_client_type_id || i_currency_id || v_client_id || '001';

    insert into ib_client_accounts ( client_id,
                                     client_type_id,
                                     balance
                                   , client_account
                                   , currency_id
                                   , created_date
                                   , modified_by
                                   , modified_on
                                   , condition
                                   , account_type_id
                                   , is_overdraft,
                                     overdraft_amount
                                    ,juridical_id )
    values (i_client_id,
            i_client_type_id,
            0,
            v_client_account,
            i_currency_id,
            now(),
            -1,
            now(),
            i_client_condition,
            i_client_type_id,
            i_is_overdraft,
            i_overdraft_amount,
            i_jur_id)
    returning id into v_id;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        select max(id) into v_reference_id from ib_client_accounts;
        perform log_action_atx(v_reference_id + 1 || '', 2, v_err_text || ' add_client_account ', 'ERROR');
        return false;
END ;
$$;

alter function add_client_account(integer, integer, integer, integer, varchar, bigint, varchar) owner to interhub_user;

