create function get_sessions(i_session_id character varying) returns SETOF ib_sessions
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
    v_condition varchar := '';
BEGIN

    return query SELECT t.*
                 FROM ib_sessions t
                 WHERE session_id = i_session_id
                   and created_date between now()::timestamp - INTERVAL '15 min' and now();

exception
    when others then
        perform log_action_atx(v_condition || '', 2, 'Данный не нфйден ид : get_sessions' || v_condition, 'OK');
END;
$$;

alter function get_sessions(varchar) owner to interhub_user;

