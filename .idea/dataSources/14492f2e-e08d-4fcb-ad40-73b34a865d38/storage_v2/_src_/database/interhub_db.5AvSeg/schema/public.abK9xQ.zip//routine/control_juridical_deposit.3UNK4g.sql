create function control_juridical_deposit(i_from_account_id integer, i_to_account_id integer, i_amount numeric, i_user_id integer, i_group_id bigint, i_lead_id character varying DEFAULT NULL::character varying, i_descreption character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
    v_object_id constant integer := 2;
    v_client_id          integer; 
   v_from_accounts   ib_Client_accounts%rowtype;
  v_role_id integer;
 v_state_id	integer;
  v_to_accounts		 ib_client_accounts%rowtype;
BEGIN 
	if i_from_account_id != 0  then 	
		select t.*  into v_from_accounts  from ib_client_accounts t
				where  t.id  = i_from_account_id  ;
	else 
			v_from_accounts.id =0;
	end if;
		if i_to_account_id != 0  then 
			  select t.*  into v_to_accounts  from ib_client_accounts t
				where  t.id  = i_to_account_id  ;
 		else 
			v_to_accounts.id= 0;
 		end if;
 	if v_from_accounts.id is  null or v_to_accounts.id is null then
 			raise 'accountlardan bittasi topilmadi ';
 	end if;
	/* select r.role_id into v_role_id from ib_users r where r.id  = i_user_id ;
		if not found then 
				raise 'userni role kiritilmagan yoki user topilmadi ';
		end if;*/
/*
	if v_role_id in (1,2) then 
		v_state_id := 6;
	else 
	 	v_state_id := 5;
	end if;
*/

insert into ib_jur_client_deposit (
	from_account_id,
	to_account_id,
	amount,
	state_id,
	created_by,
	group_id,
	lead_id,
	 descreption
	)
	values(v_from_accounts.id,
		v_to_accounts.id,
		i_amount,
		v_State_id,
		i_user_id,
		i_group_id,
		i_lead_id,
		i_descreption
		);
--	if v_state_id =6  then 
		return true;
--	end if;
return false; 
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_from_account_id || '', v_object_id, v_err_text || ' control_juridical_deposit ', 'ERROR');
        return false;
END;
$$;

alter function control_juridical_deposit(integer, integer, numeric, integer, bigint, varchar, varchar) owner to interhub_user;

