create function write_log_transaction(i_agent_id integer, i_client_account character varying, i_gateway_merchant_id integer, i_transact_date timestamp without time zone, i_gateway_transact_id character varying, i_params character varying, i_transact_amount bigint, i_merchant_id integer, i_agent_transact_id character varying) returns void
    security definer
    language plpgsql
as
$$
DECLARE
    -- Change this to reflect the dblink connection string
    v_conn_str text := 'port=5432 dbname=bill_master_db host=localhost user=postgres password=post1910';
    v_query    text;
BEGIN
    v_query := 'SELECT true FROM write_log_transaction_atx ( ' || quote_nullable(i_agent_id) ||
               ',' || quote_nullable(i_client_account) || ',' || quote_nullable(i_gateway_merchant_id) ||
               ',' || quote_nullable(i_transact_date) || ',' || quote_nullable(i_gateway_transact_id) || ',' ||
               quote_nullable(i_params) ||
               ',' || quote_nullable(i_transact_amount) || ',' || quote_nullable(i_merchant_id) || ',' ||
               quote_nullable(i_agent_transact_id) || ' )';
    PERFORM * FROM dblink(v_conn_str, v_query) AS p (ret boolean);
    -- you need to do something here to avoid ERROR:  unable to map dynamic shared memory segment
exception
    when others then
        perform log_action_atx(i_agent_id || '', 7, sqlerrm, 'ERROR');
END;
$$;

alter function write_log_transaction(integer, varchar, integer, timestamp, varchar, varchar, bigint, integer, varchar) owner to interhub_user;

