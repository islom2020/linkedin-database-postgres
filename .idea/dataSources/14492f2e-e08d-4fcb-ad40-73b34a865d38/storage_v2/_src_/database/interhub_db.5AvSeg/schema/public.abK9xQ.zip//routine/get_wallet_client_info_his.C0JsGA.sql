create function get_wallet_client_info_his(i_id integer DEFAULT NULL::integer, i_user_id integer DEFAULT NULL::integer, i_wallet_client_info_id integer DEFAULT NULL::integer, i_created_date_from character varying DEFAULT NULL::character varying, i_created_date_to character varying DEFAULT NULL::character varying) returns SETOF ib_wallet_client_info_his
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
    v_condition varchar := '';
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;

    if i_user_id is not null then
        v_condition := v_condition || ' and t.user_id = ' || i_user_id;
    end if;
 
    if i_wallet_client_info_id is not null then
        v_condition := v_condition || ' and  t.wallet_client_info_id= ' || i_wallet_client_info_id ;
    end if;
   
 if i_created_date_from  is not null then
        v_condition := v_condition ||
                       ' and  t.created_date   >= to_date( ''' ||
                       i_created_date_from || ''', ''dd.mm.yyyy'')';
    end if;


   if i_created_date_to is not null then
        v_condition := v_condition ||
                       ' and  t.created_date  <= to_date( ''' ||
                       i_created_date_to || ''', ''dd.mm.yyyy'')';
    end if;

   
    RETURN QUERY
        execute 'SELECT * FROM ib_wallet_client_info_his t  WHERE  1= 1 ' || v_condition;
    IF NOT FOUND THEN
        perform log_action_atx(v_condition, 5, '    get_wallet_client_info_his ' || v_condition, 'ERROR');
    END IF;
END ;
$$;

alter function get_wallet_client_info_his(integer, integer, integer, varchar, varchar) owner to interhub_user;

