create function get_wallet_client_info_count(i_date character varying DEFAULT NULL::character varying)
    returns TABLE(accessed integer, blocked integer, proffesional integer, main integer)
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;  
    v_object_id constant integer := 5;
     v_condition varchar := '';
    v_accessed_count integer:=0 ;
   v_blocked_count integer:=0 ;
  v_prof_count integer :=0;
 v_main_count integer :=0;
    begin 
       select count(*) into v_accessed_count from ib_v_wallet_client_info t where 
    to_Date( t.created_date , 'yyyy-mm-dd')  = to_date(i_date, 'dd.mm.yyyy');
  
       select count(*) into v_blocked_count from ib_v_wallet_client_info t where t.state_id  =3 and 
    to_Date( t.modified_date , 'yyyy-mm-dd')  = to_date(i_date, 'dd.mm.yyyy');
  
       select count(*) into v_prof_count from ib_v_wallet_client_info t where t.client_wallet_type  = 3  and 
    to_Date( t.modified_date , 'yyyy-mm-dd')   = to_date(i_date, 'dd.mm.yyyy');
  
       select count(*) into v_main_count from ib_v_wallet_client_info t where t.client_wallet_type  = 2  and 
    to_Date( t.modified_date , 'yyyy-mm-dd')  = to_date(i_date, 'dd.mm.yyyy');
  
       return  query select v_accessed_count as accessed, v_blocked_count as blocked ,v_prof_count  as proffesional,v_main_count as main ;
  exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(v_condition, v_object_id, v_err_text || 'get_client_jur_info', 'ERROR');
        
END;
$$;

alter function get_wallet_client_info_count(varchar) owner to interhub_user;

