create function get_gateway_merch_fields(i_id integer DEFAULT NULL::integer, i_code character varying DEFAULT NULL::character varying, i_gateway_merch_id integer DEFAULT NULL::integer) returns SETOF ib_gateway_merchant_fields
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    rec         RECORD;
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
    if i_code is not null then
        v_condition := v_condition || ' and  t.code = ' || i_code;
    end if;
    if i_gateway_merch_id is not null then
        v_condition := v_condition || ' and t.merchant_id = ' || i_gateway_merch_id;
    end if;

    return query execute 'select t.* 
                            FROM ib_gateway_merch_fields t,  ib_gateway_merchants m
                        where t.gateway_merch_id  = m.id  and  1=1 ' || v_condition;

    IF NOT FOUND THEN
        perform log_action_atx(v_condition, 3, 'Данный не нaйден ид :' || 1, 'OK');
    END IF;
END;
$$;

alter function get_gateway_merch_fields(integer, varchar, integer) owner to interhub_user;

