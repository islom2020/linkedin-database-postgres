create function get_merchants_page(i_page integer DEFAULT 1, i_page_count integer DEFAULT 20, i_id integer DEFAULT NULL::integer, i_name character varying DEFAULT NULL::character varying, i_category_id integer DEFAULT NULL::integer, i_currency_id integer DEFAULT NULL::integer, i_gateway_id integer DEFAULT NULL::integer, i_gateway_merchant_id integer DEFAULT NULL::integer, i_state_id integer DEFAULT NULL::integer, i_ordered_by character varying DEFAULT NULL::character varying, i_is_desc character varying DEFAULT NULL::character varying)
    returns TABLE(id integer, name character varying, gateway_merchant_id integer, category_id integer, min_amount bigint, max_amount bigint, currency_id integer, state_id integer, info character varying, count integer)
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
	v_gateway_merchants varchar='';
   v_condition varchar := '';
     r record;
v_merchant_count integer;
BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
   
     if i_gateway_id is not null then
		 begin    for r in (	select t.id  from ib_gateway_merchants t  where t.gateway_id  = i_gateway_id )
		    loop 
		    		v_gateway_merchants := v_gateway_merchants|| r.id ||' ,';
		    end loop;
		 
		   v_gateway_merchants :=  substr(v_gateway_merchants,  1,  (length(v_gateway_merchants)-1)); 
		  
        v_condition := v_condition || ' and t.gateway_merchant_id  in ( ' || v_gateway_merchants || ' ) ';
       exception when others then 
			return query execute ' SELECT  t.* FROM ib_merchants  t
      WHERE   1= 1 ' ||
                         ' order by 1 desc limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count ;
		  end;
    end if;
   if i_ordered_by is   null then
          i_ordered_by := '1';
     end if;
	  if i_is_desc  ='Y' then
          i_ordered_by := i_ordered_by || ' desc ';
      end if;
    if i_gateway_merchant_id is not null then
        v_condition := v_condition || ' and t.gateway_merchant_id  = ' || i_currency_id ;
    end if;
     if i_category_id is not null then
        v_condition := v_condition || ' and t.category_id  = ' || i_category_id ;
    end if;
     if i_state_id is not null then
        v_condition := v_condition || ' and t.state_id  = ' || i_state_id ;
    end if;
    if i_currency_id is not null then
        v_condition := v_condition || ' and t.currency_id = ' || i_currency_id ;
    end if;
    if i_name is not null then
        v_condition := v_condition || 'and lower(t.name) like ''%' || lower(i_name) || '%' || '''';
    end if;
       EXECUTE 'select  count(*)  from ib_merchants t where 1=1 ' || v_condition into v_merchant_count;

    return query execute ' SELECT id  ,
name,
gateway_merchant_id ,
category_id ,
min_amount,
max_amount,
currency_id ,state_id ,info  , '||v_merchant_count ||   ' as count  FROM ib_merchants  t
      WHERE   1= 1 ' || v_condition ||
                         ' order by  '||i_ordered_by||'     limit ' || i_page_count || '  offset   ' || ((i_page - 1)) * i_page_count;

    IF NOT FOUND THEN
        perform log_action_atx(v_condition || '', 2, 'Данный не нфйден ид :' || v_condition, 'OK');
    END IF;
END;
$$;

alter function get_merchants_page(integer, integer, integer, varchar, integer, integer, integer, integer, integer, varchar, varchar) owner to interhub_user;

