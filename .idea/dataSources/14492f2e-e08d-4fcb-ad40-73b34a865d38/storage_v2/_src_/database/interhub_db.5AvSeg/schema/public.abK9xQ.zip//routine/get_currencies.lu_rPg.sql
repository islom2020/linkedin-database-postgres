create function get_currencies(i_id integer DEFAULT NULL::integer, i_currency_code character varying DEFAULT NULL::character varying) returns SETOF ib_currencies
    language plpgsql
as
$$
DECLARE
    v_condition varchar := '';
    v_date      date    := now();
BEGIN
    if i_currency_code is not null then
        v_condition := ' and c.currency_code = ''' || i_currency_code || '''';
    end if;
    if i_id is not null then
        v_condition := ' and c.id = ' || i_id ;
    end if;
    return query execute ' SELECT  c.*
            FROM   ib_currencies c
      WHERE  1 = 1 ' || v_condition;

END;
$$;

alter function get_currencies(integer, varchar) owner to interhub_user;

