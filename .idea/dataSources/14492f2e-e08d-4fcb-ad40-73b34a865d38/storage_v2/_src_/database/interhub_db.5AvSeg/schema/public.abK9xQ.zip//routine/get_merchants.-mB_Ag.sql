create function get_merchants(i_id integer DEFAULT NULL::integer, i_name character varying DEFAULT NULL::character varying, i_category_id integer DEFAULT NULL::integer, i_currency_id integer DEFAULT NULL::integer, i_gateway_id integer DEFAULT NULL::integer, i_gateway_merchant_id integer DEFAULT NULL::integer, i_state_id integer DEFAULT NULL::integer) returns SETOF ib_merchants
    language plpgsql
as
$$
DECLARE
    rec         RECORD;
	v_gateway_merchants varchar='';
   v_condition varchar := '';
     r record;

BEGIN
    if i_id is not null then
        v_condition := v_condition || ' and t.id = ' || i_id;
    end if;
   
     if i_gateway_id is not null then
		 begin    for r in (	select t.id  from ib_gateway_merchants t  where t.gateway_id  = i_gateway_id )
		    loop 
		    		v_gateway_merchants := v_gateway_merchants|| r.id ||' ,';
		    end loop;
		 
		   v_gateway_merchants :=  substr(v_gateway_merchants,  1,  (length(v_gateway_merchants)-1)); 
		  
        v_condition := v_condition || ' and t.gateway_merchant_id  in ( ' || v_gateway_merchants || ' ) ';
       exception when others then 
			return query execute ' SELECT  t.* FROM ib_merchants  t
      WHERE   1= 1 '  ;
		  end;
    end if;
   
    if i_gateway_merchant_id is not null then
        v_condition := v_condition || ' and t.gateway_merchant_id  = ' || i_currency_id ;
    end if;
   if i_state_id is not null then
        v_condition := v_condition || ' and t.state_id  = ' || i_state_id ;
    end if;
    if i_currency_id is not null then
        v_condition := v_condition || ' and t.currency_id = ' || i_currency_id ;
    end if;
    if i_name is not null then
        v_condition := v_condition || 'and lower(t.name) like ''%' || lower(i_name) || '%' || '''';
    end if;
    return query execute ' SELECT  t.* FROM ib_merchants  t
      WHERE   1= 1 ' || v_condition;

    IF NOT FOUND THEN
        perform log_action_atx(v_condition || '', 2, 'Данный не нфйден ид :' || v_condition, 'OK');
    END IF;
END;
$$;

alter function get_merchants(integer, varchar, integer, integer, integer, integer, integer) owner to interhub_user;

