create function cancel_trans_proveden() returns integer
    language plpgsql
as
$$
DECLARE
    v_id                  integer;
    r                     record;
    v_gateway_currency_id integer;
    v_agents              ib_agents%rowtype;
    v_client_id           integer;
begin

    for r in (select t.*
              from ib_transacts t
              where t.state_id in ( 5 ,4)
                and t.id in (1600346791343))
        loop
            select c.client_id, t.currency_id
            into v_client_id, v_gateway_currency_id
            from ib_gateway_merchants t,
                 ib_gateways c
            where t.id = r.gateway_merchant_id
              and c.id = t.gateway_id;
            if not found then
                raise 'something is err';
            end if;
            select t.* into v_agents from ib_agents t where id = r.agent_id;
            if not found then
                raise 'something is err111';
            end if;
            select *
            from
                take_deposit_back(i_client_id => v_agents.client_id,
                                  i_cr_amount =>r.transact_amount,
                                  i_client_type_id => 2,
                                  i_currency_id=>v_agents.currency_id,
                                  i_group_id =>r.id)
            into v_id;
            if v_id = -1 then
                raise 'take deposit';
            end if;
            update ib_transacts c set state_id = 7 where c.id = r.id;
        end loop;

    return v_id;
exception
    when others then
        perform log_action_atx(22 || '', 1, sqlerrm, 'ERROR');
        return -1;
END;
$$;

alter function cancel_trans_proveden() owner to interhub_user;

