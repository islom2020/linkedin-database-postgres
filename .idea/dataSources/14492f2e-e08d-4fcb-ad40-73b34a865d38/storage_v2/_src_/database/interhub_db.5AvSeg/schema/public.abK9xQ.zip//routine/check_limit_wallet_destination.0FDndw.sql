create function check_limit_wallet_destination(i_wallet character varying, i_transact_amount numeric) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
   v_object_id			integer := 5;
   v_wallet ib_wallets%rowtype;
   v_wallet_type  ib_wallet_types%rowtype;
  v_sum_month 		numeric;
 v_balance  numeric;
begin
	select t.* into  v_wallet  from ib_wallets t where 
			t.phone_number  = i_wallet and state_id  = 2;
		if not found then 
			raise 'wallet not found or blocked';
		end if;
	select t.balance into v_balance from ib_client_accounts t where t.client_id  = v_wallet.client_id  
			and t.currency_id  =  v_wallet.currency_id and t.account_type_id =  5 
			and t.client_type_id =  5 ;
		if not found then 
			raise ' client account is not found ' ;
		end if;
		
	select t.*  into v_wallet_type  from ib_wallet_types t , ib_clients c 
				where t.id  =  c.client_wallet_type and c.id =  v_wallet.client_id;
			if not found then 
			 raise 'wallet type not found';
			end if;
	 
		if (v_balance + i_transact_amount) >  v_wallet_type.max_amount then 
				raise 'max amount should be ';
		end if;
		
		/* if i_transact_amount >   v_wallet_type.pay_by_one_limit then 
		 		raise 'limit is larger';
		 end if;*/
		 
/*
		select  sum (t.transact_amount )  into v_sum_month  from ib_wallet_transacts t where 
				t."source" = v_wallet.phone_number and t.state_id  = 6 and
				t.created_date  between  date_trunc('month', current_date)  and now()  ; 
			v_Sum_month := v_Sum_month +  i_transact_amount; 
		if  v_Sum_month > v_wallet_type.month_limit then 
			raise 'month limit is larger ';
		end if;*/
			
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_wallet, v_object_id, v_err_text ||'check_limit_wallet', 'ERROR');
        return false;
END;
$$;

alter function check_limit_wallet_destination(varchar, numeric) owner to interhub_user;

