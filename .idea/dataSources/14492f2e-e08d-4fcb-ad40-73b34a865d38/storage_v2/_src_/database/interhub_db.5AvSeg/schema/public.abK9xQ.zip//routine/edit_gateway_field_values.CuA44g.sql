create function edit_gateway_field_values(i_id integer, i_title character varying DEFAULT NULL::character varying, i_field_id integer DEFAULT NULL::integer, i_service_field_value_id integer DEFAULT NULL::integer, i_gateway_value_ids character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id       integer;
    v_err_text           varchar;
    v_created_by         integer := 1;
    v_object_id constant integer := 2;
   v_title varchar ;
  v_gateway_value_ids varchar;
   v_field_id integer ;
 v_service_field_value_id integer;
    v_name               varchar(300);
BEGIN
    select   title, field_id ,  service_field_value_id,   gateway_value_ids
    into
         v_title, v_field_id,   v_service_field_value_id,  v_gateway_value_ids
    from ib_gateway_field_values
    where id = i_id;
    if not found then
        v_err_text := 'takaya id ne nayden ';
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
    end if;

    if i_title is null then
        i_title := v_title;
    end if;
       if i_gateway_value_ids is null then
        i_gateway_value_ids := v_gateway_value_ids;
    end if;
 	if i_field_id is null then
        i_field_id := v_field_id;
    end if; 
    if i_service_field_value_id is null then
        i_service_field_value_id := v_service_field_value_id;
    end if;
   
    update ib_gateway_field_values
    set  title = i_title,
    field_id=  i_field_id,
    service_field_value_id= i_service_field_value_id,
    gateway_value_ids =  i_gateway_value_ids
    where id = i_id;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', v_object_id, v_err_text, 'ERROR');
        return false;
END;
$$;

alter function edit_gateway_field_values(integer, varchar, integer, integer, varchar) owner to interhub_user;

