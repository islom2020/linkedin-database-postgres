create function cancel_trans_uspeshni() returns integer
    language plpgsql
as
$$
DECLARE 
v_id integer;
r               record;
v_gateway_currency_id  integer;
    v_agents             ib_agents%rowtype;
  v_client_id  integer;
 v_res integer;
 v_agent_merchants ib_Agent_merchant%rowtype;
begin
	
	for r in (select
						t.*
					from
						ib_transacts t
					where t.state_id in (4,5 ) and 
						  t.id  in (1600407446685))
	 loop
	 select c.client_id , t.currency_id into v_client_id, v_gateway_currency_id from ib_gateway_merchants t ,  ib_gateways c 
       		where t.id = r.gateway_merchant_id and c.id = t.gateway_id;
       	if not found then 
       	raise 'something is err';
       	end if;
        begin
	         
	        select t.*
	        into v_agent_merchants
	        from ib_agent_merchant t
	        where agent_id = r.agent_id
	          and merchant_id = r.merchant_id;
	    exception
	        when others then
	            perform log_action_atx(r.id || '', 7, sqlerrm, 'ERROR');
	            return -1;
	    end;
       
       	select t.* into v_agents from ib_agents t where id = r.agent_id;
       	 if not found then 
       		raise 'something is err111';
       	end if;
        select return_deposit(i_client_id => v_client_id,
                              i_cr_amount =>  r.transact_amount,
                              i_client_type_id => 3,
                              i_currency_id => v_gateway_currency_id,
                              i_group_id => r.id,
                               i_from_currency_id =>  v_agent_merchants.currency_id,
                              i_commission_amount => r.commission_amount)
       /*
		 select reverse_deposit(i_from_client_id => v_client_id, 
        						i_to_client_id =>  v_Agents.client_id,
        					   i_dr_amount => r.transact_amount,
                               i_from_client_type_id => 3,
                               i_to_client_type_id => 2,
                               i_currency_id =>v_agent_merchants.currency_id,
                               i_group_id => r.id,
                               i_from_currency_id =>  v_gateway_currency_id,
                               i_commission_amount => r.commission_amount)*/
        into v_res;
        if v_res = -1 then
            return
                false;
        end if; 
			update ib_transacts set state_id  = 6 where id =  r.id ;
	 end loop;
	return v_id;
	exception when others then 
			perform log_action_atx(22 || '', 1, sqlerrm, 'ERROR');
        return -1;
	END;
$$;

alter function cancel_trans_uspeshni() owner to interhub_user;

