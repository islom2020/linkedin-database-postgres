create view ib_v_operation_list
            (group_id, debit_amount, source_currency_id, credit_amount, destination_currency_id, comission_amount,
             source_client_name, source_client_id, destination_client_name, destination_client_id, credit_account,
             debit_account, deposit_date, transact_type, count)
as
SELECT t.group_id,
       max(a.transact_amount)            AS debit_amount,
       max(ag.currency_id)               AS source_currency_id,
       max(a.amount_in_currency)         AS credit_amount,
       max(g.currency_id)                AS destination_currency_id,
       max(a.commission_amount)          AS comission_amount,
       (SELECT cl.client_name
        FROM ib_clients cl
        WHERE cl.id = max(ag.client_id)) AS source_client_name,
       max(ag.client_id)                 AS source_client_id,
       (SELECT cl.client_name
        FROM ib_clients cl
        WHERE cl.id = max(g.client_id))  AS destination_client_name,
       max(g.client_id)                  AS destination_client_id,
       (SELECT f.client_account
        FROM ib_client_accounts f,
             ib_client_deposit r
        WHERE f.id = r.account_id
          AND r.credit_amount = max(t.credit_amount)
          AND r.group_id = t.group_id)   AS credit_account,
       (SELECT f.client_account
        FROM ib_client_accounts f,
             ib_client_deposit r
        WHERE f.id = r.account_id
          AND r.debit_amount = max(t.debit_amount)
          AND r.group_id = t.group_id)   AS debit_account,
       max(t.deposit_date)               AS deposit_date,
       'P'::text                         AS transact_type,
       1                                 AS count
FROM ib_client_deposit t,
     ib_client_accounts c,
     ib_transacts a,
     ib_agents ag,
     ib_gateway_merchants m,
     ib_gateways g
WHERE a.id = t.group_id
  AND c.id = t.account_id
  AND a.gateway_merchant_id = m.id
  AND a.agent_id = ag.id
  AND g.id = m.gateway_id
GROUP BY t.group_id;

alter table ib_v_operation_list
    owner to interhub_user;

