create function edit_merchant(i_id integer, i_name character varying DEFAULT NULL::character varying, i_gateway_merchant_id integer DEFAULT NULL::integer, i_category_id integer DEFAULT NULL::integer, i_min_amount bigint DEFAULT NULL::bigint, i_max_amount bigint DEFAULT NULL::bigint, i_currency_id integer DEFAULT NULL::integer, i_state_id integer DEFAULT NULL::integer, i_info character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_err_text            varchar;
    v_object_id constant  integer := 1;
    v_name                character varying;
    v_gateway_merchant_id integer ;
    v_category_id         integer ;
    v_min_amount          bigint ;
    v_max_amount          bigint ;
   v_currency_id		integer;
 v_state_id  integer;
v_info   varchar ;

BEGIN
    select name,
           gateway_merchant_id,
           category_id,
           min_amount,
           max_amount,
           currency_id ,
           state_id ,
           info 
    into
        v_name ,
        v_gateway_merchant_id ,
        v_category_id ,
        v_min_amount ,
        v_max_amount,
        v_currency_id,
		 v_state_id  ,
 		v_info
    from ib_merchants
    where id = i_id;
    if not found then
        v_err_text := 'takaya merchant ne nayden ';
        perform log_action_atx(i_id, v_object_id, v_err_text, 'ERROR');
        return false;
    end if;
    if i_name is null then
        i_name := v_name;
    end if;
    if i_currency_id is null then
        i_currency_id := v_currency_id;
    end if;
    if i_info is null then
        i_info := v_info;
    end if;
   
    if i_gateway_merchant_id is null then	
        i_gateway_merchant_id := v_gateway_merchant_id;
    else 
	    update ib_merchant_fields   set gateway_merch_id  =   i_gateway_merchant_id where service_id  =  i_id ;
    end if;
    if i_min_amount is null then
        i_min_amount := v_min_amount;
    end if;
    if i_category_id is null then
        i_category_id := v_category_id;
    end if;
    if i_max_amount is null then
        i_max_amount := v_max_amount;
    end if;

   if i_state_id is null then
        i_state_id := v_state_id;
    end if;
    update ib_merchants
    set name                = i_name,
        gateway_merchant_id = i_gateway_merchant_id,
        min_amount          = i_min_amount,
        category_id         = i_category_id,
        max_amount          = i_max_amount,
        currency_id 		= i_currency_id,
        state_id		= i_state_id,
        info 	= i_info
    where id = i_id;
    return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id||'', v_object_id, v_err_text || ' edit_merchant', 'ERROR');
        return false;
END;
$$;

alter function edit_merchant(integer, varchar, integer, integer, bigint, bigint, integer, integer, varchar) owner to interhub_user;

