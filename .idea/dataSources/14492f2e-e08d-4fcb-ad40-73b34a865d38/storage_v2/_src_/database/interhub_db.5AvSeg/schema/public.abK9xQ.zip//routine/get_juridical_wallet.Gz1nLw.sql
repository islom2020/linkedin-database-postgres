create function get_juridical_wallet(i_id integer DEFAULT NULL::integer, i_client_id integer DEFAULT NULL::integer, i_token character varying DEFAULT NULL::character varying, i_type character varying DEFAULT NULL::character varying) returns SETOF ib_v_juridical_wallet
    language plpgsql
as
$$
DECLARE
    v_err_text           varchar;
      v_condition     varchar := '';
begin
	
	
	  if i_client_id is not null then
        v_condition := v_condition || ' and t.client_id = ' || i_client_id;
     end if;
    if i_type is not null then
        v_condition := v_condition || ' and t.type  = ''' || i_type || '''';
    end if;
     if i_token is not null then
        v_condition := v_condition || ' and t.token  = ''' || i_token || '''';
    end if;
    if i_id is not null then
        v_condition := v_condition || ' and t.id  = ''' || i_id || '''';
    end if;
     RETURN QUERY
        execute 'SELECT * FROM ib_v_juridical_wallet t  WHERE  1= 1 ' || v_condition;
	exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_client_id || '' , 5,
                               v_err_text || 'add_wallets',
                               'ERROR');
       
END;
$$;

alter function get_juridical_wallet(integer, integer, varchar, varchar) owner to interhub_user;

