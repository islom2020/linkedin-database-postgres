create function get_currency_dump(i_currency_code character varying) returns SETOF ib_currencies_dump
    language plpgsql
as
$$
DECLARE
BEGIN
    return query SELECT t.*
                 from public.ib_currencies t
                 where t.currency_code = i_currency_code;
exception
    when others then
        perform log_action_atx(i_currency_code, 1, 'Данный не нфйден ид :' || i_currency_code, 'ERROR');

END;
$$;

alter function get_currency_dump(varchar) owner to interhub_user;

