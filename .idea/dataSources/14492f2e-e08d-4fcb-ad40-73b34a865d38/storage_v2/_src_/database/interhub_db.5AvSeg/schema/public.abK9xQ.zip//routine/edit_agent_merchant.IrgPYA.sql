create function edit_agent_merchant(i_id integer, i_agent_id integer DEFAULT NULL::integer, i_merchant_id integer DEFAULT NULL::integer, i_commission_down numeric DEFAULT NULL::numeric, i_commission_to_agent numeric DEFAULT NULL::numeric, i_commission_from_agent numeric DEFAULT NULL::numeric, i_currency_id integer DEFAULT NULL::integer, i_min_amount numeric DEFAULT NULL::numeric, i_max_amount numeric DEFAULT NULL::numeric, i_state_id integer DEFAULT NULL::integer, i_is_main character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_reference_id          integer;
    v_err_text              varchar;
    v_currency_id         integer;
    v_created_by            integer := 1;
    v_object_id constant    integer := 2;
    v_agent_id              integer;
    v_merchant_id           integer;
    v_commission_down       numeric(10, 2);
    v_commission_to_agent         numeric(10, 2);
    v_commission_from_agent numeric(5, 2);
   v_min_amount numeric ;
  v_max_amount numeric ;
 v_is_main  varchar ;
 v_state_id  integer;
BEGIN
    select agent_id, merchant_id, commission_down, commission_to_agent, currency_id,  min_amount, max_amount , state_id,  is_main 
    into
        v_agent_id , v_merchant_id, v_commission_down, v_commission_to_agent, v_currency_id,v_min_amount,v_max_amount, v_state_id,v_is_main 
    from ib_agent_merchant
    where id = i_id;
    if not found then
        v_err_text := 'takaya id ne nayden ';
        perform log_action_atx(i_id, v_object_id, v_err_text, 'ERROR');
        return false;
    end if;
    if i_agent_id is null then
        i_agent_id := v_agent_id;
    end if;
    if i_currency_id is null then
        i_currency_id := v_currency_id;
    end if;
       if i_is_main is null then
        i_is_main := v_is_main;
    end if;
     if i_min_amount is null then
        i_min_amount := v_min_amount;
    end if;
     if i_max_amount is null then
        i_max_amount := v_max_amount;
    end if;
    if i_merchant_id is null then
        i_merchant_id := v_merchant_id;
    end if;
    if i_commission_down is null then
        i_commission_down := v_commission_down;
    end if;
    if i_commission_to_agent is null then
        i_commission_to_agent := v_commission_to_agent;
    end if;
     if i_state_id is null then
        i_state_id := v_state_id;
    end if;
    if i_commission_from_agent is null then
        i_commission_from_agent := v_commission_from_agent;
    end if;
    update ib_agent_merchant
    set agent_id              = i_agent_id,
        merchant_id           = i_merchant_id,
        commission_to_agent         = i_commission_to_agent,
        commission_down       = i_commission_down,
        commission_from_agent = i_commission_from_agent, 
        min_amount = i_min_amount ,
        max_amount = i_max_amount,
        state_id = i_state_id,
        is_main = i_is_main 
    where id = i_id;
     return true;
exception
    when others THEN
        v_err_text := sqlerrm;
        perform log_action_atx(i_id || '', v_object_id, v_err_text ||' edit_agent_merchant', 'ERROR');
       return false ;
      
END;
$$;

alter function edit_agent_merchant(integer, integer, integer, numeric, numeric, numeric, integer, numeric, numeric, integer, varchar) owner to interhub_user;

