create function add_or_edit_reaction_b2(i_post_id character varying, i_user_id character varying, i_reaction_type integer) returns integer
    language plpgsql
as
$$
declare
        v_reaction_type integer := null;
begin
--         select reaction_type into v_reaction_type from user_reaction
--             ur where ur.user_id = i_user_id::uuid and  ur.post_id = i_post_id::uuid;
-- 
--         if v_reaction_type = i_reaction_type then
--             delete from user_reaction ur where ur.user_id = i_user_id::uuid and  ur.post_id = i_post_id::uuid;
--             return -1;
--         end if;

--         if v_reaction_type is null then
            insert into user_reaction(user_id, post_id, reaction_type) values
            (i_user_id::uuid, i_post_id::uuid, i_reaction_type);
            return i_reaction_type;
--         end if;

--         update user_reaction ur set reaction_type = i_reaction_type
--         where ur.user_id = i_user_id::uuid and  ur.post_id = i_post_id::uuid;
--         return i_reaction_type;

end;
$$;

alter function add_or_edit_reaction_b2(varchar, varchar, integer) owner to postgres;

