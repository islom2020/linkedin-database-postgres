create function add_user_trigger() returns trigger
    language plpgsql
as
$$
begin
    insert into log(error_text) values (NEW.first_name || ' ismli user bazaga qoshildi');
    return NEW;
end
$$;

alter function add_user_trigger() owner to postgres;

