create function get_post_reaction_json(i_post_id character varying) returns SETOF json
    language plpgsql
as
$$
begin
    return query select json_agg(
                                json_build_object(
                                        'user_id', u.id,
                                        'user_name', u.first_name,
                                        'user_avatar', ac.content,
                                        'i_about', u.about,
                                        'reaction_type', ur.reaction_type
                                    )
                            )
                 from user_reaction ur
                          inner join "user" u on ur.user_id = u.id
                          left join attachment a on u.avatar = a.id
                          left join attachment_content ac on ac.id = a.attachment_c_id
                 where ur.post_id = i_post_id::uuid;
end;
$$;

alter function get_post_reaction_json(varchar) owner to postgres;

