create function get_user_by_id(i_id uuid) returns SETOF "user"
    language plpgsql
as
$$
begin
    return query select * from "user" where id = i_id;
end;

$$;

alter function get_user_by_id(uuid) owner to postgres;

