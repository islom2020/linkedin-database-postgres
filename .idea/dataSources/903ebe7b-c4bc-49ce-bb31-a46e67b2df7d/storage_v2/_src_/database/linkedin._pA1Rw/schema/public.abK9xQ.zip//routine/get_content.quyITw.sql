create function get_content(i_attachment_id uuid) returns SETOF json
    language plpgsql
as
$$
begin
        return query select content from attachment_content
        where id = i_attachment_id;
    end;
$$;

alter function get_content(uuid) owner to postgres;

