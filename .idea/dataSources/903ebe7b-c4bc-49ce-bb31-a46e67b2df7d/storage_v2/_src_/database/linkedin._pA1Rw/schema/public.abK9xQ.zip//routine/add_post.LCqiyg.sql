create function add_post(i_title character varying, i_user_id character varying, i_attachments character varying) returns character varying
    language plpgsql
as
$$
declare
    v_user_id       uuid              := i_user_id::uuid;
    v_json_list     json              := i_attachments::json;
    v_json          json              := null;
    v_content       character varying := null;
    v_content_name  character varying := null;
    v_content_type  character varying := null;
    v_content_size  bigint            := null;
    v_attachment_id uuid              := null;
    v_post_id       uuid              := null;
    v_counter       integer           := 0;


begin

    raise notice '%', i_attachments;
    insert into post(title, user_id) VALUES (i_title, v_user_id) returning id into v_post_id;
    loop
        select v_json_list -> v_counter into v_json;
        exit when v_json is null;
        select v_json ->> ('name')::character varying into v_content_name;
        select v_json ->> ('content_type')::character varying into v_content_type;
        select (v_json ->> 'size')::bigint into v_content_size;
        select (v_json ->> 'content') into v_content;

        select add_attachment(
                       i_name := v_content_name,
                       i_content_type := v_content_type,
                       i_content := v_content, i_size := v_content_size
                   )
        into v_attachment_id;
        insert into post_attachment(post_id, attachment_id) VALUES (v_post_id, v_attachment_id);

        v_counter := v_counter + 1;
    end loop;

    return i_attachments;
end
$$;

alter function add_post(varchar, varchar, varchar) owner to postgres;

