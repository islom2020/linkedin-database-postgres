create function edit_user(i_id uuid, i_firstname character varying DEFAULT NULL::character varying, i_lastname character varying DEFAULT NULL::character varying, i_birthdate character varying DEFAULT NULL::character varying, i_region_id uuid DEFAULT NULL::uuid, i_avatar_id uuid DEFAULT NULL::uuid, i_password character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
declare
    v_firstname character varying := null;
    v_lastname character varying := null;
    v_birthdate character varying := null;
    v_region_id uuid := null;
    v_avatar_id uuid := null;
begin
    select first_name,last_name,birth_date,region_id,avatar
        into v_firstname,v_lastname,v_birthdate,v_region_id,v_avatar_id from "user" where id = i_id;

    if i_firstname is null then
        i_firstname := v_firstname;
        end if;
    if i_lastname is null then
        i_lastname := v_lastname;
        end if;
    if i_birthdate is null then
        i_birthdate := v_birthdate;
        end if;
    if i_region_id is null then
        i_region_id := v_region_id;
    end if;
    if i_avatar_id is null then
        i_avatar_id := v_avatar_id;
    end if;

    update  "user" set first_name = i_firstname, last_name = i_lastname, birth_date = to_date(i_birthdate,'yyyy-mm-dd'),
                    region_id = i_region_id, avatar = i_avatar_id where id = i_id;

    return true;
    exception when others then
    perform add_log('Error not found user');
    return false;

end;
$$;

alter function edit_user(uuid, varchar, varchar, varchar, uuid, uuid, varchar) owner to postgres;

