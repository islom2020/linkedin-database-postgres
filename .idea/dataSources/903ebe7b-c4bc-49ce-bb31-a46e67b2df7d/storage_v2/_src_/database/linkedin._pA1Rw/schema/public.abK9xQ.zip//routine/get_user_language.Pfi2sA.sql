create function get_user_language(i_user_id uuid) returns json
    language plpgsql
as
$$
declare
    v_result json;

begin

    select json_agg(json_build_object(
            'name', la.name ))
    into v_result from language la
                           inner join user_language ula
                                      on la.id = ula.language_id
    where ula.user_id = i_user_id;


    return v_result;
end
$$;

alter function get_user_language(uuid) owner to postgres;

