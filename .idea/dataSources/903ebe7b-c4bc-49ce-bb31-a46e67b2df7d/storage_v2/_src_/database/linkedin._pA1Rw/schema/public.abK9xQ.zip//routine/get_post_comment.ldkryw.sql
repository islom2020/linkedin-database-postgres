create function get_post_comment(i_post_id character varying) returns SETOF user_comment
    language plpgsql
as
$$
begin
        return query select * from user_comment where post_id = i_post_id;
    end;
$$;

alter function get_post_comment(varchar) owner to postgres;

