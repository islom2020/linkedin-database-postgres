create function update2_user_trigger_b2() returns trigger
    language plpgsql
as
$$
begin
        insert into log(error_text) values (row_to_json(old) || ' dan ' || row_to_json(old) || ' ga o''zgardi');
        return NEW;
end;

$$;

alter function update2_user_trigger_b2() owner to postgres;

