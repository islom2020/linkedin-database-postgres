create function get_post_reaction(i_post_id character varying)
    returns TABLE(user_id uuid, full_name character varying, i_about character varying, i_avatar bytea, i_reaction_type integer)
    language plpgsql
as
$$
declare
    v_post_id       uuid    := i_post_id::uuid;
    v_reaction_type integer := null;

begin
        return query select
                            u.id, u.first_name,
                            u.about, ac.content, ur.reaction_type
                            from post as p
    inner join user_reaction as ur on ur.post_id = p.id
    inner join "user" as u on ur.user_id = u.id
    left join attachment a on u.avatar = a.id
    left join attachment_content ac on a.attachment_c_id = ac.id
        where v_post_id = p.id;
end;

$$;

alter function get_post_reaction(varchar) owner to postgres;

