create function update_user_trigger() returns trigger
    language plpgsql
as
$$
begin
    insert into log(error_text) values (OLD.first_name || 'ismli user ' || NEW.first_name || ' li ismga ozgardi');
    return NEW;
end
$$;

alter function update_user_trigger() owner to postgres;

