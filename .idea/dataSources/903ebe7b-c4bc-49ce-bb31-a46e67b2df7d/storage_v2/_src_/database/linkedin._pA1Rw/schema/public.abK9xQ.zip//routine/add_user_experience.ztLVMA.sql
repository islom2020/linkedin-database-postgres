create function add_user_experience(i_user_id uuid, i_experience_id uuid, i_start_date character varying DEFAULT NULL::character varying, i_position character varying DEFAULT NULL::character varying, i_end_date character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    v_expereince_id uuid;
    v_user_id       uuid;
BEGIN

    --         insert into user_experience(user_id, experience_id) values ()
--         insert  into experience( name, region_id, description, linkedin_url)
--         values (i_name,i_region_id,i_description,i_linkedIn_url);
    select id into v_user_id from "user" where i_user_id = id;
    select id into v_expereince_id from experience where i_experience_id = id;
    if v_user_id is null or v_expereince_id is null then
        return false;
    end if;
    insert into user_experience(user_id, experience_id, start_date, end_date, position) values (i_user_id, i_experience_id, to_date(i_start_date, 'yyyy/mm/dd'), to_date(i_end_date, 'yyyy/mm/dd'), i_position);
    return true;

exception
    when others then
        return false;
End;
$$;

alter function add_user_experience(uuid, uuid, varchar, varchar, varchar) owner to postgres;

