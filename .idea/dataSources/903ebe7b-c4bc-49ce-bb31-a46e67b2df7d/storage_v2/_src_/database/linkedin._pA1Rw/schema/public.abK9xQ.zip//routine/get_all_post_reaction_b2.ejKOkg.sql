create function get_all_post_reaction_b2(i_post_id character varying)
    returns TABLE(user_id uuid, full_name character varying, about character varying, avatar bytea, reaction_type integer)
    language plpgsql
as
$$
declare
    v_reaction_type integer := null;
begin
        return query select u.id ,u.first_name,u.about,ac.content, ur.reaction_type  from user_reaction ur
        inner join "user" u on ur.user_id = u.id
        left join attachment a on u.avatar = a.id
        left join attachment_content ac on a.attachment_c_id = ac.id where i_post_id::uuid = ur.post_id;

end
$$;

alter function get_all_post_reaction_b2(varchar) owner to postgres;

