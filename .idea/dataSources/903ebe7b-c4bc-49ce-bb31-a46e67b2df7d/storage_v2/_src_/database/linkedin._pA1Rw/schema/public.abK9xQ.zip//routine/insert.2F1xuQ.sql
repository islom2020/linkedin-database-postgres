create function insert() returns void
    language plpgsql
as
$$
declare
        v_user record := null;
        v_counter integer := 0;
begin


        loop
            exit when v_counter = 100;
        for v_user in select id from "user"
            loop
            insert into user_reaction(user_id, post_id, reaction_type) VALUES (v_user.id, 'fbf9978f-9638-457b-a008-c9075d4944a2',1);
            end loop;
        v_counter := v_counter + 1;
        end loop;


end;
$$;

alter function insert() owner to postgres;

