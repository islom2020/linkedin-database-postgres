create function get_user_post(i_user_id character varying) returns json
    language plpgsql
as
$$
declare
    v_result json;
begin

    select json_agg(json_build_object(
            'id', p.id,
            'title', p.title,
            'attachments', (select json_agg(json_build_object(
                    'name', at.name,
                    'content_type', at.content_type,
                    'size', at.size,
                    'attachment_id', at.id,
                    'content', atc.content,
                    'attachment_content_id', atc.id
                ))
                            from post_attachment pa
                                     inner join attachment at on at.id = pa.attachment_id
                                     inner join attachment_content atc on atc.id = at.attachment_c_id
                            where pa.post_id = p.id
                            order by p.created_date
            )))
    into v_result
    from post p
    where p.user_id = cast(i_user_id as uuid);

    return v_result;

end;
$$;

alter function get_user_post(varchar) owner to postgres;

