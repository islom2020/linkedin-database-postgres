create function add_attachment(i_content bytea, i_name character varying DEFAULT NULL::character varying, i_content_type character varying DEFAULT NULL::character varying, i_size bigint DEFAULT NULL::bigint) returns uuid
    language plpgsql
as
$$
declare
    v_attachment_content_id uuid;
    v_attachment_id         uuid;
begin
    if i_content is null then
        return null;
    end if;

    select add_attachment_content(i_content) into v_attachment_content_id;
    if not FOUND then
        return null;
    end if;

    insert into attachment(attachment_c_id, name, content_type, size)
    values (v_attachment_content_id, i_name, i_content_type, i_size)
    returning id into v_attachment_id;

    -- exception
--     when others then
--         perform add_log('ERROR');
--         return null;

    return v_attachment_id;

end;
$$;

alter function add_attachment(bytea, varchar, varchar, bigint) owner to postgres;

