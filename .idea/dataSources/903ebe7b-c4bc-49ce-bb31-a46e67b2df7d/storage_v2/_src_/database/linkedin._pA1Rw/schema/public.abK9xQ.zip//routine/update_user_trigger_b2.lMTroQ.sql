create function update_user_trigger_b2() returns trigger
    language plpgsql
as
$$
begin
        insert into log(error_text) values (NEW.first_name || 'bazamizga qoshilding');
        return NEW;
end;

$$;

alter function update_user_trigger_b2() owner to postgres;

