create function add_attachment_content(i_content bytea) returns uuid
    language plpgsql
as
$$
declare
    v_attachment_c_id uuid := null;
begin
    insert into attachment_content(content) values (i_content) returning id into v_attachment_c_id;
    return v_attachment_c_id;
end;
$$;

alter function add_attachment_content(bytea) owner to postgres;

