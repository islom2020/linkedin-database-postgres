create function add_post_b2(i_title character varying, i_attachments character varying, i_user_id character varying) returns character varying
    language plpgsql
as
$$
declare
    v_json_list     json              := i_attachments::json;
    v_json          json              := null;
    v_name          character varying := null;
    v_counter       integer           := 0;
    v_attachment_id uuid              := null;
    v_post_id       uuid              := null;

begin

--     raise notice '%', i_attachments;
    insert into post(TITLE, USER_ID) VALUES (i_title, i_user_id::uuid) returning id into v_post_id;
    loop
        select v_json_list -> v_counter into v_json;
        exit when v_json is null;
        select add_attachment(
                       i_name := v_json ->> 'name',
                       i_content_type := (v_json -> 'content_type')::character varying,
                       i_content := (v_json ->> 'content')::bytea,
                       i_size := (v_json ->> 'size')::bigint)
        into v_attachment_id;

        insert into post_attachment(post_id, attachment_id) VALUES (v_post_id, v_attachment_id);
        v_counter := v_counter + 1;
    end loop;
    return i_attachments;
end
$$;

alter function add_post_b2(varchar, varchar, varchar) owner to postgres;

