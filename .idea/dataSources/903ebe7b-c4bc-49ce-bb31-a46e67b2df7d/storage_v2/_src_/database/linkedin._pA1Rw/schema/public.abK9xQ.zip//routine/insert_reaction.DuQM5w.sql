create function insert_reaction() returns void
    language plpgsql
as
$$
declare
    v_user record := null;
    v_counter integer := 0;
begin
    loop
    for v_user in select id from "user"
        loop
            perform add_reaction(i_user_id := v_user.id::character varying,
                                i_post_id := '79fcdbf8-5f82-4060-9a97-88f74d6cc093', i_reaction_type := 3);
        end loop;

    exit when v_counter = 10000;
    v_counter := v_counter + 1;
    end loop ;
end;
$$;

alter function insert_reaction() owner to postgres;

