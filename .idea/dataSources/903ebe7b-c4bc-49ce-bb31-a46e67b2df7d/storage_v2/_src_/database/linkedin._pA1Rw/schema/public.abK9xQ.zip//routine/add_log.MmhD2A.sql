create function add_log(i_error_text character varying DEFAULT NULL::character varying) returns void
    language plpgsql
as
$$
begin
    insert into log(error_text) values (i_error_text);
end;
$$;

alter function add_log(varchar) owner to postgres;

