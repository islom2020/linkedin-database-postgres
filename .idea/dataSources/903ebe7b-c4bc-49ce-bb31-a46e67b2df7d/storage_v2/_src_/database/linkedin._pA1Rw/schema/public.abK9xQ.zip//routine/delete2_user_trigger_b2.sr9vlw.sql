create function delete2_user_trigger_b2() returns trigger
    language plpgsql
as
$$
begin
        insert into log(error_text) values (row_to_json(old) || ' user o''chdi');
        return NEW;
end;
$$;

alter function delete2_user_trigger_b2() owner to postgres;

