create function get_user_all_information(i_id uuid)
    returns TABLE(name character varying, skills json, experiences json, educations json)
    language plpgsql
as
$$
declare
    js_skills      json := null;
    js_experiences json := null;
    js_educations  json := null;
begin
    return query select (select first_name from "user" where id = i_id ),(select json_build_array('skill', s.name) from skill s
        inner join user_skill us on us.user_id = i_id and us.skill_id = s.id),null,null;
end
$$;

alter function get_user_all_information(uuid) owner to postgres;

