create function get_region_by_user_id(i_user_id uuid)
    returns TABLE(c_id uuid, c_name character varying, r_id uuid, r_name character varying)
    language plpgsql
as
$$
declare
        v_region_id uuid := null;
begin
        select region_id into v_region_id from "user" where "user".id = i_user_id;
        return
            query select c.id as country_id,
                         c.name as country_name,
                         r.id as region_id,
                         r.name as region_name
            from region r inner join country c on r.country_id = c.id
                where r.id = v_region_id;

end;
$$;

alter function get_region_by_user_id(uuid) owner to postgres;

