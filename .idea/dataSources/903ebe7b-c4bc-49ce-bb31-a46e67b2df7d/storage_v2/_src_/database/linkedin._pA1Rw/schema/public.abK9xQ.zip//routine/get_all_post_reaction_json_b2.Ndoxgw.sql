create function get_all_post_reaction_json_b2(i_post_id character varying) returns SETOF json
    language plpgsql
as
$$
declare
    v_reaction_type integer := null;
begin
    return query select json_agg(json_build_object(
            'id', u.id,
            'first_name', u.first_name,
            'about', u.about,
            'content', ac.content,
            'reaction_type', ur.reaction_type
        ))
                 from user_reaction ur
                          inner join "user" u on ur.user_id = u.id
                          left join attachment a on u.avatar = a.id
                          left join attachment_content ac on a.attachment_c_id = ac.id
                 where i_post_id::uuid = ur.post_id;

end
$$;

alter function get_all_post_reaction_json_b2(varchar) owner to postgres;

