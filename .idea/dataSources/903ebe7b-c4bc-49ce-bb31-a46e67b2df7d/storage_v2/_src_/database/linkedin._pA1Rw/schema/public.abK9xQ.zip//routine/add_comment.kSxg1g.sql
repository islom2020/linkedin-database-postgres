create function add_comment(i_post_id character varying, i_user_id character varying, i_text character varying, i_attachment_id character varying DEFAULT NULL::character varying, i_comment_id character varying DEFAULT NULL::character varying) returns boolean
    language plpgsql
as
$$
declare
    v_post_id       uuid    := i_post_id::uuid;
    v_user_id       uuid    := i_user_id::uuid;
    v_attachment_id       uuid    := i_attachment_id::uuid;
    v_comment_id       uuid    := i_comment_id::uuid;
    v_reaction_type integer := null;

begin
    if v_comment_id is not null then
        insert into user_comment (id, user_id, post_id, text, attachment_id, parent_comment_id)
        values (v_user_id,v_post_id,i_text,v_attachment_id,v_comment_id );
    else
        insert into user_comment (id, user_id, post_id, text, attachment_id)
        values (v_user_id,v_post_id,i_text,v_attachment_id);
    end if;
    return true;
end;

$$;

alter function add_comment(varchar, varchar, varchar, varchar, varchar) owner to postgres;

