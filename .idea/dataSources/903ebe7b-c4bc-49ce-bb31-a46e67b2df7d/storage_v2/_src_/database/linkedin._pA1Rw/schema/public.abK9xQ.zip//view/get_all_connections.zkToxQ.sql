create view get_all_connections("from", from_id, "to", to_id) as
SELECT from_user.first_name AS "from",
       from_user.id         AS from_id,
       to_user.first_name   AS "to",
       to_user.id           AS to_id
FROM "user" from_user
         JOIN user_connection uc ON from_user.id = uc.from_user
         JOIN "user" to_user ON to_user.id = uc.to_user;

alter table get_all_connections
    owner to postgres;

