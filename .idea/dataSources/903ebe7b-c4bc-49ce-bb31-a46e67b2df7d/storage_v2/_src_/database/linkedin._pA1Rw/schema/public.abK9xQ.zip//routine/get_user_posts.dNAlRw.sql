create function get_user_posts(i_user_id character varying) returns SETOF json
    language plpgsql
as
$$
begin
    return query select json_agg(json_build_object(
                                'id', p.id,
                                'title', p.title,
                                'attachments', (select json_agg
                                                           (json_build_object(
                                                                'id', a.id, 'name', a.name,
                                                                'content_type', a.content_type,
                                                                'content', encode(ac.content,'base64')
                                                            ))
                                                from post_attachment pa
                                                         inner join attachment a on pa.attachment_id = a.id
                                                         inner join attachment_content ac on a.attachment_c_id = ac.id
                                                where p.id = pa.post_id
                                                group by a.created_date
                                )
                            ))
                 from post p
                 where p.user_id = i_user_id::uuid;
end;
$$;

alter function get_user_posts(varchar) owner to postgres;

