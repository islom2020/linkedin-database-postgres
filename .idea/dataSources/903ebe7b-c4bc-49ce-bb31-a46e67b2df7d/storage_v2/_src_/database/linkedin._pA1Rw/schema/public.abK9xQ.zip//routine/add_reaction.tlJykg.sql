create function add_reaction(i_user_id character varying, i_post_id character varying, i_reaction_type integer) returns integer
    language plpgsql
as
$$
declare
    v_user_id       uuid    := i_user_id::uuid;
    v_post_id       uuid    := i_post_id::uuid;
    v_reaction_type integer := null;

begin

--     select reaction_type
--     into v_reaction_type
--     from user_reaction p
--     where p.user_id = v_user_id
--       and p.post_id = v_post_id;
-- 
--     if v_reaction_type is null then
        insert into user_reaction(user_id, post_id, reaction_type)
        VALUES (v_user_id, v_post_id, i_reaction_type);
--         return i_reaction_type;
--     end if;
-- 
--     if v_reaction_type = i_reaction_type then
--         delete from user_reaction p where p.user_id = v_user_id and p.post_id = v_post_id;
--         return -1;
--     end if;
-- 
--     update user_reaction p set reaction_type = i_reaction_type
--     where p.user_id = v_user_id and p.post_id = v_post_id;
    return i_reaction_type;

    exception when others
            then return -2;

end;

$$;

alter function add_reaction(varchar, varchar, integer) owner to postgres;

