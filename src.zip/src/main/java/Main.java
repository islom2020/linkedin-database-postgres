import model.izzatillo.UserService;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        long startTime1 = System.nanoTime();
        UserService.getUserByJsonnn();
        long endTime1 = System.nanoTime();
        System.out.println(endTime1-startTime1);

//        long startTime = System.nanoTime();
//        UserServiceee.getUserByJson();
//        long endTime = System.nanoTime();
//
//        System.out.println("json: " + (endTime - startTime));
//436062700
// 441380100
    }
}


