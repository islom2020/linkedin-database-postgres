import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import model.User;

import java.sql.*;
import java.util.ArrayList;

public class UserServiceee {
    public static void getUserByJson() throws SQLException {

        try (Connection connection = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/linkedin",
                "postgres",
                "1"
        )) {

            PreparedStatement preparedStatement = connection.prepareStatement("select * from get_user_full_info(?)");
            preparedStatement.setString(1, "959c5c9b-be3e-4257-b9c8-2a265d912409");
            ResultSet resultSet = preparedStatement.executeQuery();
            ObjectMapper objectMapper = new ObjectMapper();
            while (resultSet.next()) {
                String get_user_full_info = resultSet.getString("get_user_full_info");
                User user = objectMapper.readValue(get_user_full_info, User.class);
                System.out.println(user.getFirstName());
            }


        } catch (SQLException | JsonProcessingException throwables) {
            throwables.printStackTrace();
        }
    }



}
