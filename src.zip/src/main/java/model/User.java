package model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

@Data
public class User {
    private UUID userId;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("last_name")
    private String lastName;
    private String email;
    private String about;
    private String region;
    @JsonProperty("birth_date")
    private Date birthDate;
    private ArrayList<Education> education;
    private ArrayList<Experience> experience;
    private ArrayList<Skill> skill;

}

@Data
class Education{

    private String name;
    private String faculty;
    private String degree;
    private String description;
    private String region;
    private String linkedin;
    @JsonProperty("start_date")
    private String startDate;
    @JsonProperty("end_date")
    private String endDate;
}


@Data
class Experience{
    private String name;
    private String description;
    private String region;
    private String linkedin;
    @JsonProperty("start_date")
    private String startDate;
    @JsonProperty("end_date")
    private String endDate;
}

@Data
class Skill{
    private String name;
    @JsonProperty("category_name")
    private String categoryName;
}



