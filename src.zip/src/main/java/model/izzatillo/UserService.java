package model.izzatillo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class UserService {

    public static void getUserByJsonnn() throws SQLException {

        try (Connection connection = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/linkedin",
                "postgres",
                "1"
        )) {


            PreparedStatement preparedStatement = connection.prepareStatement("select * from get_user_info(?)");

            PreparedStatement preparedStatement2 = connection.prepareStatement("select * from get_education_by_user_id(?)");
            PreparedStatement preparedStatement3 = connection.prepareStatement("select * from get_skill_by_user_id(?)");
            preparedStatement.setString(1, "959c5c9b-be3e-4257-b9c8-2a265d912409");
            preparedStatement2.setString(1, "959c5c9b-be3e-4257-b9c8-2a265d912409");
            preparedStatement3.setString(1, "959c5c9b-be3e-4257-b9c8-2a265d912409");
            ResultSet resultSet = preparedStatement.executeQuery();
            ObjectMapper objectMapper = new ObjectMapper();
            System.out.println(resultSet);
            while (resultSet.next()) {
                model.izzatillo.User user = new model.izzatillo.User();

                user.setUserId(UUID.fromString(resultSet.getString("id")));
                user.setFirstName(resultSet.getString("first_name"));
                user.setLastName(resultSet.getString("last_name"));

                ResultSet resultSet2 = preparedStatement2.executeQuery();
                ResultSet resultSet3 = preparedStatement3.executeQuery();


                ArrayList<UserEducation> userEducations = new ArrayList<>();
                while (resultSet2.next()) {
                    UserEducation userEducation = new UserEducation();
                    userEducation.setEdDesc(resultSet2.getString("ed_desc"));
                    userEducation.setEdEndDate(resultSet2.getDate("ed_end_date"));
                    userEducation.setEdStartDate(resultSet2.getDate("ed_start_date"));
                    userEducation.setName(resultSet2.getString("ed_name"));
                    userEducation.setId(UUID.fromString(resultSet2.getString("ed_id")));
                    userEducation.setDegree(resultSet2.getByte("ed_degree"));
                    userEducation.setEdFaculty(resultSet2.getString("ed_faculty"));
                    userEducations.add(userEducation);
                }
                ArrayList<UserSkill> userSkills = new ArrayList<>();
                while (resultSet3.next()) {
                    UserSkill userSkill = new UserSkill();
                    userSkill.setId(UUID.fromString(resultSet3.getString("skill_id")));
                    userSkill.setName(resultSet3.getString("skill_name"));
                    userSkill.setSkillCategoryName(resultSet3.getString("skill_category_name"));
                    userSkill.setSkillCategoryId(UUID.fromString(resultSet3.getString("skill_category_id")));
                    userSkills.add(userSkill);
                }
                user.setUserEducations(userEducations);
                user.setUserSkills(userSkills);
                user.setUserExperiences(getUserEx());
                System.out.println(user.getFirstName());

            }


        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public static ArrayList<UserExperience> getUserEx() {

        ArrayList<UserExperience> userExperiences = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/linkedin",
                "postgres",
                "1"
        )) {

            PreparedStatement preparedStatement1 = connection.prepareStatement("select * from get_experience_by_user_id(?)");
            preparedStatement1.setString(1, "959c5c9b-be3e-4257-b9c8-2a265d912409");
            ResultSet resultSet1 = preparedStatement1.executeQuery();
            while (resultSet1.next()) {
                UserExperience userExperience = new UserExperience();
                userExperience.setExDesc(resultSet1.getString("ex_desc"));
                userExperience.setExEndDate(resultSet1.getDate("ex_end_date"));
                userExperience.setExStartDate(resultSet1.getDate("ex_start_date"));
                userExperience.setName(resultSet1.getString("ex_name"));
                userExperience.setId(UUID.fromString(resultSet1.getString("ex_id")));
                userExperiences.add(userExperience);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return userExperiences;
    }
}