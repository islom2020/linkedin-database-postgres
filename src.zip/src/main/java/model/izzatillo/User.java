package model.izzatillo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

@Data
public class User {
    private UUID userId;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("last_name")
    private String lastName;
    private String email;
    private String about;
    private ArrayList<UserExperience> userExperiences;
    private ArrayList<UserEducation> userEducations;
    private ArrayList<UserSkill> userSkills;

}

@Data
class UserExperience{
    private UUID id;
    private String name;
    private String exPosition;
    private Date exStartDate;
    private Date exEndDate;
    private String exDesc;
}

@Data
class UserEducation{
    private UUID id;
    private String name;
    private byte degree;
    private Date edStartDate;
    private Date edEndDate;
    private String edDesc;
    private String edFaculty;
}

@Data
class UserSkill{
    private UUID id;
    private String name;
    private UUID skillCategoryId;
    private String skillCategoryName;
}
